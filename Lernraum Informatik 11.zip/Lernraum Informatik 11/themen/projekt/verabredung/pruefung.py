"""Selbstcheck zu "Arbeitsteilung und Schnittstellen" -- prueft den Ordner stockwerk/ (Aufgabe 2, 3, 5 ★★; unter Mehr 7 und 8).

Gestartet wird spiel.py (arbeit() ist sein Modul). Die Raeume der Klasse -- meinraum.py und musikraum.py -- laedt der
Check SELBST, frisch, als Modul (_lade), und fragt sie so, wie das Spiel fragt: name, beschreibung(), befehle(),
antwort(befehl, rucksack). Er baut dafuer eigene Rucksaecke (LC2, LC8: ueber eigene Werte, nicht ueber die Werte des
Spiels) und sieht nach, was zurueckkommt und was dabei in der Shell erschien (die Verabredung: nie print, nie input).
Ob ein Raum im Spiel ist, zeigt das Spiel selbst: hoch, geh <name> (anspielen).

Aufgabe 5 ★★ (18.11.2026, Werkstatt Grundriss): turnhalle.py, die Turnhalle von Rasmus und Zeynep, passend gemacht.
Solange die Datei so ist, wie sie geschickt wurde (Fingerabdruck TURNHALLE_START), ist die Pruefung „noch nicht dran“
-- sonst stuende am Start eine zweite offene Pruefung (LC1). Sie fragt den Raum wie der Grundriss (_raum_befunde) und
dazu jeden seiner Befehle: Antwortet er auf alle wie auf einen unbekannten, kommt der Befehl nicht an (die Klammer
vertauscht).

Der Zufall des Musikraums (Aufgabe 8) steht fest, solange der Check ihn fragt: random.choice liefert immer das Element
auf Platz k und zaehlt mit, wie oft gewuerfelt wurde.
"""
import ast
import builtins
import hashlib
import importlib.util
import io
import random
import re
import sys

import pruefen
from pruefen import erwarte, braucht, anspielen, funktion, quelltext, ohne_kommentare

TITEL = "Arbeitsteilung und Schnittstellen · Selbstcheck"

# So spielt der Check das Programm an: in den ersten Stock und ins Sekretariat
EINGABEN = ["hoch", "geh sekretariat", "benutze telefon", "raus", "ende"]

TREPPE = "wartest auf den Morgen"
KEIN_WERT = object()
VERGEBEN = ("flur", "informatikraum", "lehrerzimmer", "bibliothek", "keller", "hausmeisterraum", "tor", "gang",
            "sekretariat", "aula", "turnhalle", "musikraum")
# turnhalle.py, wie Rasmus und Zeynep sie geschickt haben (ohne Kommentare und Leerzeilen) -- stockwerk_testen.py
# rechnet nach, dass der Abdruck zur Datei im Arbeitsordner passt
TURNHALLE_START = "b424fb2007cdcc69e9db3b583e71f3fe174467e6"
UNBEKANNT = "tanze im kreis"
HINTS = {"beschreibung": "str", "befehle": "list[str]", "antwort": "str"}


class _KeinInput(Exception):
    pass


def _kein_input(*_):
    raise _KeinInput()


def _hat_code(datei):
    """Steht in der Datei mehr als der Kopfkommentar?"""
    return any(z.strip() for z in ohne_kommentare(datei).splitlines())


def _lade(datei):
    """Laedt eine Datei des Ordners frisch als Modul. Gibt (modul, gedruckt, fehler)."""
    pfad = pruefen._programmordner() / datei
    if not pfad.exists():
        return None, "", "Die Datei %s fehlt im Ordner." % datei
    spec = importlib.util.spec_from_file_location("_check_" + pfad.stem, str(pfad))
    modul = importlib.util.module_from_spec(spec)
    puffer, vorher, eingabe = io.StringIO(), sys.stdout, builtins.input
    sys.stdout, builtins.input = puffer, _kein_input
    try:
        pruefen._mit_zeitgrenze(lambda: spec.loader.exec_module(modul))
        fehler = None
    except _KeinInput:
        fehler = "%s fragt beim Laden mit input() -- ein Raum fragt nie." % datei
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        fehler = "%s bricht beim Laden ab: %s: %s" % (datei, type(e).__name__, e)
    finally:
        sys.stdout, builtins.input = vorher, eingabe
    return modul, puffer.getvalue(), fehler


def _ruf(modul, name, *argumente):
    """Ruft eine Funktion des Moduls. Gibt (wert, gedruckt, fehler)."""
    f = getattr(modul, name, None)
    if not callable(f):
        return KEIN_WERT, "", "Im Raum gibt es keine Funktion %s." % name
    puffer, vorher, eingabe = io.StringIO(), sys.stdout, builtins.input
    sys.stdout, builtins.input = puffer, _kein_input
    try:
        wert, fehler = pruefen._mit_zeitgrenze(lambda: f(*argumente)), None
    except _KeinInput:
        wert, fehler = KEIN_WERT, "%s fragt mit input() -- ein Raum fragt nie, er bekommt den Befehl." % name
    except BaseException as e:  # noqa: BLE001
        wert, fehler = KEIN_WERT, "%s bricht ab: %s: %s" % (name, type(e).__name__, e)
    finally:
        sys.stdout, builtins.input = vorher, eingabe
    return wert, puffer.getvalue(), fehler


def _verbotenes(datei):
    """print, input, global im Quelltext der Datei -- als Liste der Namen."""
    try:
        baum = ast.parse(quelltext(datei))
    except SyntaxError:
        return []
    funde = set()
    for k in ast.walk(baum):
        if isinstance(k, ast.Global):
            funde.add("global")
        if isinstance(k, ast.Call) and isinstance(k.func, ast.Name) and k.func.id in ("print", "input"):
            funde.add(k.func.id)
    return sorted(funde)


def _befehl_probe(befehl):
    """Ein Befehl aus befehle() zum Ausprobieren: <satz> und Aehnliches wird ein Wort."""
    return re.sub(r"<[^>]*>", "probe", str(befehl)).strip()


def _raum_befunde(datei, erlaubt=()):
    """Alles, was gegen die Verabredung spricht -- als Liste von Saetzen (leer: passt)."""
    m, gedruckt, fehler = _lade(datei)
    if fehler:
        return [fehler]
    if gedruckt:
        return ["Beim import zeigt %s etwas in der Shell an (%s) -- dort stehen nur Startwerte und Funktionen."
                % (datei, gedruckt.strip().splitlines()[0][:40])]
    funde = []
    name = getattr(m, "name", None)
    if not isinstance(name, str) or not name:
        funde.append("In %s steht kein name = \"…\" -- so heißt der Raum im Spiel." % datei)
    elif not re.fullmatch(r"[a-zäöüß]+", name):
        funde.append("name = %r: klein und ein Wort, sonst findet geh den Raum nicht." % name)
    elif name in VERGEBEN and name not in erlaubt:
        funde.append("name = %r: Diesen Raum gibt es schon im Spiel -- wählt einen anderen." % name)
    for fn, art in (("beschreibung", str), ("befehle", list)):
        wert, gedruckt, fehler = _ruf(m, fn)
        if fehler:
            funde.append(fehler)
        elif gedruckt:
            funde.append("%s() zeigt etwas in der Shell an -- verabredet ist: zurückgeben, nicht anzeigen." % fn)
        elif not isinstance(wert, art) or not wert:
            funde.append("%s() gibt %r zurück -- verabredet ist %s." % (fn, wert, "ein Satz" if art is str else
                                                                      "eine Liste der Befehle, mindestens einer"))
    wert, gedruckt, fehler = _ruf(m, "antwort", UNBEKANNT, ["lampe"])
    if fehler:
        funde.append(fehler if "keine Funktion" not in fehler else "Im Raum gibt es keine Funktion antwort(befehl, rucksack).")
    elif gedruckt:
        funde.append("antwort(\"%s\", [\"lampe\"]) zeigt etwas in der Shell an -- verabredet ist: zurückgeben." % UNBEKANNT)
    elif not isinstance(wert, str) or not wert:
        funde.append("antwort(\"%s\", [\"lampe\"]) gibt %r zurück -- auch für einen Befehl, den der Raum nicht kennt, "
                     "kommt ein Satz zurück." % (UNBEKANNT, wert))
    verb = _verbotenes(datei)
    if verb:
        funde.append("In %s steht %s -- die Verabredung sagt: nie print, nie input, nie global." % (datei, ", ".join(verb)))
    return funde


def _raum_ok(datei):
    try:
        return not _raum_befunde(datei, ("musikraum",) if datei == "musikraum.py" else ())
    except AssertionError:
        return False


def _im_spiel(name):
    return re.search(r"^import\s+%s\b" % re.escape(name), ohne_kommentare(), re.M) is not None


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es am Ende von abenteuer konnte"""
    aus, _ = anspielen(["westen", "schau", "ende"])
    erwarte("Der Keller." in aus, "Im Westen des Flurs ist kein Keller mehr -- ist im Spiel etwas verrutscht?")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")


# ── Aufgabe 2 · Die Aula zieht ein ───────────────────────────────────────

def pruefe_20_aula():
    """Aufgabe 2 · Die Aula ist im ersten Stock"""
    aus, _ = anspielen(["hoch", "geh aula", "sprich hallo", "ende"])
    erwarte("Die Aula. 400" in aus, "Im ersten Stock gibt es noch keine Aula: geh aula findet keine Tür. Steht sie im "
            "Spiel wie das Sekretariat?")
    erwarte("hallo" in aus, "In der Aula antwortet niemand auf sprich hallo.")


# ── Aufgabe 3 · Euer Raum ────────────────────────────────────────────────

def pruefe_30_verabredung():
    """Aufgabe 3 · meinraum.py hält die Verabredung: name, beschreibung(), befehle(), antwort(befehl, rucksack)"""
    braucht(_hat_code("meinraum.py"))
    funde = _raum_befunde("meinraum.py")
    erwarte(not funde, funde[0] if funde else "")


def pruefe_31_befehle():
    """Aufgabe 3 ★★ · Jeder Befehl tut etwas -- und einer gibt etwas in den Rucksack, nie über sechs"""
    braucht(_hat_code("meinraum.py") and _raum_ok("meinraum.py"))
    m, _, _ = _lade("meinraum.py")
    sonst, _, _ = _ruf(m, "antwort", UNBEKANNT, ["lampe"])
    befehle, _, _ = _ruf(m, "befehle")
    for b in befehle:
        probe = _befehl_probe(b)
        wert, gedruckt, fehler = _ruf(m, "antwort", probe, ["lampe"])
        erwarte(fehler is None, "Bei antwort(\"%s\", …) %s" % (probe, fehler or ""))
        erwarte(isinstance(wert, str) and wert and wert != sonst and not gedruckt,
                "Auf \"%s\" antwortet der Raum wie auf einen Befehl, den er nicht kennt -- jeder Befehl aus befehle() "
                "bekommt seine eigene Antwort." % probe)
    m, _, _ = _lade("meinraum.py")
    rucksack = ["lampe"]
    for b in befehle:
        _ruf(m, "antwort", _befehl_probe(b), rucksack)
    erwarte(len(rucksack) > 1, "Kein Befehl aus befehle() legt etwas in den Rucksack (er blieb %s)." % rucksack)
    gegeben = [x for x in rucksack if x != "lampe"]
    for b in befehle:
        _ruf(m, "antwort", _befehl_probe(b), rucksack)
    erwarte(len([x for x in rucksack if x != "lampe"]) == len(gegeben),
            "Wer die Befehle zweimal gibt, bekommt %s zweimal -- jedes Ding gibt es im Raum nur einmal." % gegeben)
    m, _, _ = _lade("meinraum.py")
    voll = ["lampe", "seil", "apfel", "kreide", "stick", "karte"]
    for b in befehle:
        _ruf(m, "antwort", _befehl_probe(b), voll)
    erwarte(len(voll) <= 6, "Mit sechs Dingen im Rucksack gibt der Raum trotzdem etwas hinein -- jetzt sind es %d. "
            "Verabredet sind höchstens sechs." % len(voll))


def pruefe_32_im_spiel():
    """Aufgabe 3 ★★★ · Euer Raum ist im Spiel: hoch, geh, seine Befehle, raus"""
    braucht(_hat_code("meinraum.py") and _raum_ok("meinraum.py"))
    m, _, _ = _lade("meinraum.py")
    erwarte(_im_spiel("meinraum"), "spiel.py holt meinraum noch nicht herein.")
    befehle, _, _ = _ruf(m, "befehle")
    erster = _befehl_probe(befehle[0])
    satz, _, _ = _ruf(m, "beschreibung")
    aus, _ = anspielen(["hoch", "geh %s" % m.name, erster, "raus", "ende"])
    erwarte(satz[:25] in aus, "Nach hoch und geh %s steht die Beschreibung eures Raums nicht da -- steht er in der "
            "Liste oben?" % m.name)
    m, _, _ = _lade("meinraum.py")
    antwort, _, _ = _ruf(m, "antwort", erster, ["lampe"])
    erwarte(str(antwort)[:25] in aus, "Im Spiel antwortet euer Raum auf \"%s\" nicht so wie allein." % erster)


def pruefe_39_hints():
    """Hinweis · In meinraum.py hat jedes def Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(_hat_code("meinraum.py"))
    try:
        baum = ast.parse(quelltext("meinraum.py"))
    except SyntaxError:
        baum = None
    braucht(baum is not None)
    ohne, falsch = [], []
    for k in baum.body:
        if isinstance(k, ast.FunctionDef):
            if k.returns is None or any(a.annotation is None for a in k.args.args):
                ohne.append(k.name)
            elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[k.name]:
                falsch.append("%s -> %s" % (k.name, HINTS[k.name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 5 ★★ · Die Turnhalle, die nicht passt: die Tür geht auf ─────

def _abdruck(datei):
    zeilen = [z.rstrip() for z in ohne_kommentare(datei).splitlines() if z.strip()]
    return hashlib.sha1("\n".join(zeilen).encode("utf-8")).hexdigest()


def pruefe_50_turnhalle():
    """Aufgabe 5 ★★ · turnhalle.py passt zur Verabredung: alle vier Stecker grün"""
    braucht(_hat_code("turnhalle.py") and _abdruck("turnhalle.py") != TURNHALLE_START,
            "turnhalle.py ist noch so, wie Rasmus und Zeynep sie geschickt haben.")
    funde = _raum_befunde("turnhalle.py", erlaubt=("turnhalle",))
    erwarte(not funde, funde[0] if funde else "")
    m, _, _ = _lade("turnhalle.py")
    sonst, _, _ = _ruf(m, "antwort", UNBEKANNT, ["lampe"])
    befehle, _, _ = _ruf(m, "befehle")
    eigene = 0
    for b in befehle:
        probe = _befehl_probe(b)
        wert, gedruckt, fehler = _ruf(m, "antwort", probe, ["lampe"])
        erwarte(fehler is None, "Bei antwort(\"%s\", …) %s" % (probe, fehler or ""))
        erwarte(not gedruckt, "Auf \"%s\" zeigt die Turnhalle etwas in der Shell an -- verabredet ist: zurückgeben, "
                "nicht anzeigen." % probe)
        erwarte(isinstance(wert, str) and wert, "Auf \"%s\" gibt die Turnhalle %r zurück -- verabredet ist ein Satz, "
                "für jeden Befehl." % (probe, wert))
        eigene += wert != sonst
    erwarte(eigene > 0, "Auf jeden ihrer Befehle antwortet die Turnhalle wie auf einen, den sie nicht kennt -- kommt der "
            "Befehl in der Klammer an der Stelle an, an der das Spiel ihn schickt?")


# ── Aufgabe 7 ★★ · Zwei Räume, ein Name ──────────────────────────────────

class _Raum:
    """Ein Raum, wie ihn der Check fuer doppelte_namen baut: nur ein Name."""
    def __init__(self, name):
        self.name = name


def pruefe_70_doppelt():
    """Aufgabe 7 ★★ · doppelte_namen() findet jeden doppelten Namen einmal"""
    f = funktion("doppelte_namen")
    braucht(f is not None)
    g = f.__globals__
    alt = g.get("oben")
    try:
        for namen, soll in ((["aula", "mensa", "aula", "aula", "kunst", "kunst"], ["aula", "kunst"]),
                            (["aula", "mensa"], []), ([], []), (["mensa", "aula", "mensa"], ["mensa"])):
            g["oben"] = [_Raum(n) for n in namen]
            puffer, vorher = io.StringIO(), sys.stdout
            sys.stdout = puffer
            try:
                wert = f()
                fehler = None
            except BaseException as e:  # noqa: BLE001
                wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
            finally:
                sys.stdout = vorher
            erwarte(fehler is None, "doppelte_namen() bricht ab: %s" % fehler)
            erwarte(wert == soll, "Mit Räumen namens %s gibt doppelte_namen() %r zurück, nicht %r."
                    % (", ".join(namen) or "(keine)", wert, soll))
    finally:
        g["oben"] = alt
    alt_q = pruefen._QUELLE
    pruefen._QUELLE = re.sub(r"^oben[ \t]*=.*$", "oben = [sekretariat, sekretariat]", alt_q, count=1, flags=re.M)
    try:
        aus, _ = anspielen(["ende"])
    finally:
        pruefen._QUELLE = alt_q
    erwarte("Achtung: Zwei Räume heißen sekretariat." in aus,
            "Mit oben = [sekretariat, sekretariat] steht beim Start nicht „Achtung: Zwei Räume heißen sekretariat.“")


# ── Aufgabe 8 ★★★★ · Für Expert*innen: Der Musikraum zieht ein ───────────

def _wuerfel(k, zaehler):
    """random.choice fest: immer das Element auf Platz k; zaehlt jeden Wurf aus einer Liste von Tasten."""
    def wahl(liste):
        if len(liste) and all(isinstance(x, str) and len(x) == 1 and x in "cdefgah" for x in liste):
            zaehler.append(1)
        return liste[k % len(liste)]
    return wahl


def _musik(k, befehle, rucksack=None):
    """Laedt musikraum.py frisch, Zufall fest auf k; gibt (antworten, rucksack, wuerfe beim Laden, wuerfe gesamt)."""
    echt = random.choice
    zaehler = []
    random.choice = _wuerfel(k, zaehler)
    try:
        m, _, fehler = _lade("musikraum.py")
        beim_laden = len(zaehler)
        r = ["lampe"] if rucksack is None else rucksack
        antworten = []
        for b in befehle:
            wert, gedruckt, f = _ruf(m, "antwort", b, r)
            antworten.append(f or ("GEDRUCKT" if gedruckt else wert))
    finally:
        random.choice = echt
    return antworten, r, beim_laden, len(zaehler)


def _melodie(text):
    """Die Töne aus „Das Klavier spielt: c d e.“ (auch mit Kommas)."""
    m = re.search(r"spielt:?\s*(.*)", str(text))
    if not m:
        return []
    return [t for t in re.split(r"[\s,.]+|\bund\b", m.group(1).lower()) if len(t) == 1 and t in "cdefgah"]


def pruefe_80_musik_verabredung():
    """Aufgabe 8 ★★★★ · musikraum.py hält die Verabredung -- name musikraum, hör zu und spiele unter den Befehlen"""
    braucht(_hat_code("musikraum.py"))
    funde = _raum_befunde("musikraum.py", erlaubt=("musikraum",))
    erwarte(not funde, funde[0] if funde else "")
    m, _, _ = _lade("musikraum.py")
    erwarte(getattr(m, "name", "") == "musikraum", "Der Musikraum heißt im Spiel musikraum -- in musikraum.py steht "
            "name = %r." % getattr(m, "name", None))
    befehle, _, _ = _ruf(m, "befehle")
    erwarte(any(str(b).startswith("spiele") for b in befehle) and "hör zu" in befehle,
            "Unter den Befehlen des Musikraums fehlen spiele … oder hör zu.")


def pruefe_81_melodie():
    """Aufgabe 8 ★★★★ · Drei verschiedene Töne, genau drei Würfe -- gewürfelt erst am Klavier, dann nicht mehr"""
    braucht(_hat_code("musikraum.py") and _raum_ok("musikraum.py"))
    for k in range(7):
        antworten, _, beim_laden, wuerfe = _musik(k, ["hör zu", "hör zu"])
        toene = _melodie(antworten[0])
        erwarte(beim_laden == 0, "musikraum.py würfelt schon beim import -- erst, wenn jemand ans Klavier geht.")
        erwarte(len(toene) == 3 and len(set(toene)) == 3,
                "Liefert random.choice immer den Platz %d, spielt das Klavier %r -- verlangt sind drei verschiedene "
                "Töne." % (k, antworten[0]))
        erwarte(wuerfe == 3, "Für die Melodie wird %d-mal gewürfelt -- verabredet sind genau drei Würfe, einmal je "
                "Spiel." % wuerfe)
        erwarte(_melodie(antworten[1]) == toene, "Beim zweiten hör zu spielt das Klavier eine andere Melodie.")


def pruefe_82_bank():
    """Aufgabe 8 ★★★★ · Die Melodie öffnet die Bank einmal -- das Notenheft kommt mit nimm in den Rucksack"""
    braucht(_hat_code("musikraum.py") and _raum_ok("musikraum.py"))
    antworten, _, _, _ = _musik(0, ["hör zu"])
    toene = _melodie(antworten[0])
    braucht(len(toene) == 3)
    spielen = ["spiele %s" % t for t in toene]
    antworten, r, _, _ = _musik(0, ["spiele x"] + spielen + spielen + ["nimm notenheft", "nimm notenheft"])
    erwarte("Taste" in str(antworten[0]), "Auf spiele x sagt der Musikraum nicht, dass es die Taste nicht gibt.")
    erwarte("springt auf" in str(antworten[3]), "Nach der Melodie %s springt die Bank nicht auf (Antwort: %r)."
            % (", ".join(toene), antworten[3]))
    erwarte(not any("springt auf" in str(a) for a in antworten[4:7]), "Die Bank springt beim zweiten Mal wieder auf.")
    erwarte(r.count("notenheft") == 1, "Nach der Melodie und zweimal nimm notenheft liegen %d Notenhefte im Rucksack "
            "-- es gibt nur eines." % r.count("notenheft"))
    voll = ["lampe", "seil", "apfel", "kreide", "stick", "karte"]
    _musik(0, spielen + ["nimm notenheft"], voll)
    erwarte(len(voll) == 6, "Mit sechs Dingen im Rucksack kommt das Notenheft trotzdem hinein.")


def pruefe_83_musik_im_spiel():
    """Aufgabe 8 ★★★★ · Der Musikraum ist im ersten Stock"""
    braucht(_hat_code("musikraum.py") and _raum_ok("musikraum.py"))
    erwarte(_im_spiel("musikraum"), "spiel.py holt musikraum noch nicht herein.")
    aus, _ = anspielen(["hoch", "geh musikraum", "hör zu", "ende"])
    erwarte("Das Klavier spielt" in aus or "spielt" in aus.split("hör zu")[-1],
            "Nach hoch, geh musikraum, hör zu spielt im Spiel kein Klavier -- steht der Musikraum in der Liste oben?")
