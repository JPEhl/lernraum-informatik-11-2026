# Die Schule bei Nacht -- mit erstem Stock.
# Daran arbeitet ihr: Räume für oben.
#
# Vorbereitet (das ist kein neuer Stoff):
# hoch im Flur führt in den Gang im ersten
# Stock; dort geh <raum>, raus und runter.
# Jeder Raum oben ist eine eigene Datei
# (ein Modul). Das Spiel fragt ihn nur über
# die Verabredung: name, beschreibung(),
# befehle(), antwort(befehl, rucksack).
#
# Einbinden: oben import <raum> und den
# Raum in die Liste oben schreiben.

import random

# Die Räume im ersten Stock -- je Raum eine Datei:
import sekretariat


# ------------------------ die Welt

# Was wo liegt -- je Raum eine Liste. Der Schacht
# ist kein Raum, man kommt nur mit dem Seil an
# ihn heran.
dinge_flur = ["kreide"]
dinge_informatikraum = ["stick", "kreide"]
dinge_lehrerzimmer = ["seil", "apfel", "kreide"]
dinge_bibliothek = ["karte", "kreide"]
dinge_keller = ["pausenbrot", "kreide"]
dinge_schacht = ["hausmeisterschlüssel"]
dinge_hausmeisterraum = ["torschlüssel", "kreide"]
dinge_tor = []

rucksack = ["lampe"]

# Welche Räume es im ersten Stock gibt:
oben = [sekretariat]


# ------------------------ die Räume

def beschreibung(raum: str) -> str:
    """Der Satz, der einen Raum beschreibt."""
    if raum == "flur":
        return "Der Flur. Nur deine Lampe leuchtet. Das Haupttor liegt im Norden, dahinter ist Nacht."
    elif raum == "informatikraum":
        return "Der Informatikraum. 24 Rechner schlafen. Einer blinkt, als hätte er etwas zu sagen."
    elif raum == "lehrerzimmer":
        return "Das Lehrerzimmer. Es riecht nach altem Kaffee. Die Kaffeemaschine beobachtet dich."
    elif raum == "bibliothek":
        return "Die Bibliothek. Ein Plakat sagt RUHE! Es ist sehr, sehr ruhig."
    elif raum == "keller":
        return "Der Keller. Rohre, Staub, ein Schacht im Boden. Irgendwo tropft es."
    elif raum == "hausmeisterraum":
        return "Der Hausmeisterraum. 300 Schlüssel an der Wand, einer davon ist sehr groß."
    elif raum == "tor":
        return "Das Haupttor. Draußen ist Nacht, Luft und ein Fahrrad, das deins ist."
    elif raum == "gang" or raum in zimmer_namen():
        return oben_beschreibung(raum)
    else:
        return "Ein Raum, den es nicht gibt."


def ziel(raum: str, richtung: str) -> str:
    """Welcher Raum liegt von raum aus in richtung? Leerer Text heißt: Wand."""
    if raum == "flur":
        if richtung == "norden":
            return "tor"
        elif richtung == "osten":
            return "informatikraum"
        elif richtung == "süden":
            return "lehrerzimmer"
        elif richtung == "westen":
            return "keller"
    elif raum == "informatikraum":
        if richtung == "westen":
            return "flur"
    elif raum == "lehrerzimmer":
        if richtung == "norden":
            return "flur"
    elif raum == "keller":
        if richtung == "osten":
            return "flur"
        elif richtung == "süden":
            return "bibliothek"
    elif raum == "bibliothek":
        if richtung == "norden":
            return "keller"
        elif richtung == "westen":
            return "hausmeisterraum"
    elif raum == "hausmeisterraum":
        if richtung == "osten":
            return "bibliothek"
    return ""


def ausgaenge(raum: str) -> list[str]:
    """Alle Richtungen, in denen es von raum aus weitergeht."""
    liste = []
    for richtung in ["norden", "osten", "süden", "westen"]:
        if ziel(raum, richtung) != "":
            liste.append(richtung)
    return liste


def tuer_offen(wohin: str) -> bool:
    """Darf man nach wohin? Manche Türen brauchen etwas aus dem Rucksack."""
    if wohin == "tor":
        return "torschlüssel" in rucksack
    elif wohin == "hausmeisterraum":
        return "hausmeisterschlüssel" in rucksack
    elif wohin == "keller":
        return "lampe" in rucksack
    else:
        return True


def dinge_im(raum: str) -> list[str]:
    """Die Liste der Dinge, die in raum liegen."""
    if raum == "flur":
        return dinge_flur
    elif raum == "informatikraum":
        return dinge_informatikraum
    elif raum == "lehrerzimmer":
        return dinge_lehrerzimmer
    elif raum == "bibliothek":
        return dinge_bibliothek
    elif raum == "keller":
        return dinge_keller
    elif raum == "hausmeisterraum":
        return dinge_hausmeisterraum
    else:
        return dinge_tor


def wert(ding: str) -> int:
    """Wie viele Punkte ein Fundstück bringt."""
    if ding == "stick":
        return 30
    elif ding == "hausmeisterschlüssel" or ding == "torschlüssel":
        return 20
    else:
        return 10


# ------------------------ anzeigen

def aufzaehlen(liste: list[str]) -> str:
    """Zählt auf, wie ein Mensch es sagt: ["stick", "seil", "apfel"] -> "Stick, Seil und Apfel"."""
    text = ""
    for i in range(len(liste)):
        if i > 0 and i == len(liste) - 1:
            text = text + " und "
        elif i > 0:
            text = text + ", "
        text = text + liste[i].capitalize()
    return text


def zeige_raum(raum: str) -> None:
    print()
    if "lampe" not in rucksack:
        print("Stockdunkel. Du siehst nicht einmal, wo du die Lampe hingelegt hast.")
    else:
        print(beschreibung(raum))
        hier = dinge_im(raum)
        if len(hier) > 0:
            print("Hier liegt:", aufzaehlen(hier) + ".")
        if "karte" in rucksack and len(ausgaenge(raum)) > 0:
            print("Ausgänge:", aufzaehlen(ausgaenge(raum)) + ".")


def zeige_rucksack(punkte: int, zuege: int) -> None:
    if len(rucksack) == 0:
        print("Dein Rucksack ist leer.")
    else:
        print("Du trägst:", aufzaehlen(rucksack) + ".")
    print("Punkte:", punkte, "- Züge übrig:", zuege)


def befehle(raum: str) -> str:
    """Die Befehle, die gerade gehen -- steht vor jeder Eingabe."""
    if raum == "gang":
        text = "Befehle:"
        for name in zimmer_namen():
            text = text + " geh " + name + " ·"
        return text + " runter · zeige · hilfe"
    if raum in zimmer_namen():
        text = "Befehle:"
        for befehl in oben_befehle(raum):
            text = text + " " + befehl + " ·"
        return text + " raus · schau · zeige · hilfe"
    if "karte" in rucksack:
        wege = ausgaenge(raum)
    else:
        wege = ["norden", "osten", "süden", "westen"]
    text = "Befehle:"
    for richtung in wege:
        text = text + " " + richtung + " ·"
    for ding in dinge_im(raum):
        text = text + " nimm " + ding + " ·"
    for ding in rucksack:
        text = text + " lege " + ding + " ·"
        if ding == "apfel" or ding == "pausenbrot":
            text = text + " iss " + ding + " ·"
    return text + " schau · zeige · hilfe (alle Befehle)"


def hilfe() -> None:
    print("Befehle: norden, osten, süden, westen, nimm <ding>, lege <ding>,")
    print("         schau, zeige, karte, benutze <ding>, iss <ding>, warte <n>, hilfe, ende")
    print("Im Flur: hoch. Im ersten Stock: geh <raum>, raus, runter.")


# ------------------------ der erste Stock
# Das Spiel kennt von einem Raum oben nur, was
# die Verabredung sagt.

def zimmer_namen() -> list[str]:
    """Die Namen aller Räume im ersten Stock."""
    namen = []
    for zimmer in oben:
        namen.append(zimmer.name)
    return namen


def oben_beschreibung(raum: str) -> str:
    """Was man oben sieht -- im Gang oder in einem Raum."""
    for zimmer in oben:
        if zimmer.name == raum:
            return zimmer.beschreibung()
    return "Der Gang im ersten Stock. Türen: " + aufzaehlen(zimmer_namen()) + "."


def oben_befehle(raum: str) -> list[str]:
    """Was man in einem Raum oben tun kann."""
    for zimmer in oben:
        if zimmer.name == raum:
            return zimmer.befehle()
    return []


def oben_antwort(raum: str, befehl: str) -> str:
    """Der Raum oben antwortet auf einen Befehl."""
    for zimmer in oben:
        if zimmer.name == raum:
            return zimmer.antwort(befehl, rucksack)
    return "Hier ist niemand."


# ------------------------ handeln

def gehe(raum: str, richtung: str) -> str:
    """Gibt den neuen Raum zurück -- oder den alten, wenn es nicht weitergeht."""
    wohin = ziel(raum, richtung)
    if wohin == "":
        print("Da ist eine Wand. Eine sehr solide Wand.")
        return raum
    if not tuer_offen(wohin):
        if wohin == "keller":
            print("Da unten ist es stockdunkel. Ohne Lampe gehst du da nicht runter.")
        else:
            print("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")
        return raum
    return wohin


def nimm(ding: str, raum: str) -> int:
    """Nimmt ding aus dem Raum in den Rucksack. Gibt die Punkte dafür zurück."""
    hier = dinge_im(raum)
    if ding not in hier:
        print("Hier gibt es kein", ding + ".")
        return 0
    if len(rucksack) >= 6:
        print("Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht. Leg etwas ab oder iss etwas.")
        return 0
    hier.remove(ding)
    rucksack.append(ding)
    print("Du nimmst:", ding.capitalize() + ".")
    if ding == "stick":
        print("Dein USB-Stick. Der Grund für diese ganze Nacht.")
    if ding == "pausenbrot":
        print("Ein Pausenbrot von 2019. Es ist ... fest geworden.")
    return wert(ding)


def lege(ding: str, raum: str) -> None:
    if ding not in rucksack:
        print("Das hast du nicht.")
    else:
        rucksack.remove(ding)
        dinge_im(raum).append(ding)
        print("Du legst weg:", ding.capitalize() + ".")
        if ding == "lampe":
            print("Es wird sehr dunkel. Das war vielleicht keine gute Idee.")


def kater(raum: str) -> None:
    """Byte schnappt sich ein Ding (nie die Lampe) und lässt es in raum fallen."""
    print("Der Schulkater Byte streicht um deine Beine.")
    zum_schnappen = []
    for ding in rucksack:
        if ding != "lampe":
            zum_schnappen.append(ding)
    if len(zum_schnappen) == 0:
        print("Er schnuppert an deiner Lampe und verliert das Interesse.")
    else:
        ding = random.choice(zum_schnappen)
        rucksack.remove(ding)
        dinge_im(raum).append(ding)
        print("Er schnappt sich", ding, "und lässt es hier fallen.")


def benutze(ding: str, raum: str) -> int:
    """Gibt die Punkte zurück, die das bringt (meistens keine)."""
    if ding == "seil":
        if "seil" not in rucksack:
            print("Du hast kein Seil.")
        elif raum != "keller":
            print("Hier gibt es nichts, wo ein Seil hilft.")
        elif len(dinge_schacht) == 0:
            print("Der Schacht ist leer. Du hast schon alles geholt.")
        else:
            print("Du lässt das Seil in den Schacht. Unten liegt ein Schlüssel mit einem Anhänger: HM.")
            print("Du ziehst ihn hoch. Das Seil bleibt unten, es hat sich verhakt.")
            rucksack.remove("seil")
            rucksack.append("hausmeisterschlüssel")
            dinge_schacht.remove("hausmeisterschlüssel")
            return wert("hausmeisterschlüssel")
    elif ding == "kaffeemaschine":
        if raum != "lehrerzimmer":
            print("Hier steht keine Kaffeemaschine.")
        else:
            meldung = random.choice(["Fehler 418: Ich bin eine Teekanne.",
                                     "Bitte Wassertank füllen. Der Wassertank ist voll.",
                                     "Entkalken Sie mich. Jetzt.",
                                     "Kein Kaffee für Schüler nach 22 Uhr."])
            print("Die Kaffeemaschine sagt:", meldung)
    elif ding == "lampe":
        print("Die Lampe leuchtet schon. Mehr kann sie nicht.")
    else:
        print("Damit kannst du hier nichts anfangen.")
    return 0


def iss(ding: str) -> int:
    """Gibt zurück, wie viele Züge das bringt -- auch negativ."""
    if ding not in rucksack:
        print("Das hast du nicht.")
        return 0
    elif ding == "apfel":
        rucksack.remove("apfel")
        print("Knackig. Du bist wieder wach: 3 Züge mehr.")
        return 3
    elif ding == "pausenbrot":
        rucksack.remove("pausenbrot")
        print("Du beißt ab. Du bereust es. Byte schaut dich mitleidig an. 3 Züge weniger.")
        return -3
    else:
        print("Das isst man nicht.")
        return 0


def sterne(punkte: int) -> str:
    """Ein Stern je 10 Punkte, als Text."""
    text = ""
    for i in range(punkte // 10):
        text = text + "*"
    return text


# ------------------------ das Spiel

raum = "flur"
zuege = 30
punkte = 0
sekunden = 0
ruhe = 0

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
hilfe()
zeige_raum(raum)

eingabe = ""
while zuege > 0 and raum != "tor" and eingabe != "ende":
    print(befehle(raum))
    eingabe = input("> ").lower().strip()
    zuege = zuege - 1
    sekunden = sekunden + 45

    if eingabe == "ende":
        print("Du setzt dich auf die Treppe und wartest auf den Morgen.")
    elif raum in zimmer_namen() and eingabe not in ["hilfe", "schau", "zeige", "raus"]:
        print(oben_antwort(raum, eingabe))
    elif eingabe == "hoch":
        if raum == "flur":
            raum = "gang"
            zeige_raum(raum)
        else:
            print("Hier geht es nicht nach oben.")
    elif eingabe == "runter":
        if raum == "gang":
            raum = "flur"
            zeige_raum(raum)
        else:
            print("Hier geht es nicht nach unten.")
    elif eingabe.startswith("geh "):
        wohin = eingabe.replace("geh ", "")
        if raum == "gang" and wohin in zimmer_namen():
            raum = wohin
            zeige_raum(raum)
        else:
            print("Hier gibt es keine Tür zu", wohin + ".")
    elif eingabe == "raus":
        if raum in zimmer_namen():
            raum = "gang"
            zeige_raum(raum)
        else:
            print("Raus? Hier gibt es keinen Raum im ersten Stock.")
    elif eingabe == "hilfe":
        hilfe()
    elif eingabe == "schau":
        zeige_raum(raum)
    elif eingabe == "zeige":
        zeige_rucksack(punkte, zuege)
    elif eingabe == "karte":
        if "karte" in rucksack:
            print("Die Karte zeigt von hier:", aufzaehlen(ausgaenge(raum)) + ".")
        else:
            print("Du hast keine Karte. In der Bibliothek gibt es alles, auch Karten.")
    elif eingabe in ["norden", "osten", "süden", "westen"] or eingabe.startswith("gehe "):
        richtung = eingabe.replace("gehe ", "")
        vorher = raum
        raum = gehe(raum, richtung)
        if raum != vorher:
            if raum == "bibliothek":
                ruhe = ruhe + 1
                laut = ""
                for i in range(ruhe):
                    laut = laut + "RUHE! "
                print("Das Plakat hängt da.", laut)
            if raum == "keller" and random.randint(1, 6) == 1:
                print("KLACK. Die Sicherung fliegt raus. Deine Lampe flackert. Das kostet dich 2 Züge.")
                zuege = zuege - 2
            if random.randint(1, 5) == 1:
                kater(raum)
            zeige_raum(raum)
    elif eingabe.startswith("nimm "):
        punkte = punkte + nimm(eingabe.replace("nimm ", ""), raum)
    elif eingabe.startswith("warte "):
        zahl = eingabe.replace("warte ", "")
        if zahl.isdigit():
            n = int(zahl)
            zuege = zuege - n
            sekunden = sekunden + n * 45
            print("Du wartest", n, "Züge. Nichts passiert. Irgendwo tropft es.")
        else:
            print("Warten geht nur mit einer Zahl, zum Beispiel: warte 3")
    elif eingabe.startswith("lege "):
        lege(eingabe.replace("lege ", ""), raum)
    elif eingabe.startswith("benutze "):
        punkte = punkte + benutze(eingabe.replace("benutze ", ""), raum)
    elif eingabe.startswith("iss "):
        zuege = zuege + iss(eingabe.replace("iss ", ""))
    else:
        print("Das verstehe ich nicht. Tippe hilfe.")

print()
if raum == "tor":
    punkte = punkte + zuege * 2
    print("Du schließt das Tor auf und stehst draußen. Die Nacht ist kalt und wunderbar.")
    if "stick" in rucksack:
        print("Und der Stick ist dabei. Morgen wird ein guter Tag.")
    else:
        print("Der Stick liegt noch im Informatikraum. Morgen wird ein langer Tag.")
elif zuege <= 0:
    print("Die Lampe wird schwach, flackert und geht aus. Du sitzt im Dunkeln, bis der Hausmeister kommt.")

minuten = sekunden // 60
rest = sekunden % 60
print("Spielzeit:", minuten, "min", rest, "s -", punkte, "Punkte")
if minuten > 0:
    print("Das sind", round(punkte / minuten, 1), "Punkte pro Minute.")
print("Deine Sterne:", sterne(punkte))
