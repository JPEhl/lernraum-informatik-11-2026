# turnhalle.py -- von Rasmus und Zeynep
name = "turnhalle"
trainer = "Herr Albers, Handy 0151 2345 6789"


def beschreibung() -> str:
    return "Die Turnhalle. Es riecht nach Bodenwachs."


def befehle() -> list[str]:
    return ["pfeife", "ruf den trainer"]


def reagiere(befehl: str, rucksack: list[str]) -> str:
    if befehl == "pfeife":
        print("TRRRT! Niemand rennt.")
    elif befehl == "ruf den trainer":
        return "Du rufst " + trainer + " an. Mailbox."
    return "Die Turnhalle hallt."
