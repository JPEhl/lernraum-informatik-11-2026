# aula.py -- der Raum von Kofi und Jule,
# nach der Verabredung neu geschrieben.
# Lesen ja, ändern nicht.

name = "aula"
dinge = ["mikrofon"]


def beschreibung() -> str:
    """Was man sieht, wenn man hereinkommt."""
    return "Die Aula. 400 leere Stühle schauen zur Bühne."


def befehle() -> list[str]:
    """Was man hier tun kann."""
    return ["sprich <satz>", "nimm mikrofon"]


def antwort(befehl: str, rucksack: list[str]) -> str:
    """Die Antwort der Aula auf einen Befehl."""
    if befehl.startswith("sprich "):
        satz = befehl.replace("sprich ", "")
        if "mikrofon" in rucksack:
            return "Aus allen Lautsprechern: " + satz + "! Niemand klatscht."
        return "Du sagst: " + satz + ". Die Stühle hören nicht zu."
    elif befehl == "nimm mikrofon":
        if "mikrofon" not in dinge:
            return "Hier liegt kein Mikrofon mehr."
        elif len(rucksack) >= 6:
            return "Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht."
        dinge.remove("mikrofon")
        rucksack.append("mikrofon")
        return "Du nimmst das Mikrofon. Es rauscht beleidigt."
    return "In der Aula hallt es: " + befehl + " ... " + befehl + " ..."
