# musikraum.py -- Expertenaufgabe 8: der
# Musikraum aus der Expertenspur, als Modul
# nach der Verabredung.
