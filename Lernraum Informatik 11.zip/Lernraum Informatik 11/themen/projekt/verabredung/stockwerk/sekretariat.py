# sekretariat.py -- der Raum von Farida
# und Malte, gebaut nach der Verabredung.
# Lesen ja, ändern nicht.

name = "sekretariat"
dinge = ["stempel"]


def beschreibung() -> str:
    """Was man sieht, wenn man hereinkommt."""
    text = "Das Sekretariat. Ein Telefon, ein Schrank voller Akten -- abgeschlossen. Gut so."
    if "stempel" in dinge:
        text = text + " Auf dem Tisch liegt ein Stempel."
    return text


def befehle() -> list[str]:
    """Was man hier tun kann."""
    return ["benutze telefon", "nimm stempel", "stemple"]


def antwort(befehl: str, rucksack: list[str]) -> str:
    """Die Antwort des Sekretariats auf einen Befehl."""
    if befehl == "benutze telefon":
        return "Eine Ansage: Sie werden verbunden. Sie werden nicht verbunden."
    elif befehl == "nimm stempel":
        if "stempel" not in dinge:
            return "Hier liegt kein Stempel mehr."
        elif len(rucksack) >= 6:
            return "Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht."
        dinge.remove("stempel")
        rucksack.append("stempel")
        return "Du nimmst den Stempel. Er riecht nach Tinte und Macht."
    elif befehl == "stemple":
        if "stempel" in rucksack:
            return "Du stempelst deinen Arm: GENEHMIGT."
        return "Womit denn?"
    return "Im Sekretariat versteht das niemand. Bitte ein Formular ausfüllen."
