# meinraum.py -- euer Raum im ersten Stock.
# Was hier stehen muss, sagt die Verabredung
# (Reiter Erklärung). Vorbild: sekretariat.py.
# Beim Zusammenführen bekommt die Datei den
# Namen eures Raums.
