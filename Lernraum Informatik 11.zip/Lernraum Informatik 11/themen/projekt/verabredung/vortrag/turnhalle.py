# turnhalle.py -- der Raum von Rasmus und Zeynep
name = "turnhalle"


def beschreibung():
    return "Die Turnhalle. Es riecht nach Bodenwachs."


def antwort(rucksack, befehl):
    return "In der Turnhalle hallt es: " + str(befehl)
