# So bindet das Spiel die Räume im ersten Stock ein.
import sekretariat
import kunstraum

oben = [sekretariat, kunstraum]

for zimmer in oben:
    print(zimmer.name, "--", zimmer.beschreibung())
print(kunstraum.antwort("male", ["lampe"]))
