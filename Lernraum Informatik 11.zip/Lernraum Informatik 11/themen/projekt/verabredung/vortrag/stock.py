# So fragt das Spiel jeden Raum im ersten Stock.
# aula.py und turnhalle.py haben zwei Paare
# gebaut -- jedes für sich.
import aula
import turnhalle

print(aula.antwort("schau", ["lampe"]))
print(turnhalle.antwort("schau", ["lampe"]))
