# kunst.py -- der Kunstraum, nach der Verabredung.
name = "kunstraum"
dinge = ["pinsel"]


def beschreibung() -> str:
    return "Der Kunstraum. Auf der Staffelei: ein halber Kater."


def befehle() -> list[str]:
    return ["male", "nimm pinsel"]


def antwort(befehl: str, rucksack: list[str]) -> str:
    if befehl == "male":
        return "Ein Strich mehr. Der Kater sieht jetzt aus wie ein Hund."
    elif befehl == "nimm pinsel":
        if "pinsel" not in dinge:
            return "Hier liegt kein Pinsel mehr."
        elif len(rucksack) >= 6:
            return "Dein Rucksack ist voll."
        dinge.remove("pinsel")
        rucksack.append("pinsel")
        return "Du nimmst den Pinsel. Er tropft."
    return "Im Kunstraum sagt dazu niemand etwas. Kunst eben."


# Die Probe: so, wie das Spiel fragt
print(beschreibung())
print(antwort("male", ["lampe"]))
print(antwort("tanze", ["lampe"]))
rucksack = ["lampe"]
print(antwort("nimm pinsel", rucksack))
print(rucksack)
