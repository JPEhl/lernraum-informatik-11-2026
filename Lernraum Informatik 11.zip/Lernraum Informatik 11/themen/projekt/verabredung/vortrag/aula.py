# aula.py -- der Raum von Kofi und Jule
name = "aula"


def beschreibung():
    print("Die Aula. 400 leere Stühle schauen zur Bühne.")


def antwort(befehl, rucksack):
    print("Die Aula. 400 leere Stühle schauen zur Bühne.")
