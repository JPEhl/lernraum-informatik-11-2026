"""Selbstcheck zu "Kryptoanalyse" -- prueft knacken.py (Pflicht: Aufgabe 2; Mehr: Aufgabe 7 und 9).

Die Aufgaben 1, 3, 5 und 8 (an den Tischen der Werkstatt Krypto) prueft die Seite, nicht dieser Check.

Der Check ruft die Funktionen der Klasse SELBST, mit eigenen Texten und Schluesseln -- nie mit Evas Zettel aus der
Datei: Wer den Klartext hinschreibt, besteht nicht (LC2). Die Texte sind lang genug, dass e wirklich der haeufigste
Buchstabe ist (nachgerechnet mit der Rechnung des Checks, _haeufigster).

Je Pruefung eine Sache (LC3): nur Buchstaben · Leerzeichen zaehlen nicht · bei Gleichstand der erste im Alphabet ·
knacke · knacke_mit_wort. Am Start fehlt haeufigster -- genau Aufgabe 2 ★ ist offen (LC1).
"""
import ast
import io
import sys

from pruefen import erwarte, braucht, funktion, quelltext

TITEL = "Kryptoanalyse · Selbstcheck"

ABC = "abcdefghijklmnopqrstuvwxyz"
KEIN_WERT = object()
HINTS = {"verschiebe": "str", "verschluesseln": "str", "entschluesseln": "str", "ersetzen": "str",
         "zaehle": "int", "haeufigster": "str", "knacke": "str", "knacke_mit_wort": "int",
         "knacke_alle": "list[str]", "knacke_drei": "str"}

LANG = [
    "der bus faehrt um sieben, wir treffen uns vor der eisdiele und gehen dann gemeinsam zur aula hinueber",
    "eine gitarre, zwei verstaerker und ein ersatzkabel, mehr passt leider nicht in den kofferraum der lehrerin",
    "wer den text lesen kann, sollte ihn nicht weitererzaehlen, denn sonst ist die ueberraschung dahin",
]


def _caesar(text, k):
    return "".join(ABC[(ABC.index(z) + k) % 26] if z in ABC else z for z in text.lower())


def _haeufigster(text):
    beste = "a"
    for b in ABC:
        if text.count(b) > text.count(beste):
            beste = b
    return beste


def _rufen(name, *argumente):
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
    return wert, puffer.getvalue(), fehler


def _kurz(a):
    t = repr(a)
    return t if len(t) <= 40 else t[:37] + "…'"


def _gleich(name, argumente, soll, wofuer=""):
    wert, gedruckt, fehler = _rufen(name, *argumente)
    aufruf = "%s(%s)" % (name, ", ".join(_kurz(a) for a in argumente))
    erwarte(fehler is None, "%s bricht ab: %s" % (aufruf, fehler))
    erwarte(wert is not None, "%s gibt nichts zurück (None)%s." % (
        aufruf, " -- sie druckt, statt zurückzugeben" if gedruckt.strip() else ""))
    erwarte(wert == soll, "%s liefert %s%s." % (aufruf, _kurz(wert), wofuer))


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _haeufigster_geht():
    if funktion("haeufigster") is None:
        return False
    w, _, f = _rufen("haeufigster", "xyy")
    return f is None and w == "y"


def _nur_buchstaben_geht():
    if not _haeufigster_geht():
        return False
    w, _, f = _rufen("haeufigster", "x   y   y")
    return f is None and w == "y"


def _haeufigster_ganz():
    """Fuer braucht(): haeufigster besteht alle drei Pruefungen der Aufgabe 2 ★ -- sonst warten knacke und Co."""
    if not _nur_buchstaben_geht():
        return False
    for text in ("cbcb", "zzaa", "abcdefghm"):
        w, _, f = _rufen("haeufigster", text)
        if f is not None or w != _haeufigster(text):
            return False
    return True


def _knacke_geht():
    if funktion("knacke") is None:
        return False
    w, _, f = _rufen("knacke", _caesar(LANG[0], 3))
    return f is None and w == LANG[0]


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_caesar():
    """Grundlage · Die Funktionen aus „Caesar-Verschlüsselung“ sind noch da"""
    for name in ("verschiebe", "verschluesseln", "entschluesseln"):
        erwarte(funktion(name) is not None, "Die Funktion %s() aus „Caesar-Verschlüsselung“ fehlt in knacken.py." % name)
    _gleich("entschluesseln", (_caesar("probe", 5), 5), "probe")


# ── Aufgabe 2 ★ · haeufigster ────────────────────────────────────────────

def pruefe_20_haeufigster():
    """Aufgabe 2 · haeufigster() findet den häufigsten Buchstaben"""
    erwarte(funktion("haeufigster") is not None,
            "Noch keine Funktion haeufigster(text) in knacken.py -- das ist Aufgabe 2 ★.")
    for text in ("eeeab", "qrrrt", "zzaz", "mnmom"):
        _gleich("haeufigster", (text,), _haeufigster(text))


def pruefe_21_nur_buchstaben():
    """Aufgabe 2 · Leerzeichen und Satzzeichen zählen nicht mit"""
    braucht(_haeufigster_geht())
    for text in ("x   y   y", "a, b. b!!! ...", "  kk  "):
        _gleich("haeufigster", (text,), _haeufigster(text),
                " -- es zählt nur, was im Alphabet steht")


def pruefe_22_gleichstand():
    """Aufgabe 2 · Bei Gleichstand gewinnt, was im Alphabet zuerst steht"""
    braucht(_nur_buchstaben_geht())
    for text in ("cbcb", "zzaa", "mn", "abcdefghm"):
        _gleich("haeufigster", (text,), _haeufigster(text),
                " -- bei Gleichstand bleibt der Buchstabe, der zuerst kam; nur ein größerer Zähler löst ihn ab")


# ── Aufgabe 2 ★★ · knacke ────────────────────────────────────────────────

def pruefe_23_knacke():
    """Aufgabe 2 ★★ · knacke() liefert den Klartext eines Caesar-Zettels"""
    braucht(funktion("knacke") is not None)
    braucht(_haeufigster_ganz())
    for text, k in ((LANG[0], 3), (LANG[1], 17), (LANG[2], 25), (LANG[1], 0)):
        _gleich("knacke", (_caesar(text, k),), text, " (verschlüsselt war mit %d)" % k)


# ── Aufgabe 2 ★★★ · knacke_mit_wort ──────────────────────────────────────

def pruefe_24_mit_wort():
    """Aufgabe 2 ★★★ · knacke_mit_wort() findet den Schlüssel über ein bekanntes Wort"""
    braucht(funktion("knacke_mit_wort") is not None)
    for text, k, wort in (("treffpunkt ist die aula", 9, "aula"), ("ruf an", 3, "ruf"), ("ja", 14, "ja")):
        _gleich("knacke_mit_wort", (_caesar(text, k), wort), k)
    _gleich("knacke_mit_wort", (_caesar("bis gleich", 4), "konzert"), -1, " -- das Wort steht bei keinem Schlüssel da")


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_29_hints():
    """Hinweis · Jedes def mit Type Hint (kein Stern)"""
    braucht(funktion("haeufigster") is not None)
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None:
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer): %s. Es läuft auch ohne; vereinbart ist es trotzdem."
            % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 7 · Mehr: knacke_alle ────────────────────────────────────────

def pruefe_50_knacke_alle():
    """Aufgabe 7 · knacke_alle() knackt jeden Zettel eines Stapels"""
    braucht(funktion("knacke_alle") is not None)
    braucht(_haeufigster_ganz())
    braucht(funktion("knacke") is None or _knacke_geht())
    _gleich("knacke_alle", ([],), [], " -- ein leerer Stapel gibt eine leere Liste")
    stapel = [_caesar(LANG[2], 7), _caesar(LANG[0], 20)]
    vorher = list(stapel)
    _gleich("knacke_alle", (stapel,), [LANG[2], LANG[0]])
    erwarte(stapel == vorher, "knacke_alle() ändert den Stapel, den sie bekommt -- sie soll eine neue Liste zurückgeben.")


# ── Aufgabe 9 · Mehr: drei Schluessel im Wechsel (Expertenaufgabe) ───────

def _drei(text, ks):
    raus, i = "", 0
    for z in text:
        if z in ABC:
            raus += ABC[(ABC.index(z) + ks[i % 3]) % 26]
            i += 1
        else:
            raus += z
    return raus


# Lang genug, dass in jeder der drei Gruppen e der haeufigste Buchstabe ist (nachgezaehlt 17.11.2026; ein Text, bei
# dem eine Gruppe n vorn hat oder e nur knapp, wuerde auch die Loesung rot machen: Ein Gleichstand loest sich nach
# dem Verschieben anders auf).
DREI = [
    ("wenn der regen nachlaesst, stellen wir die lautsprecher neben die treppe, denn dort hoeren alle, die aus den "
     "klassen kommen, sofort die ersten takte, und keiner der lehrer wird die feier noch verhindern wollen, wenn erst "
     "einmal der refrain erklingt und die ganze schule mitsingt, bis es dunkel wird und dann ist es vorbei, meint der "
     "hausmeister", (3, 11, 20)),
    ("es ist eine sehr seltene ehre, dass der chor neben der band stehen darf, denn eigentlich singen "
     "die beiden nie gemeinsam, aber diesmal werden sie es wagen und eine ganze stunde lang zusammen "
     "auftreten, bevor der hausmeister die buehne wieder abbaut", (5, 0, 17)),
]


def pruefe_70_drei():
    """Aufgabe 9 ★★★★ · knacke_drei() knackt drei Schlüssel im Wechsel"""
    braucht(funktion("knacke_drei") is not None)
    braucht(_haeufigster_ganz())
    for text, ks in DREI:
        _gleich("knacke_drei", (_drei(text, ks),), text, " (verschlüsselt war mit %d, %d, %d im Wechsel)" % ks)
