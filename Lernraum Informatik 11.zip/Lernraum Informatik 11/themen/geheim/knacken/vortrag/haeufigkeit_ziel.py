# Eva zählt -- welcher Buchstabe kommt am häufigsten?
ABC = "abcdefghijklmnopqrstuvwxyz"


def verschiebe(zeichen: str, schluessel: int) -> str:
    platz = ABC.index(zeichen)
    return ABC[(platz + schluessel) % 26]


def verschluesseln(text: str, schluessel: int) -> str:
    geheim = ""
    for zeichen in text.lower():
        if zeichen in ABC:
            geheim = geheim + verschiebe(zeichen, schluessel)
        else:
            geheim = geheim + zeichen
    return geheim


def entschluesseln(geheimtext: str, schluessel: int) -> str:
    return verschluesseln(geheimtext, 26 - schluessel)


def zaehle(text: str, buchstabe: str) -> int:
    anzahl = 0
    for zeichen in text:
        if zeichen == buchstabe:
            anzahl = anzahl + 1
    return anzahl


def haeufigster(text: str) -> str:
    haeufigster_bisher = ABC[0]
    for buchstabe in ABC:
        if zaehle(text, buchstabe) > zaehle(text, haeufigster_bisher):
            haeufigster_bisher = buchstabe
    return haeufigster_bisher


zettel = "dboppox xkmr nob zbylo rsxdob nob leorxo, lbsxqd nso xoeox cksdox wsd"
print(haeufigster(zettel))
schluessel = (ABC.index(haeufigster(zettel)) - ABC.index("e")) % 26
print(schluessel)
print(entschluesseln(zettel, schluessel))
