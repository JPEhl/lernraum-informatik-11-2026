# Eva probiert -- ein Zettel, alle Schlüssel
ABC = "abcdefghijklmnopqrstuvwxyz"


def verschiebe(zeichen: str, schluessel: int) -> str:
    platz = ABC.index(zeichen)
    return ABC[(platz + schluessel) % 26]


def verschluesseln(text: str, schluessel: int) -> str:
    geheim = ""
    for zeichen in text.lower():
        if zeichen in ABC:
            geheim = geheim + verschiebe(zeichen, schluessel)
        else:
            geheim = geheim + zeichen
    return geheim


def entschluesseln(geheimtext: str, schluessel: int) -> str:
    return verschluesseln(geheimtext, 26 - schluessel)


zettel = "dboppox xkmr nob zbylo rsxdob nob leorxo, lbsxqd nso xoeox cksdox wsd"
