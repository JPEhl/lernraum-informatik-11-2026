# Geheime Nachrichten -- knacken.py
# Daran arbeitet ihr in diesem Thema.
#
# Oben stehen die Funktionen aus
# "Caesar-Verschlüsselung". Ihr seid
# jetzt Eva: Ihr habt einen Zettel, aber
# keinen Schlüssel.

ABC = "abcdefghijklmnopqrstuvwxyz"


def verschiebe(zeichen: str, schluessel: int) -> str:
    platz = ABC.index(zeichen)
    return ABC[(platz + schluessel) % 26]


def verschluesseln(text: str, schluessel: int) -> str:
    geheim = ""
    for zeichen in text.lower():
        if zeichen in ABC:
            geheim = geheim + verschiebe(zeichen, schluessel)
        else:
            geheim = geheim + zeichen
    return geheim


def entschluesseln(geheimtext: str, schluessel: int) -> str:
    return verschluesseln(geheimtext, 26 - schluessel)


def ersetzen(text: str, geheimalphabet: str) -> str:
    geheim = ""
    for zeichen in text.lower():
        if zeichen in ABC:
            geheim = geheim + geheimalphabet[ABC.index(zeichen)]
        else:
            geheim = geheim + zeichen
    return geheim


zettel = "opc lfqectee mprtyye ylns opc alfdp, mctyre otp vlmpw xte fyo otp ypfp rtelccp"
print(zettel)
