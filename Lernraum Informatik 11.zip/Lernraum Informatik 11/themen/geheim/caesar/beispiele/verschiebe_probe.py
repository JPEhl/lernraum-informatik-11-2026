ABC = "abcdefghijklmnopqrstuvwxyz"


def verschiebe(zeichen: str, schluessel: int) -> str:
    platz = ABC.index(zeichen)
    return ABC[(platz + schluessel) % 26]


print(verschiebe("p", 3))
print(verschiebe("y", 3))
print(verschiebe("z", 1))
