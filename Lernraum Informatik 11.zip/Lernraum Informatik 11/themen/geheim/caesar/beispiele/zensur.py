ABC = "abcdefghijklmnopqrstuvwxyz"
text = "um acht!"
neu = ""
for zeichen in text:
    if zeichen in ABC:
        neu = neu + "*"
    else:
        neu = neu + zeichen
print(neu)
