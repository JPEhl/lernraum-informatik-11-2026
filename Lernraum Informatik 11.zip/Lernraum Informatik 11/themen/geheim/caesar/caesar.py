# Geheime Nachrichten -- caesar.py
# Daran arbeitet ihr in diesem Thema.
#
# Oben steht verschiebe() aus dem Vortrag:
# ein Buchstabe, um den Schlüssel weiter.
# Ihr baut daraus Funktionen für ganze
# Texte. Umlaute schreibt ihr als ae, oe,
# ue -- sie stehen nicht im Alphabet.

ABC = "abcdefghijklmnopqrstuvwxyz"


def verschiebe(zeichen: str, schluessel: int) -> str:
    platz = ABC.index(zeichen)
    return ABC[(platz + schluessel) % 26]


print(verschiebe("y", 3))
