"""Selbstcheck zu "Caesar-Verschlüsselung" -- prueft caesar.py (Pflicht: Aufgabe 2; Mehr: Aufgabe 5 und 7).

Aufgabe 1 (an der Scheibe) und Aufgabe 6 (im Labor) prueft die Seite, nicht dieser Check -- die erste Pflicht mit
einer Pruefung ist darum Aufgabe 2 (LC1).

Kein Spiel, keine Eingabe: Der Check ruft die Funktionen der Klasse SELBST, mit eigenen Texten und Schluesseln, und
sieht nach, was zurueckkommt -- und ob dabei etwas gedruckt wurde (eine Funktion, die druckt statt zurueckzugeben,
liefert None). Die Probe aus der Aufgabe ("Auftritt am Freitag …") ist bewusst NICHT dabei: Wer die Antwort
hinschreibt, besteht nicht (LC2).

Je Pruefung eine Sache (LC3): Buchstaben · andere Zeichen bleiben · Grossbuchstaben (Rueckblick *Eingabe und Text*) ·
zurueckgeben statt drucken. Am Start fehlt verschluesseln -- genau Aufgabe 2 ★ ist offen, alles andere „noch nicht
dran“ (LC1).
"""
import ast
import io
import sys

from pruefen import erwarte, braucht, funktion, quelltext

TITEL = "Caesar-Verschlüsselung · Selbstcheck"

ABC = "abcdefghijklmnopqrstuvwxyz"
KEIN_WERT = object()
HINTS = {"verschiebe": "str", "verschluesseln": "str", "entschluesseln": "str", "ersetzen": "str",
         "schluesselalphabet": "str", "vigenere": "str"}


def _caesar(text, k):
    """So soll es sein -- die Rechnung des Checks, unabhaengig von der Klasse."""
    raus = ""
    for z in text.lower():
        raus += ABC[(ABC.index(z) + k) % 26] if z in ABC else z
    return raus


def _rufen(name, *argumente):
    """Die Funktion `name` mit diesen Argumenten rufen. Gibt (wert, gedruckt, fehler)."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
    return wert, puffer.getvalue(), fehler


def _aufruf(name, *argumente):
    return "%s(%s)" % (name, ", ".join(repr(a) for a in argumente))


def _gleich(name, argumente, soll):
    """Ruft name(*argumente) und meldet, woran es haengt -- nie die Loesung."""
    wert, gedruckt, fehler = _rufen(name, *argumente)
    aufruf = _aufruf(name, *argumente)
    erwarte(fehler is None, "%s bricht ab: %s" % (aufruf, fehler))
    erwarte(wert is not None, "%s gibt nichts zurück (None)%s." % (
        aufruf, " -- sie druckt, statt zurückzugeben" if gedruckt.strip() else ""))
    erwarte(wert == soll, "%s liefert %r." % (aufruf, wert))


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _ruft(name):
    gerufen = set()
    for n, k in _defs():
        if n == name:
            for c in ast.walk(k):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Name):
                    gerufen.add(c.func.id)
    return gerufen


def _hat_schleife(name):
    for n, k in _defs():
        if n == name:
            return any(isinstance(c, (ast.For, ast.While)) for c in ast.walk(k))
    return False


def _buchstaben_gehen():
    """Fuer braucht(): verschluesseln stimmt bei Kleinbuchstaben ohne Leerzeichen."""
    if funktion("verschluesseln") is None:
        return False
    wert, _, fehler = _rufen("verschluesseln", "bao", 1)
    return fehler is None and wert == "cbp"


def _verschluesseln_geht():
    """Fuer braucht(): verschluesseln stimmt bei Kleinbuchstaben mit Leerzeichen."""
    if funktion("verschluesseln") is None:
        return False
    wert, _, fehler = _rufen("verschluesseln", "ab yz", 3)
    return fehler is None and wert == "de bc"


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_verschiebe():
    """Grundlage · verschiebe() aus dem Vortrag ist noch da und schiebt im Kreis"""
    erwarte(funktion("verschiebe") is not None, "Die Funktion verschiebe() aus dem Vortrag fehlt in caesar.py.")
    _gleich("verschiebe", ("y", 3), "b")


# ── Aufgabe 2 ★ · verschluesseln ─────────────────────────────────────────

def pruefe_20_buchstaben():
    """Aufgabe 2 · verschluesseln() schiebt jeden Buchstaben um den Schlüssel"""
    erwarte(funktion("verschluesseln") is not None,
            "Noch keine Funktion verschluesseln(text, schluessel) in caesar.py -- das ist Aufgabe 2 ★.")
    for text, k in (("bao", 1), ("zug", 3), ("eva", 0), ("amara", 25)):
        _gleich("verschluesseln", (text, k), _caesar(text, k))


def pruefe_21_andere_zeichen():
    """Aufgabe 2 · Leerzeichen, Satzzeichen und Ziffern bleiben stehen"""
    braucht(_buchstaben_gehen())
    for text, k in (("um acht!", 3), ("probe 2, aula", 10)):
        _gleich("verschluesseln", (text, k), _caesar(text, k))


def pruefe_22_gross():
    """Aufgabe 2 · Großbuchstaben werden klein und dann verschoben"""
    braucht(_verschluesseln_geht())
    for text, k in (("Bao", 2), ("ZUGABE in der Aula", 4)):
        _gleich("verschluesseln", (text, k), _caesar(text, k))


def pruefe_23_eine_stelle():
    """Aufgabe 2 · verschluesseln() benutzt verschiebe()"""
    braucht(_verschluesseln_geht())
    erwarte("verschiebe" in _ruft("verschluesseln"),
            "verschluesseln() ruft verschiebe() nicht -- wie ein Buchstabe geschoben wird, steht schon dort.")


# ── Aufgabe 2 ★★ · entschluesseln ────────────────────────────────────────

def pruefe_24_entschluesseln():
    """Aufgabe 2 ★★ · entschluesseln() holt den Klartext zurück"""
    braucht(funktion("entschluesseln") is not None)
    braucht(_verschluesseln_geht())
    for text, k in (("bis gleich, bao", 7), ("zugabe", 3), ("eva hoert mit", 25), ("aula", 0)):
        _gleich("entschluesseln", (_caesar(text, k), k), text)


def pruefe_25_ohne_eigene_schleife():
    """Aufgabe 2 ★★ · entschluesseln() ruft verschluesseln() -- kein zweites Verfahren"""
    braucht(funktion("entschluesseln") is not None)
    erwarte("verschluesseln" in _ruft("entschluesseln") and not _hat_schleife("entschluesseln"),
            "entschluesseln() hat eine eigene Schleife oder ruft verschluesseln() nicht -- zurückschieben ist "
            "dasselbe Verfahren mit einem anderen Schlüssel.")


# ── Aufgabe 2 ★★★ · ersetzen ─────────────────────────────────────────────

def pruefe_26_ersetzen():
    """Aufgabe 2 ★★★ · ersetzen() setzt ein beliebiges Geheimalphabet ein"""
    braucht(funktion("ersetzen") is not None)
    rueckwaerts = ABC[::-1]
    verschoben = ABC[5:] + ABC[:5]
    _gleich("ersetzen", ("abc xyz!", rueckwaerts), "zyx cba!")
    _gleich("ersetzen", ("Eva liest mit.", verschoben), _caesar("Eva liest mit.", 5))
    eigenes = "mnbvcxylkjhgfdsapoiuztrewq"
    soll = "".join(eigenes[ABC.index(z)] if z in ABC else z for z in "aula um acht")
    _gleich("ersetzen", ("Aula um acht", eigenes), soll)


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_29_hints():
    """Hinweis · Jedes def mit Type Hint (kein Stern)"""
    braucht(funktion("verschluesseln") is not None)
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None:
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer): %s. Es läuft auch ohne; vereinbart ist es trotzdem."
            % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 5 · Mehr: ein Schlüsselwort ──────────────────────────────────

def _schluesselalphabet(wort):
    raus = ""
    for z in wort.lower() + ABC:
        if z in ABC and z not in raus:
            raus += z
    return raus


def pruefe_50_schluesselalphabet():
    """Aufgabe 5 ★★★ · schluesselalphabet() baut das Geheimalphabet aus einem Wort"""
    braucht(funktion("schluesselalphabet") is not None)
    for wort in ("band", "Lötkolben", "anna", "zz top"):
        _gleich("schluesselalphabet", (wort,), _schluesselalphabet(wort))


# ── Aufgabe 7 · Mehr: Vigenère (Expertenaufgabe) ─────────────────────────

def _vigenere(text, wort):
    raus, i = "", 0
    for z in text.lower():
        if z in ABC:
            raus += ABC[(ABC.index(z) + ABC.index(wort[i % len(wort)])) % 26]
            i += 1
        else:
            raus += z
    return raus


def pruefe_60_vigenere():
    """Aufgabe 7 ★★★★ · vigenere() schiebt jeden Buchstaben um den nächsten Buchstaben des Worts"""
    braucht(funktion("vigenere") is not None)
    for text, wort in (("aula um acht", "band"), ("Eva hoert mit!", "rot"), ("zugabe", "z"), ("ab cd", "bc")):
        _gleich("vigenere", (text, wort), _vigenere(text, wort))
