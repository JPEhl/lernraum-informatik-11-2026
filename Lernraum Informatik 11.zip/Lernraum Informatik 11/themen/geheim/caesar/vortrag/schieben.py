# Drei Buchstaben weiter -- ein Buchstabe nach dem anderen
ABC = "abcdefghijklmnopqrstuvwxyz"
