def potenz_rest(basis: int, exponent: int, teiler: int) -> int:
    ergebnis = 1
    for i in range(exponent):
        ergebnis = ergebnis * basis % teiler
    return ergebnis


for exponent in range(1, 8):
    print(exponent, potenz_rest(5, exponent, 23))
