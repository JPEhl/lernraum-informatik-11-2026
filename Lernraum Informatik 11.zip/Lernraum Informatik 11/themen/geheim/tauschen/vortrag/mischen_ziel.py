# Ein Geheimnis vor allen Ohren -- mischen mit Zahlen
TEILER = 23
BASIS = 5


def potenz_rest(basis: int, exponent: int, teiler: int) -> int:
    ergebnis = 1
    for i in range(exponent):
        ergebnis = ergebnis * basis % teiler
    return ergebnis


geheim_amara = 6
von_amara = potenz_rest(BASIS, geheim_amara, TEILER)
print("Amara schickt:", von_amara)
geheim_bao = 9
von_bao = potenz_rest(BASIS, geheim_bao, TEILER)
print("Bao schickt:", von_bao)
print("Amara rechnet:", potenz_rest(von_bao, geheim_amara, TEILER))
print("Bao rechnet:", potenz_rest(von_amara, geheim_bao, TEILER))
