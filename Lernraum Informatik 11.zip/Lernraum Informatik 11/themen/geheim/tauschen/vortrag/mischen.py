# Ein Geheimnis vor allen Ohren -- mischen mit Zahlen
TEILER = 23
BASIS = 5
