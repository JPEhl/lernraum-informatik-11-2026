# Geheime Nachrichten -- tauschen.py
# Daran arbeitet ihr in diesem Thema.
#
# Oben stehen die Funktionen aus
# "Caesar-Verschlüsselung". Amara und Bao
# brauchen einen neuen Schlüssel -- und
# jede Zahl geht über Evas Router.

ABC = "abcdefghijklmnopqrstuvwxyz"


def verschiebe(zeichen: str, schluessel: int) -> str:
    platz = ABC.index(zeichen)
    return ABC[(platz + schluessel) % 26]


def verschluesseln(text: str, schluessel: int) -> str:
    geheim = ""
    for zeichen in text.lower():
        if zeichen in ABC:
            geheim = geheim + verschiebe(zeichen, schluessel)
        else:
            geheim = geheim + zeichen
    return geheim


def entschluesseln(geheimtext: str, schluessel: int) -> str:
    return verschluesseln(geheimtext, 26 - schluessel)


TEILER = 23
BASIS = 5
geheim_amara = 6
geheim_bao = 9
