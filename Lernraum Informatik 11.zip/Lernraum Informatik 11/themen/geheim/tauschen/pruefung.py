"""Selbstcheck zu "Schlüsseltausch nach Diffie-Hellman" -- prueft tauschen.py (Pflicht: Aufgabe 2 und 5 ★★; Mehr:
Aufgabe 9). Die Aufgaben 1 und 8 (an den Tischen der Werkstatt Krypto) prueft die Seite, nicht dieser Check.

Der Check ruft die Funktionen der Klasse SELBST, mit eigenen Zahlen -- auch grossen (Teiler 1 000 003), damit ein
Programm, das die 23 fest eingebaut hat, auffaellt (LC2). Je Pruefung eine Sache (LC3): kleine Zahlen · Exponent 0 ·
grosser Teiler · caesar_schluessel · Evas Suche · (Mehr) schnell potenzieren.

Aufgabe 9 (Expertenaufgabe) ZAEHLT die Malnahmen (LC5, „Aufwand zaehlen“): Die Basis kommt als Zahl hinein, die jedes
Malnehmen mitschreibt (_Zahl); `**` und `pow` sind im Rumpf verboten -- sonst rechnete Python ungezaehlt.
Am Start fehlt potenz_rest -- genau Aufgabe 2 ★ ist offen (LC1).
"""
import ast
import io
import sys

from pruefen import erwarte, braucht, funktion, quelltext

TITEL = "Schlüsseltausch nach Diffie-Hellman · Selbstcheck"

KEIN_WERT = object()
HINTS = {"verschiebe": "str", "verschluesseln": "str", "entschluesseln": "str", "potenz_rest": "int",
         "caesar_schluessel": "int", "finde_geheimzahl": "int", "potenz_schnell": "int"}


def _rufen(name, *argumente):
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
    return wert, puffer.getvalue(), fehler


def _gleich(name, argumente, soll, wofuer=""):
    wert, gedruckt, fehler = _rufen(name, *argumente)
    aufruf = "%s(%s)" % (name, ", ".join(repr(int(a)) for a in argumente))
    erwarte(fehler is None, "%s bricht ab: %s" % (aufruf, fehler))
    erwarte(wert is not None, "%s gibt nichts zurück (None)%s." % (
        aufruf, " -- sie druckt, statt zurückzugeben" if gedruckt.strip() else ""))
    erwarte(wert == soll, "%s liefert %r%s." % (aufruf, wert, wofuer))


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _rumpf(name):
    for n, k in _defs():
        if n == name:
            return k
    return None


def _ruft(name):
    k = _rumpf(name)
    return set() if k is None else {c.func.id for c in ast.walk(k) if isinstance(c, ast.Call) and isinstance(c.func, ast.Name)}


def _potenz_ganz():
    """Fuer braucht(): potenz_rest besteht auch Exponent 0 und einen grossen Teiler."""
    if funktion("potenz_rest") is None:
        return False
    for b, e, t in ((5, 6, 23), (5, 0, 23), (7, 300, 1000003)):
        w, _, f = _rufen("potenz_rest", b, e, t)
        if f is not None or w != pow(b, e, t):
            return False
    return True


def _potenz_geht():
    if funktion("potenz_rest") is None:
        return False
    w, _, f = _rufen("potenz_rest", 5, 6, 23)
    return f is None and w == 8


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_caesar():
    """Grundlage · Die Funktionen aus „Caesar-Verschlüsselung“ sind noch da"""
    for name in ("verschiebe", "verschluesseln", "entschluesseln"):
        erwarte(funktion(name) is not None, "Die Funktion %s() aus „Caesar-Verschlüsselung“ fehlt in tauschen.py." % name)


# ── Aufgabe 2 ★ · potenz_rest ────────────────────────────────────────────

def pruefe_20_potenz():
    """Aufgabe 2 · potenz_rest() mischt: so oft malnehmen, wie der Exponent sagt, Rest behalten"""
    erwarte(funktion("potenz_rest") is not None,
            "Noch keine Funktion potenz_rest(basis, exponent, teiler) in tauschen.py -- das ist Aufgabe 2 ★.")
    for b, e, t in ((5, 6, 23), (5, 1, 23), (7, 2, 23), (3, 5, 23)):
        _gleich("potenz_rest", (b, e, t), pow(b, e, t))


def pruefe_21_null():
    """Aufgabe 2 · Nullmal malgenommen ergibt 1"""
    braucht(_potenz_geht())
    _gleich("potenz_rest", (5, 0, 23), 1, " -- nullmal malgenommen bleibt der Startwert; ein Produkt beginnt bei 1")


def pruefe_22_gross():
    """Aufgabe 2 · Auch mit einem großen Teiler, ohne feste 23"""
    braucht(_potenz_geht())
    for b, e, t in ((3, 4, 7), (2, 10, 1000), (7, 300, 1000003), (123456, 50, 999983)):
        _gleich("potenz_rest", (b, e, t), pow(b, e, t))


# ── Aufgabe 2 ★★ · caesar_schluessel ─────────────────────────────────────

def pruefe_23_caesar_schluessel():
    """Aufgabe 2 ★★ · caesar_schluessel() liefert auf beiden Seiten denselben Schlüssel von 0 bis 25"""
    braucht(funktion("caesar_schluessel") is not None)
    braucht(_potenz_ganz())
    for basis, teiler, a, b in ((5, 23, 6, 9), (2, 101, 37, 58), (3, 1009, 400, 777)):
        von_a, von_b = pow(basis, a, teiler), pow(basis, b, teiler)
        soll = pow(basis, a * b, teiler) % 26
        _gleich("caesar_schluessel", (von_b, a, teiler), soll)
        _gleich("caesar_schluessel", (von_a, b, teiler), soll)
    erwarte("potenz_rest" in _ruft("caesar_schluessel"),
            "caesar_schluessel() ruft potenz_rest() nicht -- gemischt wird schon dort.")


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_29_hints():
    """Hinweis · Jedes def mit Type Hint (kein Stern)"""
    braucht(funktion("potenz_rest") is not None)
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None:
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer): %s. Es läuft auch ohne; vereinbart ist es trotzdem."
            % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 5 ★★ · finde_geheimzahl ──────────────────────────────────────

def _finde(basis, oeffentlich, teiler):
    wert = 1
    for exponent in range(1, teiler):
        wert = wert * basis % teiler
        if wert == oeffentlich:
            return exponent
    return -1


def pruefe_50_finde():
    """Aufgabe 5 ★★ · finde_geheimzahl() findet den ersten passenden Exponenten -- oder -1"""
    braucht(funktion("finde_geheimzahl") is not None)
    for b, o, t in ((5, 8, 23), (5, 11, 23), (2, 1, 7), (3, 13, 101), (2, 3, 7)):
        _gleich("finde_geheimzahl", (b, o, t), _finde(b, o, t))


def pruefe_51_selbst():
    """Aufgabe 5 ★★ · finde_geheimzahl() rechnet selbst weiter, ohne potenz_rest"""
    braucht(funktion("finde_geheimzahl") is not None)
    erwarte("potenz_rest" not in _ruft("finde_geheimzahl"),
            "finde_geheimzahl() ruft potenz_rest() -- die Auflage: selbst weiterrechnen, einmal malnehmen je Versuch.")


# ── Aufgabe 9 · Mehr: schnell potenzieren (Expertenaufgabe) ──────────────

class _Zahl(int):
    """Eine Zahl, die jedes Malnehmen mitschreibt, an dem sie beteiligt ist."""
    zaehler = [0]

    def __mul__(self, other):
        _Zahl.zaehler[0] += 1
        return _Zahl(int(self) * int(other))

    __rmul__ = __mul__

    def __mod__(self, other):
        return _Zahl(int(self) % int(other))

    def __rmod__(self, other):
        return _Zahl(int(other) % int(self))


def pruefe_80_schnell():
    """Aufgabe 9 ★★★★ · potenz_schnell() rechnet richtig und braucht höchstens zwei Malnahmen je Zweierstelle"""
    braucht(funktion("potenz_schnell") is not None)
    k = _rumpf("potenz_schnell")
    verboten = [c for c in ast.walk(k) if (isinstance(c, ast.BinOp) and isinstance(c.op, ast.Pow))
                or (isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == "pow")]
    erwarte(not verboten, "potenz_schnell() benutzt ** oder pow -- die Auflage: selbst malnehmen.")
    for b, e, t in ((5, 6, 23), (7, 1000, 1000003), (3, 123456789, 1000000007), (2, 0, 13)):
        _Zahl.zaehler[0] = 0
        wert, gedruckt, fehler = _rufen("potenz_schnell", _Zahl(b), e, t)
        aufruf = "potenz_schnell(%d, %d, %d)" % (b, e, t)
        erwarte(fehler is None, "%s bricht ab: %s" % (aufruf, fehler))
        erwarte(wert == pow(b, e, t), "%s liefert %r." % (aufruf, None if wert is KEIN_WERT else wert))
        grenze = 2 * e.bit_length()
        erwarte(_Zahl.zaehler[0] <= grenze, "%s nimmt %d-mal mal -- erlaubt sind %d (der Exponent hat %d Stellen im "
                "Zweiersystem)." % (aufruf, _Zahl.zaehler[0], grenze, e.bit_length()))
