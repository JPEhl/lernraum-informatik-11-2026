from pruefen import erwarte, braucht, seite

TITEL = "Der Dokumentbaum · Selbstcheck"

# Fingerabdrücke der Startseiten in gepaecksuche/: Solange eine Seite so ist wie am Anfang, ist ihre Aufgabe
# „noch nicht dran“ -- am Start steht genau EINE Pflichtprüfung aus: die offene Liste in Lissabon.
# Ändert sich ein Starttext, hier neu eintragen:
#   python3 -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1]).read().strip().encode()).hexdigest()[:12])" gepaecksuche/<datei>
START = {"helsinki.html": "80039836e5da", "keflavik.html": "7a6b67656765", "index.html": "9a0cae664a85",
         "tuba.html": "4c73e906dd52"}
STATIONEN = ["checkin.html", "gepaeckband.html", "keflavik.html", "lissabon.html", "helsinki.html", "fundbuero.html"]
REISE = ["checkin.html", "gepaeckband.html", "keflavik.html", "lissabon.html", "helsinki.html", "fundbuero.html"]


def angefangen(name):
    s = seite(name)
    braucht(s.da, "Die Datei %s fehlt im Ordner." % name)
    braucht(s.abdruck != START.get(name), "Noch nicht angefangen.")
    return s


def kinder(k):
    return [c for c in k.kinder if not isinstance(c, str)]


def bau_fehler(name):
    """Was am Bau der Station nicht passt, oder der leere Text."""
    s = seite(name)
    teile = [k.tag for k in kinder(s.erstes("body"))]
    if teile != ["header", "main", "nav"]:
        return "%s: Direkt in body stehen %s -- es sollen header, main, nav sein." % (name, ", ".join(teile) or "keine Elemente")
    if not s.erstes("header").finde("h1"):
        return "%s: Im header steht keine Überschrift h1." % name
    nav = s.erstes("nav")
    if not (nav.finde("ul") or nav.finde("ol")) or not nav.finde("a"):
        return "%s: In nav steht keine Liste mit Links." % name
    if not all(a.eltern.tag == "li" for a in nav.finde("a")):
        return "%s: Ein Link in nav steht nicht in einem li." % name
    return ""


def pruefe_10_lissabon_liste():
    """Aufgabe 2 · Lissabon: Die Liste ist geschlossen"""
    s = seite("lissabon.html")
    erwarte(not s.offen(), s.meldung_offen())
    # Die Liste zu spät geschlossen (</ul> erst unten vor </body>): nichts ist mehr offen, aber Überschrift und
    # Absätze stecken weiter in der Liste -- die Seite rückt ein wie vorher (Giftprobe 16.11.2026)
    fremd = [k for liste in s.elemente("ul") + s.elemente("ol") for k in kinder(liste) if k.tag != "li"]
    zeile = fremd[0].zeile if fremd else 0
    tag = fremd[0].tag if fremd else ""
    erwarte(not fremd, "In Zeile %d steht <%s> direkt in der Liste -- dort stehen nur Listenpunkte. Schaut in den Baum: "
                       "Wo endet die Liste?" % (zeile, tag))


def pruefe_20_helsinki_kreuz():
    """Aufgabe 2 ★★ · Helsinki: Nichts steht überkreuz"""
    s = angefangen("helsinki.html")
    kreuz = s.ueberkreuzt[0] if s.ueberkreuzt else ("", 0, "")
    erwarte(not s.ueberkreuzt, "In Zeile %d schließt </%s>, obwohl <%s> darin noch offen ist." % (kreuz[1], kreuz[0], kreuz[2]))
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_25_helsinki_liste():
    """Aufgabe 2 ★★ · Helsinki: Jeder Listenpunkt steht in einer Liste"""
    s = angefangen("helsinki.html")
    lose = [li for li in s.elemente("li") if li.eltern.tag not in ("ul", "ol")]
    zeile = lose[0].zeile if lose else 0
    erwarte(not lose, "In Zeile %d steht ein li, aber sein Elternelement ist keine Liste." % zeile)


def pruefe_30_zwei_stationen():
    """Aufgabe 4 · Keflavík und Lissabon: header, main, nav"""
    angefangen("keflavik.html")
    for name in ("keflavik.html", "lissabon.html"):
        fehler = bau_fehler(name)
        erwarte(not fehler, fehler)


def pruefe_40_alle_stationen():
    """Aufgabe 4 ★★ · Alle sechs Stationen gleich gebaut"""
    angefangen("keflavik.html")
    braucht(not bau_fehler("keflavik.html") and not bau_fehler("lissabon.html"), "Erst Keflavík und Lissabon.")
    fehlt = [bau_fehler(n) for n in STATIONEN if bau_fehler(n)]
    erwarte(not fehlt, fehlt[0] if fehlt else "")
    erwarte(not seite("helsinki.html").erstes("main").finde("br"), "In Helsinki stehen noch br im main -- jeder Satz wird ein Absatz.")


def _reise(k):
    """Die Ziele der Links in einer ol, in ihrer Folge."""
    return [a.attribute.get("href") for ol in k.finde("ol") for a in ol.finde("a")]


def pruefe_50_reise():
    """Aufgabe 5 ★★ · Die Startseite zeigt die Reise als ol"""
    s = angefangen("index.html")
    erwarte(_reise(s.wurzel) == REISE, "Auf der Startseite steht noch keine ol mit den sechs Stationen in der Reihenfolge der Reise.")


def pruefe_60_reise_nav():
    """Aufgabe 5 ★★★ · Die Reise steht in nav, auch am Check-in"""
    s = angefangen("index.html")
    braucht(_reise(s.wurzel) == REISE, "Erst die Liste auf der Startseite.")
    for name in ("index.html", "checkin.html"):
        navs = seite(name).elemente("nav")
        erwarte(any(_reise(n) == REISE for n in navs), "%s: Die Reise steht noch nicht in nav." % name)


def form(k):
    return (k.tag, [form(c) for c in kinder(k)])


TUBA = ("body", [("header", [("h1", []), ("img", [])]),
                 ("main", [("p", []), ("ul", [("li", []), ("li", []), ("li", [])])]),
                 ("nav", [("ul", [("li", [("a", [])])])])])


def _ebenen(k, ebene=0):
    """Alle Elemente unter k mit ihrer Ebene (k selbst ist Ebene 0): [(Ebene, Knoten)]."""
    aus = []
    for c in kinder(k):
        aus.append((ebene + 1, c))
        aus += _ebenen(c, ebene + 1)
    return aus


def _hinweis_fehlt(body):
    """Der erste der Hinweise 1 bis 6, zu dem der Baum unter body noch nicht passt (0: er passt zu allen sechs)."""
    alle = _ebenen(body)
    tags = lambda liste: [k.tag for k in liste]
    oben = kinder(body)
    if len(alle) != 13 or max([e for e, _ in alle] or [0]) != 4:
        return 1
    if tags(oben) != ["header", "main", "nav"] or not all(kinder(k) for k in oben):
        return 2
    if tags(kinder(oben[0])) != ["h1", "img"]:
        return 3
    listen = body.finde("ul")
    links = body.finde("a")
    punkte = sorted(len([c for c in kinder(u) if c.tag == "li"]) for u in listen)
    klein = [u for u in listen if len(kinder(u)) == 1]
    if len(listen) != 2 or punkte != [1, 3] or len(links) != 1 or len(body.finde("li")) != 4 \
            or not klein or links[0] not in klein[0].finde("a"):
        return 4
    tief = [k for e, k in alle if e == 4]
    a = links[0]
    if tags(tief) != ["a"] or a.eltern.eltern.eltern.tag != "nav":
        return 5
    absaetze = body.finde("p")
    if len(absaetze) != 1:
        return 6
    geschwister = kinder(absaetze[0].eltern)
    i = geschwister.index(absaetze[0])
    gross = [u for u in listen if len(kinder(u)) == 3]
    if not gross or i + 1 >= len(geschwister) or geschwister[i + 1] is not gross[0]:
        return 6
    return 0


def pruefe_70_tuba():
    """Aufgabe 6 ★★★★ · Die Tuba hat den Baum aus den Hinweisen"""
    s = angefangen("tuba.html")
    erwarte(not s.offen(), s.meldung_offen())
    body = s.erstes("body")
    erwarte(body is not None, "In tuba.html fehlt body.")
    nr = _hinweis_fehlt(body)
    erwarte(nr == 0, "Zu Hinweis %d passt der Baum von tuba.html noch nicht." % nr)
    erwarte(form(body) == TUBA, "Jeder Hinweis für sich passt, aber der Baum von tuba.html ist noch nicht der gesuchte: "
                                "Steht jeder Listenpunkt direkt in einer Liste?")
    ziele = [h for h, _, _ in s.links()]
    erwarte("sperrgepaeck.html" in ziele, "Hinweis 7: Der Link in der Tuba führt noch nicht zum Sperrgepäck.")
    quellen = [q for q, _, _ in s.bilder()]
    erwarte(quellen == ["bilder/sperrgepaeck.svg"], "Hinweis 7: Das Bild ist noch nicht bilder/sperrgepaeck.svg.")
