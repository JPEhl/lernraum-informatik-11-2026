from pruefen import erwarte, braucht, seite

TITEL = "HTML-Grundgerüst und Tags · Selbstcheck"

# Fingerabdrücke der Startseiten in gepaecksuche/: Solange eine Seite so ist wie am Anfang, ist ihre Aufgabe
# „noch nicht dran“ (drei Zustände -- am Start steht genau EINE Pflichtprüfung aus: die Überschrift von Keflavík).
# Ändert sich ein Starttext, hier neu eintragen:
#   python3 -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1]).read().strip().encode()).hexdigest()[:12])" gepaecksuche/<datei>
START = {"gepaeckband.html": "a933f3a776b9", "lissabon.html": "223d5942d9c5", "checkin.html": "2c8688fd368e",
         "zoll.html": "4d05f2636d61"}

# Der Text des Zolls ohne Leerraum (Aufgabe 7): Die Auflage heißt „kein Wort ändern“ -- verglichen wird ohne Leerraum,
# weil ein Tag mitten im Satz die Abstände im gelesenen Text verschiebt.
ZOLL_TEXT = ("Zoll"
             "DerroteKofferwurdegeöffnet.Darin:vierziglinkeSockenundeinReiseführerfürHelsinki."
             "WasderZollsagt"
             "LinkeSockensindzollfrei.DerKofferdurfteweiterreisen."
             "FragenzudenrechtenSockenbeantwortetderZollnicht.")


def angefangen(name):
    s = seite(name)
    braucht(s.da, "Die Datei %s fehlt im Ordner." % name)
    braucht(s.abdruck != START.get(name), "Noch nicht angefangen.")
    return s


def ansage(stuecke):
    """So sagt es das Vorlese-Programm an: die Stücke in Anführungszeichen, ohne Stück „nichts“."""
    kurz = [x if len(x) <= 60 else x[:57].rstrip() + " …" for x in stuecke]
    return " · ".join("„%s“" % x for x in kurz) if kurz else "nichts"


def pruefe_10_kef_geruest():
    """Aufgabe 1 · Keflavík: das Grundgerüst steht noch"""
    s = seite("keflavik.html")
    erwarte(not s.geruest_fehlt(), s.meldung_geruest())


def pruefe_20_kef_h1():
    """Aufgabe 1 · Keflavík: eine Überschrift h1"""
    s = seite("keflavik.html")
    h1 = s.erstes("h1")
    # eine Überschrift, die nie endet, ist nicht „keine Überschrift“: dann die Stelle nennen, nicht den Namen vermissen
    endlos = s.meldung_offen() if h1 is not None and not h1.geschlossen else ""
    erwarte(not endlos, endlos)
    erwarte(s.text("h1") == "Keflavík", "Noch keine Überschrift h1 mit dem Namen der Station.")


def pruefe_30_kef_absaetze():
    """Aufgabe 1 · Keflavík: jede Zeile des Textes in einem Absatz"""
    s = seite("keflavik.html")
    braucht(s.text("h1"), "Erst die Überschrift.")
    erwarte(not s.lose_texte(), s.meldung_lose())
    erwarte(len(s.elemente("p")) >= 3, "Noch nicht jede Zeile des Textes steht in einem eigenen Absatz.")


def pruefe_40_kef_enden():
    """Aufgabe 1 · Keflavík: jedes Tag endet"""
    s = seite("keflavik.html")
    braucht(s.elemente("p"), "Erst die Absätze.")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_50_kef_h2():
    """Aufgabe 1 ★★ · Keflavík: „Was am Griff hing“ eine Stufe kleiner"""
    s = seite("keflavik.html")
    braucht(s.elemente("p"), "Erst die Absätze.")
    erwarte(s.text("h2") == "Was am Griff hing", "„Was am Griff hing“ ist noch keine Überschrift der zweiten Stufe.")


def pruefe_60_kef_lis():
    """Aufgabe 1 ★★ · Keflavík: der Zettel LIS ist wichtig"""
    s = seite("keflavik.html")
    braucht(s.elemente("p"), "Erst die Absätze.")
    erwarte("LIS" in s.texte("strong"), "Was auf dem Zettel steht, ist noch nicht als wichtig ausgezeichnet.")


def pruefe_70_band_ende():
    """Aufgabe 2 · Gepäckband: jedes Tag endet"""
    s = angefangen("gepaeckband.html")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_80_band_body():
    """Aufgabe 2 ★★ · Gepäckband: aller Text steht im body, in einem Absatz"""
    s = angefangen("gepaeckband.html")
    draussen = s.ausserhalb()
    satz = draussen[0][:50] if draussen else ""
    erwarte(not draussen, "Ein Text steht nicht im body: „%s“. Der Browser zeigt ihn trotzdem -- die Regel nicht." % satz)
    erwarte(not s.lose_texte(), s.meldung_lose())


def pruefe_90_lis_geruest():
    """Aufgabe 4 · Lissabon: das Grundgerüst mit title"""
    s = angefangen("lissabon.html")
    erwarte(not s.geruest_fehlt(), s.meldung_geruest())
    erwarte(s.text("title") == "Lissabon", "Der title nennt noch nicht die Station.")
    erwarte(not s.ausserhalb(), "Ein Text steht noch außerhalb von body.")


def pruefe_92_lis_ausgezeichnet():
    """Aufgabe 4 ★★ · Lissabon: ausgezeichnet wie Keflavík"""
    s = angefangen("lissabon.html")
    braucht(s.erstes("body") is not None, "Erst das Grundgerüst.")
    erwarte(s.text("h1") == "Lissabon", "Noch keine Überschrift h1 mit dem Namen der Station.")
    erwarte(not s.lose_texte(), s.meldung_lose())
    erwarte(s.text("h2") == "Was der Gepäckwagen sagt", "„Was der Gepäckwagen sagt“ ist noch keine Überschrift der zweiten Stufe.")
    erwarte("HEL" in s.texte("strong"), "Die Spur ist noch nicht als wichtig ausgezeichnet.")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_95_checkin():
    """Aufgabe 6 ★★ · Check-in: eine Linie und eine neue Zeile ohne neuen Absatz"""
    s = angefangen("checkin.html")
    erwarte(s.elemente("hr"), "Noch keine Linie zwischen den Absätzen.")
    erwarte(s.elemente("br"), "Das Schild steht noch nicht in einer eigenen Zeile.")
    erwarte(len(s.elemente("p")) == 2, "Die neue Zeile soll keinen neuen Absatz anfangen.")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_97_zoll_ansage():
    """Aufgabe 7 ★★★ · Zoll: Das Vorlese-Programm sagt an, was gemeint ist"""
    s = angefangen("zoll.html")
    erwarte(not s.offen(), s.meldung_offen())
    koerper = s.erstes("body")
    text = "".join(koerper.text().split()) if koerper is not None else ""
    erwarte(text == ZOLL_TEXT, "Am Text des Zolls ist etwas anders als am Anfang -- die Auflage: kein Wort geändert, gestrichen oder umgestellt.")
    h1, h2 = s.texte("h1"), s.texte("h2")
    betont = [t.strip(" .") for t in s.texte("strong")]
    absaetze = len(s.elemente("p"))
    erwarte(h1 == ["Zoll"], "Das Vorlese-Programm sagt als Überschrift an: %s." % ansage(h1))
    erwarte(h2 == ["Was der Zoll sagt"], "Das Vorlese-Programm sagt als Abschnitt an: %s." % ansage(h2))
    erwarte(not s.lose_texte(), s.meldung_lose())
    erwarte(absaetze == 3, "Das Vorlese-Programm liest %d Absätze vor -- gemeint sind drei." % absaetze)
    erwarte(betont == ["nicht"], "Das Vorlese-Programm betont: %s." % ansage(betont))
