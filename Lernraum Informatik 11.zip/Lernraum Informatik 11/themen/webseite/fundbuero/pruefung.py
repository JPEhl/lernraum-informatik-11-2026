import re

from pruefen import erwarte, braucht, seite, css

TITEL = "Zwölf rote Koffer · Selbstcheck"

# Fingerabdrücke der Startseiten in gepaecksuche/: Solange eine Seite so ist wie am Anfang, ist ihre Aufgabe
# „noch nicht dran“. Ändert sich ein Starttext, hier neu eintragen:
#   python3 -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1]).read().strip().encode()).hexdigest()[:12])" gepaecksuche/<datei>
START = {"keflavik.html": "38c4b854e8b8", "lissabon.html": "dc34e73952c7", "helsinki.html": "bddf1644ecf6",
         "fundbuero.html": "fd935a56eca7", "sperrgepaeck.html": "69c0c827efd5", "index.html": "adca2cbc28f5",
         "flughafen.css": "2243c398cf51"}
STATIONEN = ["checkin.html", "gepaeckband.html", "keflavik.html", "lissabon.html", "helsinki.html", "fundbuero.html"]
FLUGHAEFEN = ["keflavik.html", "lissabon.html", "helsinki.html"]
HAUSFARBE, ZOLLGRAU = "#c8352b", "#6f6a63"


def angefangen(name):
    s = seite(name)
    braucht(s.da, "Die Datei %s fehlt im Ordner." % name)
    braucht(s.abdruck != START.get(name), "Noch nicht angefangen.")
    return s


def css_angefangen():
    c = css("flughafen.css")
    braucht(c.da, "Die Datei flughafen.css fehlt im Ordner.")
    braucht(c.abdruck != START.get("flughafen.css"), "In flughafen.css steht noch keine neue Regel.")
    return c


def farbe(wert):
    return (wert or "").strip().lower()


def schreibfehler(s):
    """Erst die Schreibfehler im CSS der Seite -- sonst rechnet alles Weitere mit einer Regel, die der Browser überliest."""
    erwarte(not s.css_fehler(), s.meldung_css())


def bindet_ein(s, name):
    """flughafen.css eingebunden, mit dem Rückgriff auf spuren: im href nur der Dateiname."""
    hrefs = s.css_dateien()
    fast = [h for h in hrefs if h.endswith("flughafen.css") and h != "flughafen.css"]
    erwarte(not fast, "%s: Im href steht „%s“ -- dort steht nur der Dateiname, wie bei den Links zwischen den Stationen." % (name, fast[0] if fast else ""))
    erwarte(s.eingebunden("flughafen.css"), "%s bindet flughafen.css noch nicht ein." % name)


def pruefe_10_hausfarbe():
    """Aufgabe 1 · Die drei Flughäfen in der Hausfarbe"""
    # ohne braucht(…): die erste Pflichtprüfung ist am Anfang OFFEN und nennt den nächsten Schritt (Regelkarte LC1;
    # bis zum 11.11.2026 stand hier „Noch nicht angefangen.“ -- an der Startdatei war dann gar nichts offen)
    for n in FLUGHAEFEN:
        s = seite(n)
        schreibfehler(s)
        erwarte(farbe(s.stil("h1", "color")) == HAUSFARBE, "%s: Die Überschrift h1 ist noch nicht %s." % (n, HAUSFARBE))
        erwarte(farbe(s.stil("body", "font-family")).startswith("system-ui"), "%s: Die Schrift ist noch nicht system-ui." % n)


def pruefe_20_drei_eingebunden():
    """Aufgabe 3 · Die drei Flughäfen binden flughafen.css ein"""
    braucht(any(seite(n).abdruck != START.get(n) for n in FLUGHAEFEN), "Noch nicht angefangen.")
    for n in FLUGHAEFEN:
        s = seite(n)
        bindet_ein(s, n)
        erwarte(not s.stilbloecke(), "%s: Das eigene <style> steht noch im head." % n)
        schreibfehler(s)


def pruefe_30_alle_eingebunden():
    """Aufgabe 3 ★★ · Alle sechs Stationen, die Navigation in der Hausfarbe"""
    css_angefangen()
    for n in STATIONEN:
        s = seite(n)
        bindet_ein(s, n)
        erwarte(not s.stilbloecke(), "%s: Das eigene <style> steht noch im head." % n)
        schreibfehler(s)
    for n in STATIONEN:
        s = seite(n)
        links = [a for nav in s.elemente("nav") for a in nav.finde("a")]
        braucht(links, "%s: In nav steht kein Link." % n)
        erwarte(all(farbe(s.stil(a, "color")) == HAUSFARBE for a in links), "%s: Die Links in nav sind noch nicht %s." % (n, HAUSFARBE))
    s = seite("helsinki.html")
    im_text = [a for a in s.erstes("main").finde("a")]
    erwarte(not any(farbe(s.stil(a, "color")) == HAUSFARBE for a in im_text),
            "In Helsinki sind auch die Links im Text rot -- gemeint sind nur die Links der Navigation.")


def spalten(wert):
    """Zahl der Spalten aus grid-template-columns: „1fr 1fr 1fr 1fr“ oder „repeat(4, 1fr)“."""
    wert = (wert or "").strip()
    m = re.fullmatch(r"repeat\(\s*(\d+)\s*,.*\)", wert)
    if m:
        return int(m.group(1))
    return len(re.findall(r"[^\s(]+(?:\([^)]*\))?", wert))


def leer_getroffen(s):
    """Eine Regel, deren Selektor ein bloßes Wort ist, das auf der Seite als Klasse vorkommt, aber als Element nicht --
    die Klasse ohne Punkt. Gibt die Meldung mit Datei und Zeile oder den leeren Text."""
    klassen = {c for k in s.wurzel.alle() if hasattr(k, "klassen") for c in k.klassen()}
    for r in s.regeln():
        for sel in r.selektoren:
            if re.fullmatch(r"[a-z][a-z0-9-]*", sel) and sel in klassen and not s.trifft(sel):
                return "%s, Zeile %d: Der Selektor „%s“ trifft auf dieser Seite kein Element." % (r.datei, r.zeile, sel)
    return ""


def regal(s):
    r = s.trifft(".regal")
    braucht(r, "Im Fundbüro steht kein Element mit class=\"regal\" mehr.")
    return r[0]


def pruefe_40_regal():
    """Aufgabe 5 · Die Koffer stehen in vier Spalten"""
    s = angefangen("fundbuero.html")
    bindet_ein(s, "fundbuero.html")
    schreibfehler(s)
    r = regal(s)
    erwarte(s.stil(r, "display").strip() == "grid", leer_getroffen(s) or "Das Regal ist noch kein Grid (display).")
    erwarte(spalten(s.stil(r, "grid-template-columns")) == 4, "Das Regal hat noch nicht vier Spalten (grid-template-columns).")


def pruefe_50_gerade():
    """Aufgabe 5 ★★ · Die Koffer stehen gerade"""
    s = angefangen("fundbuero.html")
    braucht(s.eingebunden("flughafen.css") and s.stil(regal(s), "display").strip() == "grid", "Erst das Regal.")
    schreibfehler(s)
    bilder = [b for k in s.trifft(".koffer") for b in k.finde("img")]
    braucht(bilder, "In den Koffern steht kein Bild.")
    erwarte(all(s.stil(b, "float").strip() in ("none", "") for b in bilder), "Die Koffer stehen noch schräg: Ihre Bilder fließen nach rechts (float).")


def pruefe_60_zollgrau():
    """Aufgabe 6 ★★ · Das Sperrgepäck ist zollgrau"""
    s = angefangen("sperrgepaeck.html")
    bindet_ein(s, "sperrgepaeck.html")
    schreibfehler(s)
    erwarte(farbe(s.stil("h1", "color")) == ZOLLGRAU, "Die Überschrift des Sperrgepäcks ist noch nicht %s." % ZOLLGRAU)
    erwarte(farbe(seite("index.html").stil("h1", "color")) == HAUSFARBE, "Die Startseite ist nicht mehr %s -- flughafen.css bleibt, wie sie ist." % HAUSFARBE)


def pruefe_70_zoll_vorn():
    """Aufgabe 6 ★★★ · Das Grau gewinnt, obwohl das style vor dem link steht"""
    s = angefangen("sperrgepaeck.html")
    braucht(farbe(s.stil("h1", "color")) == ZOLLGRAU, "Erst zollgrau.")
    links = [k.zeile for k in s.elemente("link") if (k.attribute.get("href") or "") == "flughafen.css"]
    stile = [k.zeile for k in s.elemente("style")]
    braucht(links and stile, "Im head stehen noch nicht <style> und <link>.")
    erwarte(max(stile) < min(links), "Das <style> steht noch nach dem <link>.")


def namen_der_zeile(areas):
    """Die Namen der ersten Zeile aus grid-template-areas: "bild titel" -> ["bild", "titel"]."""
    zeilen = re.findall(r"\"([^\"]*)\"|'([^']*)'", areas or "")
    return (zeilen[0][0] or zeilen[0][1]).split() if zeilen else []


def pruefe_80_kopf():
    """Aufgabe 7 ★★★★ · Jeder Kopf: Bild links, Überschrift rechts -- ohne HTML zu ändern"""
    c = css_angefangen()
    braucht(any("grid-template-areas" in r.eigenschaften for r in c.regeln), "In flughafen.css steht noch kein grid-template-areas.")
    erwarte(seite("index.html").abdruck == START.get("index.html"), "Die Startseite ist geändert -- die Auflage: keine Zeile HTML.")
    for n in STATIONEN:
        s = seite(n)
        schreibfehler(s)
        kopf = s.erstes("header")
        braucht(kopf, "%s: Es gibt keinen header mehr." % n)
        erwarte(not s.stilbloecke() and not any(k.attribute.get("style") for k in s.wurzel.alle() if hasattr(k, "attribute")),
                "%s: In der Seite steht CSS -- die Auflage: nur flughafen.css." % n)
        h1, bild = kopf.finde("h1"), kopf.finde("img")
        braucht(h1 and bild, "%s: Im header fehlen Überschrift oder Bild." % n)
        erwarte(h1[0].zeile <= bild[0].zeile, "%s: Im Quelltext steht das Bild jetzt vor der Überschrift -- die Auflage: keine Zeile HTML." % n)
        erwarte(s.stil(kopf, "display").strip() == "grid", "%s: Der header ist noch kein Grid." % n)
        namen = namen_der_zeile(s.stil(kopf, "grid-template-areas"))
        a, b = s.stil(bild[0], "grid-area").strip(), s.stil(h1[0], "grid-area").strip()
        erwarte(a in namen and b in namen and namen.index(a) < namen.index(b),
                "%s: Bild und Überschrift stehen noch nicht in benannten Zellen, das Bild links." % n)
