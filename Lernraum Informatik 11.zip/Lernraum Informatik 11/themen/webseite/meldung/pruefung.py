from pruefen import erwarte, braucht, seite, weg

TITEL = "Die Verlustmeldung · Selbstcheck"

# Fingerabdrücke der Startseiten in gepaecksuche/: Solange eine Seite so ist wie am Anfang, ist ihre Aufgabe
# „noch nicht dran“. Ändert sich ein Starttext (planung/meldung_stand.py), hier neu eintragen:
#   python3 -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1]).read().strip().encode()).hexdigest()[:12])" gepaecksuche/<datei>
START = {"meldung.html": "d0ae63b97488", "abholen.html": "2af4555d84a2", "nachbau.html": "fe5d05f9dd38",
         "fundbuero.html": "b402947b4858"}
# die Anfrage, die am Router mitgelesen wurde (Aufgabe 7) -- getippt wird nur der Gepäckschein
NACHBAU = "GET /melden?schein=290611&farbe=rot&station=fundbuero"


def angefangen(name):
    s = seite(name)
    braucht(s.da, "Die Datei %s fehlt im Ordner." % name)
    braucht(s.abdruck != START.get(name), "Noch nicht angefangen.")
    return s


def meldung():
    s = seite("meldung.html")
    braucht(s.da, "Die Datei meldung.html fehlt im Ordner.")
    return s


def pruefe_10_reist_mit():
    """Aufgabe 1 · Jede Eingabe der Meldung reist mit"""
    s = meldung()
    m = s.meldung_formular()
    erwarte(m == "", m)


def pruefe_20_fuenf_felder():
    """Aufgabe 1 · Zwei Felder mehr, alle beschriftet"""
    s = angefangen("meldung.html")
    f = s.formular()
    braucht(f is not None and not f.ohne_namen(), "Zuerst muss jede Eingabe mitreisen.")
    namen = f.namen()
    doppelt = sorted({n for n in namen if namen.count(n) > 1})
    erwarte(not doppelt, "Zwei Felder heißen „%s“ -- auf dem Abholschein stünde der Name zweimal." % (doppelt[0] if doppelt else ""))
    erwarte(len([x for x in f.felder if x.typ != "hidden"]) >= 5, "Die Meldung hat noch keine fünf Felder.")
    erwarte(any(x.tag == "textarea" for x in f.felder), "Für „Besonderes“ fehlt noch ein Feld, in das mehrere Zeilen passen.")
    ohne = f.ohne_beschriftung()
    erwarte(not ohne, "Das Feld in Zeile %d hat keine Beschriftung (label)." % (ohne[0].zeile if ohne else 0))


def pruefe_30_vom_fundbuero():
    """Aufgabe 1 ★★ · Vom Fundbüro zur Meldung"""
    angefangen("fundbuero.html")
    erwarte(weg("fundbuero.html", "meldung.html") is not None and
            any(h == "meldung.html" for h, _, _ in seite("fundbuero.html").links()),
            "Im Fundbüro führt noch kein Link zur Verlustmeldung.")


def pruefe_40_grid():
    """Aufgabe 4 · Navigation links, Inhalt rechts"""
    s = angefangen("abholen.html")
    erwarte(not s.css_fehler(), s.meldung_css())
    seiten = s.trifft(".seite")
    braucht(seiten, "Auf abholen.html steht kein Element mit class=\"seite\" mehr.")
    box = seiten[0]
    erwarte(s.stil(box, "display").strip() == "grid", "Der Behälter mit class=\"seite\" ist noch kein Grid (display).")
    spalten = s.stil(box, "grid-template-columns").split()
    erwarte(len(spalten) == 2, "Das Grid hat noch nicht zwei Spalten (grid-template-columns).")
    kinder = [k.tag for k in box.kinder if hasattr(k, "tag")]
    erwarte(kinder[:2] == ["nav", "main"], "Im Behälter steht nicht mehr erst nav, dann main.")


def pruefe_50_farbe():
    """Aufgabe 6 ★★ · Die Farbe zum Wählen"""
    s = angefangen("meldung.html")
    f = s.formular()
    braucht(f is not None, "Zuerst das Formular.")
    wahl = [x for x in f.felder if x.tag == "select"]
    braucht(wahl, "Noch keine Auswahl in der Meldung.")
    erwarte(wahl[0].name, "Die Auswahl in Zeile %d hat keinen name: Die Farbe reist nicht mit." % wahl[0].zeile)
    erwarte(len(wahl[0].knoten.finde("option")) >= 3, "Die Auswahl hat noch keine drei Farben (option).")


def pruefe_60_nachbau():
    """Aufgabe 7 ★★★ · Rückwärts: genau diese Anfrage"""
    s = angefangen("nachbau.html")
    f = s.formular()
    braucht(f is not None, "Auf nachbau.html steht noch kein Formular.")
    getippt = [x for x in f.felder if x.tag in ("input", "textarea") and x.typ not in ("hidden", "checkbox", "radio")]
    erwarte(len(getippt) == 1, "Getippt wird nur der Gepäckschein -- euer Formular hat %d Felder zum Tippen." % len(getippt))
    farbe = f.feld("farbe")
    erwarte(farbe is not None and farbe.tag == "select", "Die Farbe wird gewählt, nicht getippt.")
    station = f.feld("station")
    erwarte(station is not None and station.typ == "hidden", "„fundbuero“ tippt niemand -- es steht schon im Formular.")
    werte = {getippt[0].name: "290611"} if getippt and getippt[0].name else {}
    a = f.anfrage(werte)
    erwarte(a == NACHBAU, "Mit 290611 schickt euer Formular: %s" % a)
