"""Selbstcheck zu "Wahrheitswerte und Bedingungen" -- prueft wahr.py (Aufgabe 2,
unter Mehr die Aufgaben 7 und 8).

Spielt das Programm mit einer unordentlichen Richtung an und danach mit
weiteren Befehlen (anspielen), und sieht sich die Kaestchen an: Liegt darin
ein Wahrheitswert, und stimmt er bei jedem Befehl? Verraet keine Bedingung,
nur woran es haengt -- und bewertet nichts.
"""
import ast
import re

import pruefen
from pruefen import erwarte, braucht, arbeit, quelltext, ohne_kommentare, ausgabe, anspielen

TITEL = "Wahrheitswerte und Bedingungen · Selbstcheck"

# Groß und mit Rand -- das Spiel räumt den Befehl zuerst auf (Thema Eingabe und Text)
EINGABEN = ["  Norden "]

_FEHLT = object()


def _wert(name):
    return getattr(arbeit(), name, _FEHLT)


def _code():
    """Der Code ohne Kommentare und ohne Text in Anführungszeichen."""
    return re.sub(r'"[^"]*"|\'[^\']*\'', '""', ohne_kommentare())


def _bei(befehl, name):
    """Der Wert eines Kästchens, wenn das Spiel mit diesem Befehl läuft."""
    _, ns = anspielen([befehl])
    return ns.get(name, _FEHLT)


def _zug(befehl, **start):
    """Das Spiel mit diesem Befehl, oben vorher andere Startwerte (wie regeln/pruefung.py).
    Gibt (was nach dem Befehl in der Shell steht, Kästchen danach)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=(?!=).*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q
    try:
        aus, ns = anspielen([befehl])
    finally:
        pruefen._QUELLE = alt
    marke = befehl + "\n"
    return (aus[aus.find(marke) + len(marke):] if marke in aus else ""), ns


def _oben(name):
    """Das Kästchen bekommt oben einen Startwert -- dann lässt er sich für eine Probe ändern."""
    return re.search(r"^%s[ \t]*=(?!=)" % name, quelltext(), re.M) is not None


def _antworten(text):
    """Je Zeile der Shell die letzte Antwort True oder False (sonst None)."""
    aus = []
    for zeile in text.splitlines():
        w = re.findall(r"\b(True|False)\b", zeile)
        aus.append(w[-1] == "True" if w else None)
    return aus


def _zeige(w):
    return "nichts" if w is _FEHLT else repr(w)


def _ueberschreibt():
    """Die Haengestelle des Themas: = statt == in einer Frage (`x = eingabe = "norden"`).
    Python meldet nichts, und der Wert kann sogar True oder False sein."""
    m = re.search(r"^\s*(\w+)\s*=\s*(eingabe|raum)\s*=(?!=)", _code(), re.M)
    return (m.group(1), m.group(2)) if m else None


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


# ── Aufgabe 2 · das Spiel stellt Fragen ──────────────────────────────────

def pruefe_30_schluessel():
    """Aufgabe 2 · Ein Kästchen hat_torschluessel mit False"""
    w = _wert("hat_torschluessel")
    erwarte(w is not _FEHLT,
            "Es gibt noch kein Kästchen hat_torschluessel. Es kommt nach oben zu "
            "raum, zuege und punkte.")
    erwarte(w is False,
            "In hat_torschluessel liegt %s. Noch hast du den Schlüssel nicht -- "
            "der Wert ist False, ohne Anführungszeichen." % _zeige(w))


def pruefe_31_richtung():
    """Aufgabe 2 · ist_richtung sagt True oder False -- bei jeder Richtung"""
    # im Startzustand wartet diese Pruefung auf die erste (hat_torschluessel)
    braucht(_wert("ist_richtung") is not _FEHLT or _wert("hat_torschluessel") is not _FEHLT)
    w = _wert("ist_richtung")
    erwarte(w is not _FEHLT,
            "Es gibt noch kein Kästchen ist_richtung.")
    ueber = _ueberschreibt() or ("", "")
    erwarte(ueber[0] != "ist_richtung",
            "In der Zeile %s = %s = … steht = statt ==. Ein = legt hinein, == fragt -- "
            "so wird %s überschrieben, und Python meldet nichts." % (ueber[0], ueber[1], ueber[1]))
    proben = (("norden", True), ("osten", True), ("süden", True),
              ("westen", True), ("nimm lampe", False), ("schau", False))
    werte = [(b, _bei(b, "ist_richtung"), soll) for b, soll in proben]
    text = [(b, x) for b, x, _ in werte if not isinstance(x, bool)]
    b0, x0 = text[0] if text else ("", "")
    erwarte(not text,
            "Bei '%s' liegt in ist_richtung %s -- kein True oder False. Steht hinter or "
            "nur ein Text wie \"süden\"? Jede Seite braucht eine ganze Frage mit ==."
            % (b0, _zeige(x0)))
    falsch = [b for b, x, soll in werte if x is not soll]
    erster = falsch[0] if falsch else ""
    erwarte(not falsch,
            "Bei '%s' stimmt ist_richtung noch nicht. Es soll True sein bei den vier "
            "Richtungen und sonst False." % erster)
    # bei "norden" antworten die Fragen aus dem Thema davor mit False -- True kommt erst von hier
    erwarte("True" in ausgabe(),
            "Das Spiel zeigt ist_richtung noch nicht an.")


def _tor_fehler():
    """Verhalten statt Woerter (Reihensichtung 25.10.): will_zum_tor und tor_offen auch
    in einem anderen Raum und mit Schluessel anspielen -- sonst bleibt eine halbe Regel
    gruen. Gibt die erste Meldung zurueck oder None."""
    for b, r, soll in (("norden", "flur", True), ("süden", "flur", False), ("norden", "keller", False)):
        if _zug(b, raum=r)[1].get("will_zum_tor", _FEHLT) is not soll:
            return ("will_zum_tor stimmt noch nicht bei '%s' im %s. True soll es nur sein, wenn "
                    "der Befehl norden ist und du im Flur stehst." % (b, r.capitalize()))
    for b, r, k, soll in (("norden", "flur", True, True), ("norden", "flur", False, False),
                          ("süden", "flur", True, False), ("norden", "keller", True, False)):
        if _zug(b, raum=r, hat_torschluessel=k)[1].get("tor_offen", _FEHLT) is not soll:
            return ("tor_offen stimmt noch nicht bei '%s' im %s %s Schlüssel. Das Tor geht nur "
                    "auf, wenn du zum Tor willst und den Schlüssel hast -- welches Wort heißt: "
                    "beide?" % (b, r.capitalize(), "mit" if k else "ohne"))
    return None


def pruefe_32_tor():
    """Aufgabe 2 ★★ · will_zum_tor und tor_offen"""
    braucht(isinstance(_wert("ist_richtung"), bool))
    ueber = _ueberschreibt() or ("", "")
    erwarte(not ueber[0],
            "In der Zeile %s = %s = … steht = statt ==. Ein = legt hinein, == fragt -- "
            "so wird %s überschrieben, und Python meldet nichts." % (ueber[0], ueber[1], ueber[1]))
    w = _wert("will_zum_tor")
    t = _wert("tor_offen")
    erwarte(w is not _FEHLT and t is not _FEHLT,
            "Es fehlt noch ein Kästchen: will_zum_tor oder tor_offen.")
    erwarte(isinstance(w, bool),
            "In will_zum_tor liegt %s, kein True oder False. Steht dort = statt ==? "
            "Ein = legt hinein, == fragt." % _zeige(w))
    braucht(_oben("raum") and _oben("hat_torschluessel"))
    fehler = _tor_fehler()
    erwarte(fehler is None, fehler or "")


def pruefe_33_bleibt_zu():
    """Aufgabe 2 ★★ · Mit not: Bleibt das Tor zu?"""
    braucht(_wert("tor_offen") is False and _oben("raum") and _oben("hat_torschluessel")
            and _tor_fehler() is None)
    # Vier Lagen; eine Zeile der Shell muss in jeder das Gegenteil von tor_offen zeigen
    # (nur bei norden im Flur mit Schluessel geht das Tor auf). Ein not vor dem
    # falschen Kaestchen (will_zum_tor, hat_torschluessel) passt nicht in alle vier.
    lagen = (("norden", "flur", True, False), ("norden", "flur", False, True),
             ("süden", "flur", True, True), ("norden", "keller", True, True))
    spalten = [_antworten(_zug(b, raum=r, hat_torschluessel=k)[0]) for b, r, k, _ in lagen]
    soll = [z for _, _, _, z in lagen]
    passt = any([sp[i] for sp in spalten] == soll for i in range(min(len(sp) for sp in spalten)))
    erwarte(passt,
            "Das Spiel zeigt noch nicht richtig, ob das Tor zu bleibt: Bei norden im "
            "Flur mit Schlüssel soll dort False stehen, in jeder anderen Lage True. Das "
            "Gegenteil von tor_offen bekommt ihr mit not.")


def pruefe_34_verstanden():
    """Aufgabe 2 ★★★ · verstanden -- bei bekannten und unbekannten Befehlen"""
    braucht(isinstance(_wert("ist_richtung"), bool))
    w = _wert("verstanden")
    erwarte(w is not _FEHLT,
            "Es gibt noch kein Kästchen verstanden.")
    erwarte(isinstance(w, bool),
            "In verstanden liegt %s, kein True oder False." % _zeige(w))
    falsch = [b for b, soll in (("westen", True), ("nimm seil", True), ("lege lampe", True),
                                ("zeige", True), ("tanze", False), ("zeigen", False))
              if _bei(b, "verstanden") is not soll]
    erster = falsch[0] if falsch else ""
    erwarte(not falsch,
            "Bei '%s' stimmt verstanden noch nicht. Das Spiel kennt die vier "
            "Richtungen, nimm …, lege … und zeige -- sonst nichts." % erster)


# ── Aufgabe 7 · Mehr: das Regal in der Bibliothek ────────────────────────

def pruefe_60_regal():
    """Aufgabe 7 ★★★★ · Das Regal -- bei jedem Wort, das rückwärts gleich ist"""
    braucht("regal_offen" in ohne_kommentare())
    # "uhu": genau drei Zeichen -- wer > statt >= schreibt, faellt hier auf
    proben = (("Lagerregal", True), ("kajak", True), ("reliefpfeiler", True),
              ("uhu", True), ("nimm lampe", False), ("aa", False))
    falsch = [b for b, soll in proben if _bei(b, "regal_offen") is not soll]
    erster = falsch[0] if falsch else ""
    erwarte(not falsch,
            "Bei '%s' stimmt regal_offen noch nicht. True nur, wenn das Wort "
            "rückwärts genauso heißt und mindestens drei Zeichen hat." % erster)


# ── Aufgabe 8 · Mehr, fuer Expert*innen: drei Schalter ───────────────────

_SCHALTER = ("unten", "mitte", "oben")


def _licht_ausdruecke():
    """Am Baum: alle Ausdruecke, aus denen kellerlicht entsteht -- die rechte Seite jeder
    Zuweisung an kellerlicht und an jedes Kaestchen, das dabei abgelesen wird (ohne die
    drei Schalter), dazu die Bedingung, unter der eine solche Zuweisung steht."""
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    eltern = {kind: knoten for knoten in ast.walk(baum) for kind in ast.iter_child_nodes(knoten)}
    zuweisungen = {}
    for k in ast.walk(baum):
        if isinstance(k, ast.Assign):
            for ziel in k.targets:
                if isinstance(ziel, ast.Name):
                    zuweisungen.setdefault(ziel.id, []).append(k)
    namen, offen, aus = set(), ["kellerlicht"], []
    while offen:
        name = offen.pop()
        if name in namen or name in _SCHALTER:
            continue
        namen.add(name)
        for z in zuweisungen.get(name, []):
            teile = [z.value]
            darueber = eltern.get(z)
            while darueber is not None:
                if isinstance(darueber, (ast.If, ast.While)):
                    teile.append(darueber.test)
                darueber = eltern.get(darueber)
            for teil in teile:
                aus.append(teil)
                offen += [n.id for n in ast.walk(teil) if isinstance(n, ast.Name)]
    return aus


def _licht_woerter():
    """Welche der verbotenen Woerter in diesen Ausdruecken stehen: and, or, not."""
    gefunden = []
    for teil in _licht_ausdruecke():
        for n in ast.walk(teil):
            if isinstance(n, ast.BoolOp):
                gefunden.append("and" if isinstance(n.op, ast.And) else "or")
            elif isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.Not):
                gefunden.append("not")
    return [w for w in ("and", "or", "not") if w in gefunden]


def _licht_verkettet():
    """Ein Vergleich mit zwei Zeichen ohne Klammer (a != b != c): Python liest zwei Fragen."""
    return any(isinstance(n, ast.Compare) and len(n.ops) > 1
               for teil in _licht_ausdruecke() for n in ast.walk(teil))


def pruefe_80_kellerlicht():
    """Aufgabe 8 ★★★★ · kellerlicht -- in jeder Lage der drei Schalter, ohne and, or, not"""
    braucht("kellerlicht" in _code())
    fehlt = [s for s in _SCHALTER if not _oben(s)]
    erster = fehlt[0] if fehlt else ""
    erwarte(not fehlt,
            "Das Kästchen %s bekommt noch keinen Startwert in einer eigenen Zeile. Die drei "
            "Schalter unten, mitte und oben beginnen jeder mit False." % erster)
    w = _wert("kellerlicht")
    erwarte(w is not _FEHLT,
            "Es gibt noch kein Kästchen kellerlicht.")
    erwarte(isinstance(w, bool),
            "In kellerlicht liegt %s, kein True oder False." % _zeige(w))
    woerter = _licht_woerter()
    erwarte(not woerter,
            "In den Zeilen, aus denen kellerlicht entsteht, steht noch: %s. Die Auflage "
            "heißt: kein and, kein or, kein not." % ", ".join(woerter))
    falsch = []
    for u in (False, True):
        for m in (False, True):
            for o in (False, True):
                ist = _zug("norden", unten=u, mitte=m, oben=o)[1].get("kellerlicht", _FEHLT)
                if ist is not ((u + m + o) % 2 == 1):
                    falsch.append((u, m, o, ist))
    u, m, o, ist = falsch[0] if falsch else (False, False, False, False)
    gekippt = u + m + o
    kette = (" Python liest a != b != c ohne Klammer als zwei Fragen an die Schalter, die "
             "beide stimmen müssen.") if falsch and _licht_verkettet() else ""
    erwarte(not falsch,
            "Mit unten = %s, mitte = %s, oben = %s liegt in kellerlicht %s. Gekippt %s -- das "
            "Licht brennt bei einer ungeraden Zahl.%s"
            % (u, m, o, _zeige(ist), ("ist dort keiner", "ist dort einer", "sind dort zwei",
                                      "sind dort alle drei")[gekippt], kette))
