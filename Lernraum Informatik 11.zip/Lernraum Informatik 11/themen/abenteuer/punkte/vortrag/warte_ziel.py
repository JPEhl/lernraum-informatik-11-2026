# warte 3 lässt drei Züge vergehen.
zuege = 10
eingabe = input("> ")
if eingabe.startswith("warte "):
    zahl = eingabe.replace("warte ", "")
    n = int(zahl)
    zuege = zuege - n
print("Noch", zuege, "Züge.")
