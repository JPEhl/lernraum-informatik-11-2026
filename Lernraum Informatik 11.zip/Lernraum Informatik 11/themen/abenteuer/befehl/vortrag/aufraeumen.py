eingabe = input("> ")
print("[" + eingabe + "]")
