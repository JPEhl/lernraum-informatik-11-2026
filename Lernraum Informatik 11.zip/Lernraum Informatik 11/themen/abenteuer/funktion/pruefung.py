"""Selbstcheck zu "Funktionen" -- prueft funktion.py (Aufgabe 2, unter Mehr 8 ★★, 9 und 10 ★★★★).

Spielt das Spiel mit einer FOLGE von Befehlen an (wie in "Die for-Schleife") und schneidet die
Antwort auf jeden Befehl heraus: Was steht nach "> westen" bis zur naechsten Eingabe? So sieht der
Check, ob das Spiel den Raum beim Betreten zeigt -- und mit der richtigen Liste.

Ob etwas eine Funktion ist, fragt er Python (pruefen.funktion), ob ein Block nur EINMAL dasteht,
zaehlt er im Quelltext ohne Kommentare (die Befehlsliste, "Stockdunkel", "Du trägst",
"Abgeschlossen"). Wo ein Satz stehen muss -- im Rumpf einer Funktion --, liest er mit ast.
Verraet keine Zeile, nur woran es haengt.

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code haengt
(SCHLUSS, wie in "Listen"): Fehlt sie, ist es unterwegs abgebrochen.

Aufgabe 10 (Expertenaufgabe, Lauf i11): Der Check AENDERT das Programm an einer Stelle und spielt dann alle
Stellen an -- ein Wort im Satz an der Wand (dort, wo er zuerst steht), das Kaestchen platz oben. So prueft er die
Idee des Themas am Verhalten: Eine Aenderung an einer Stelle gilt ueberall. Wie das Paar es gebaut hat (Funktion
oder ein Kaestchen mit dem Text), ist ihm gleich.
"""
import ast
import re

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Funktionen · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"
BEFEHLE = "Befehle:"
FLUR = "Der Flur."
KELLER = "Der Keller."
INFO = "Der Informatikraum."
DUNKEL = "Stockdunkel"
ZU = "Abgeschlossen"
WAND = "Da ist eine Wand"
MAUER = "Da ist eine Mauer"
VOLL = "voll"
SCHLUSS = "§SCHLUSS§"


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte (rucksack=[...]). Gibt
    (aus, abbruch): die ganze Ausgabe und ob das Programm unterwegs abgebrochen ist."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, _ = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _anfang(aus):
    """Was das Spiel zeigt, bevor es zum ersten Mal nach einem Befehl fragt."""
    i = aus.find("> ")
    return aus if i < 0 else aus[:i]


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _strichliste(text):
    """Die Dinge, die als „  - ding“ je Zeile dastehen."""
    return re.findall(r"^[ \t]*-[ \t]*(\S.*?)[ \t]*$", text, re.M)


def _anzahl(wort):
    """Wie oft steht `wort` im Quelltext (ohne Kommentare)?"""
    return ohne_kommentare().count(wort)


def _baum():
    try:
        return ast.parse(quelltext())
    except SyntaxError:
        return None


def _im_rumpf(name, wort):
    """Steht `wort` im Rumpf der Funktion `name`?"""
    baum = _baum()
    if baum is None:
        return False
    for k in ast.walk(baum):
        if isinstance(k, ast.FunctionDef) and k.name == name:
            teil = ast.get_source_segment(quelltext(), k) or ""
            return wort in teil
    return False


def _ruft(name):
    """Die Namen, die die Funktion `name` in ihrem Rumpf aufruft."""
    baum = _baum()
    gerufen = set()
    if baum is None:
        return gerufen
    for k in ast.walk(baum):
        if isinstance(k, ast.FunctionDef) and k.name == name:
            for c in ast.walk(k):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Name):
                    gerufen.add(c.func.id)
    return gerufen


def _ruft_drei():
    """Gibt es eine Funktion, die zeige_raum, zeige_rucksack und zeige_zeit ruft?"""
    baum = _baum()
    if baum is None:
        return False
    for k in ast.walk(baum):
        if isinstance(k, ast.FunctionDef) and {"zeige_raum", "zeige_rucksack", "zeige_zeit"} <= _ruft(k.name):
            return True
    return False


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Die for-Schleife“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- wird eine Funktion gerufen, bevor sie "
            "definiert ist oder bevor es alles gibt, was sie liest (zum Beispiel hier)?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende stehen keine Sterne mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 ★ · Die Hilfe als Funktion ────────────────────────────────

def pruefe_20_hilfe_funktion():
    """Aufgabe 2 · hilfe ist eine Funktion"""
    erwarte(funktion("hilfe") is not None,
            "Es gibt noch keine Funktion hilfe -- die Zeile mit der Befehlsliste bekommt einen Namen "
            "und wird ihr Rumpf, wie die Durchsage in der Erklärung.")


def pruefe_21_hilfe_am_start():
    """Aufgabe 2 · Die Hilfe steht gleich am Anfang"""
    braucht(funktion("hilfe") is not None)
    aus, abbruch = _spiel(["ende"])
    a = _anfang(aus)
    erwarte(not abbruch, "Das Spiel bricht ab -- wird hilfe() gerufen, bevor sie definiert ist?")
    erwarte(BEFEHLE in a, "Vor der ersten Eingabe steht keine Befehlsliste -- wird hilfe() beim Start gerufen?")
    erwarte("warte" in a, "Die Befehlsliste nennt warte <n> noch nicht.")


def pruefe_22_hilfe_befehl():
    """Aufgabe 2 · Der Befehl hilfe ruft die Funktion"""
    braucht(funktion("hilfe") is not None)
    aus, abbruch = _spiel(["hilfe", "ende"])
    erwarte(not abbruch and BEFEHLE in _nach(aus, "hilfe"),
            "Nach hilfe steht keine Befehlsliste -- fehlen beim Aufruf die Klammern?")


def pruefe_23_hilfe_einmal():
    """Aufgabe 2 · Die Befehlsliste steht nur einmal im Programm"""
    braucht(funktion("hilfe") is not None)
    erwarte(_anzahl(BEFEHLE) == 1,
            "„Befehle:“ steht noch mehr als einmal im Programm -- steht eine Kopie neben dem Aufruf?")


# ── Aufgabe 2 ★★ · Der Raum, sobald ihr ihn betretet ───────────────────

def pruefe_24_zeige_raum_funktion():
    """Aufgabe 2 ★★ · zeige_raum ist eine Funktion"""
    braucht(_anzahl("def zeige_raum") > 0 or funktion("zeige_raum") is not None)
    erwarte(funktion("zeige_raum") is not None,
            "def zeige_raum steht da, aber Python kennt die Funktion nicht -- bricht das Programm vorher ab?")


def pruefe_25_start():
    """Aufgabe 2 ★★ · Am Anfang zeigt das Spiel den Flur"""
    braucht(funktion("zeige_raum") is not None)
    aus, abbruch = _spiel(["ende"])
    a = _anfang(aus)
    erwarte(not abbruch, "Das Spiel bricht am Anfang ab -- hat hier schon einen Wert, wenn zeige_raum() "
            "zum ersten Mal gerufen wird?")
    erwarte(FLUR in a and _strichliste(a) == ["kreide"],
            "Vor der ersten Eingabe steht nicht der Flur mit „Hier liegt:“ und der Kreide.")


def pruefe_26_beim_betreten():
    """Aufgabe 2 ★★ · Nach westen zeigt das Spiel den Keller -- mit dem, was dort liegt"""
    braucht(funktion("zeige_raum") is not None)
    aus, abbruch = _spiel(["westen", "ende"])
    k = _nach(aus, "westen")
    dinge = _strichliste(k)
    erwarte(not abbruch, "Nach westen bricht das Spiel ab.")
    erwarte(KELLER in k, "Nach westen steht nicht die Beschreibung des Kellers -- wird zeige_raum() nach dem Gehen gerufen?")
    erwarte("torschlüssel" in dinge,
            "Nach westen zeigt der Keller nicht den Torschlüssel -- liest zeige_raum() noch die Liste des Flurs? "
            "Wann wird hier gesetzt?")


def pruefe_27_zurueck():
    """Aufgabe 2 ★★ · Zurück im Flur liegt dort wieder die Kreide"""
    braucht(funktion("zeige_raum") is not None)
    aus, abbruch = _spiel(["westen", "osten", "ende"])
    f = _nach(aus, "osten")
    erwarte(not abbruch and FLUR in f and _strichliste(f) == ["kreide"],
            "Nach westen und osten zeigt der Flur nicht genau die Kreide.")


def pruefe_28_schau():
    """Aufgabe 2 ★★ · schau ruft die Funktion -- und ohne Lampe ist es dunkel"""
    braucht(funktion("zeige_raum") is not None)
    aus, abbruch = _spiel(["osten", "schau", "lege lampe", "schau", "ende"])
    erwarte(not abbruch, "Bei schau oder lege bricht das Spiel ab.")
    erwarte(INFO in _nach(aus, "schau"), "Im Informatikraum zeigt schau den Raum nicht.")
    erwarte(DUNKEL in _nach(aus, "schau", 2), "Nach lege lampe ist es bei schau nicht stockdunkel.")


def pruefe_29_einmal():
    """Aufgabe 2 ★★ · Der Block steht nur einmal im Programm"""
    braucht(funktion("zeige_raum") is not None)
    erwarte(_anzahl("Du stehst jetzt im") == 0,
            "„Du stehst jetzt im“ steht noch im Programm -- nach dem Gehen zeigt zeige_raum() den Raum.")
    erwarte(_anzahl(DUNKEL) == 1 and _anzahl("Hier liegt:") == 1,
            "„Stockdunkel“ oder „Hier liegt:“ steht mehr als einmal im Programm -- steht noch eine Kopie des Blocks da?")
    erwarte(_im_rumpf("zeige_raum", "Hier liegt:"), "„Hier liegt:“ steht nicht im Rumpf von zeige_raum.")


# ── Aufgabe 2 ★★★ · Der Rucksack und das Tor ───────────────────────────

def pruefe_2a_zeige_rucksack():
    """Aufgabe 2 ★★★ · zeige ruft zeige_rucksack()"""
    braucht(funktion("zeige_rucksack") is not None)
    aus, abbruch = _spiel(["nimm kreide", "zeige", "ende"])
    z = _nach(aus, "zeige")
    erwarte(not abbruch and re.search(r"\b2 Dinge", z) is not None and _strichliste(z) == ["lampe", "kreide"],
            "Nach nimm kreide und zeige steht nicht „Du trägst 2 Dinge:“ mit Lampe und Kreide.")
    erwarte(_anzahl("Du trägst") == 1 and _im_rumpf("zeige_rucksack", "Du trägst"),
            "„Du trägst“ steht nicht genau einmal im Programm, im Rumpf von zeige_rucksack.")


def pruefe_2b_pruefe_tuer():
    """Aufgabe 2 ★★★ · pruefe_tuer() sagt die Sätze am Tor"""
    braucht(funktion("pruefe_tuer") is not None)
    aus, abbruch = _spiel(["norden", "westen", "nimm torschlüssel", "osten", "norden"])
    erwarte(not abbruch, "Am Tor bricht das Spiel ab.")
    erwarte(ZU in _nach(aus, "norden"), "Ohne Torschlüssel steht nach norden nicht „Abgeschlossen. …“.")
    erwarte(DRAUSSEN in aus, "Mit dem Torschlüssel geht das Tor nicht auf.")
    erwarte(_anzahl(ZU) == 1 and _im_rumpf("pruefe_tuer", ZU),
            "„Abgeschlossen“ steht nicht genau einmal im Programm, im Rumpf von pruefe_tuer.")


# ── Aufgabe 8 ★★ · Mehr: Nur wenn sich etwas aendert ───────────────────

def pruefe_80_nur_neu():
    """Aufgabe 8 ★★ · An der Wand zeigt das Spiel den Raum nicht noch einmal"""
    braucht("vorher" in ohne_kommentare())
    braucht(funktion("zeige_raum") is not None)
    aus, abbruch = _spiel(["osten", "osten", "westen", "ende"])
    erwarte(not abbruch, "Bei osten oder westen bricht das Spiel ab.")
    erwarte(INFO in _nach(aus, "osten"), "Nach dem ersten osten zeigt das Spiel den Informatikraum nicht mehr.")
    erwarte(INFO not in _nach(aus, "osten", 2) and "Wand" in _nach(aus, "osten", 2),
            "Nach osten gegen die Wand zeigt das Spiel den Informatikraum noch einmal.")
    erwarte(FLUR in _nach(aus, "westen"), "Nach westen zeigt das Spiel den Flur nicht.")


# ── Aufgabe 9 ★★★★ · Mehr: Uhr und Ueberblick ───────────────────────────

def pruefe_90_uhr():
    """Aufgabe 9 ★★★★ · uhr zeigt die Spielzeit, mitten im Spiel"""
    braucht('"uhr"' in ohne_kommentare() or "'uhr'" in ohne_kommentare())
    aus, abbruch = _spiel(["uhr", "warte 2", "uhr", "ende"])
    erste, zweite = _nach(aus, "uhr"), _nach(aus, "uhr", 2)
    erwarte(not abbruch, "Bei uhr bricht das Spiel ab.")
    erwarte(re.search(r"Spielzeit:\s*0 min 45 s", erste) is not None,
            "Nach dem ersten uhr (ein Zug, 45 Sekunden) steht nicht „Spielzeit: 0 min 45 s“.")
    erwarte(re.search(r"Spielzeit:\s*3 min 45 s", zweite) is not None,
            "Nach uhr, warte 2 und uhr steht nicht „Spielzeit: 3 min 45 s“.")
    erwarte(funktion("zeige_zeit") is not None and _anzahl("Spielzeit:") == 1,
            "„Spielzeit:“ steht nicht genau einmal im Programm, in einer Funktion zeige_zeit.")
    erwarte(re.search(r"Spielzeit:", aus[aus.find(TREPPE):]) is not None,
            "Am Ende des Spiels steht keine Spielzeit mehr -- wird zeige_zeit() dort gerufen?")


def pruefe_91_ueberblick():
    """Aufgabe 9 ★★★★ · überblick zeigt Raum, Rucksack und Zeit"""
    braucht("überblick" in ohne_kommentare())
    aus, abbruch = _spiel(["westen", "überblick", "ende"])
    u = _nach(aus, "überblick")
    erwarte(not abbruch, "Bei überblick bricht das Spiel ab.")
    erwarte(KELLER in u and "Du trägst" in u and "Spielzeit:" in u,
            "Nach überblick im Keller stehen nicht Raum, Rucksack und Spielzeit.")
    erwarte(_ruft_drei(), "Keine Funktion ruft zeige_raum(), zeige_rucksack() und zeige_zeit().")


# ── Aufgabe 10 ★★★★ · Mehr, Expertenaufgabe: Eine Stelle fuer jede Sache ─
# Der Check aendert EINE Stelle und spielt alle an (die Idee des Themas, am Verhalten geprueft).

def _hat_platz():
    """Steht oben (nicht eingerueckt) ein Kaestchen platz = …?"""
    return re.search(r"^platz[ \t]*=", ohne_kommentare(), re.M) is not None


def _begonnen_10():
    """Hat das Paar mit Aufgabe 10 angefangen? Im Startzustand steht der Satz an der Wand dreimal da, platz gibt es
    nicht -- dann ist die Aufgabe noch nicht dran."""
    return re.search(r"\bplatz\b", ohne_kommentare()) is not None or _anzahl(WAND) < 3


def _spiel_mauer(befehle):
    """Wie _spiel, aber vorher wird der Satz an der Wand an seiner ERSTEN Stelle geaendert (Wand -> Mauer);
    Kommentarzeilen zaehlen nicht. Gibt (aus, abbruch, geaendert)."""
    alt = pruefen._QUELLE
    zeilen, geaendert = alt.split("\n"), False
    for i, z in enumerate(zeilen):
        if WAND in z and not z.strip().startswith("#"):
            zeilen[i] = z.replace(WAND, MAUER, 1)
            geaendert = True
            break
    pruefen._QUELLE = "\n".join(zeilen)
    try:
        aus, abbruch = _spiel(befehle)
    finally:
        pruefen._QUELLE = alt
    return aus, abbruch, geaendert


def pruefe_a0_wand():
    """Aufgabe 10 ★★★★ · Ein Wort im Satz an der Wand geändert -- alle drei Wände sagen es"""
    braucht(_begonnen_10())
    aus, abbruch, geaendert = _spiel_mauer(["osten", "osten", "westen", "süden", "süden", "norden", "westen", "westen", "ende"])
    erwarte(geaendert, "Der Satz an der Wand steht nicht mehr im Programm.")
    erwarte(not abbruch, "Beim Lauf gegen die Wände bricht das Spiel ab.")
    orte = [("im Informatikraum", _nach(aus, "osten", 2)), ("im Lehrerzimmer", _nach(aus, "süden", 2)),
            ("im Keller", _nach(aus, "westen", 3))]
    stumm = [ort for ort, text in orte if MAUER not in text and WAND not in text]
    erwarte(not stumm, "An der Wand %s sagt das Spiel den Satz nicht mehr." % (stumm[0] if stumm else ""))
    alt = [ort for ort, text in orte if WAND in text]
    erwarte(not alt, "Der Selbstcheck hat den Satz an der Wand dort geändert, wo er zuerst steht -- %s sagt das Spiel "
            "noch den alten Satz." % (alt[0] if alt else ""))


def pruefe_a1_platz():
    """Aufgabe 10 ★★★★ · platz geändert -- die Grenze und ihr Satz gehen mit"""
    braucht(_begonnen_10())
    erwarte(_hat_platz(), "Oben steht noch kein Kästchen platz für die Grenze des Rucksacks.")
    # je Grenze: die Befehle, das letzte nimm, das noch klappen muss, und das erste, das zu viel ist
    # (Befehl und das wievielte Mal er in der Folge steht) -- die Lampe ist das erste Ding
    for grenze, befehle, gut, zu_viel in (
            (2, ["nimm kreide", "osten", "nimm stick", "ende"], ("nimm kreide", 1), ("nimm stick", 1)),
            (3, ["nimm kreide", "osten", "nimm stick", "nimm kreide", "ende"], ("nimm stick", 1), ("nimm kreide", 2)),
            (6, ["nimm kreide", "osten", "nimm stick", "nimm kreide", "westen", "süden", "nimm seil", "nimm apfel",
                 "nimm kreide", "ende"], ("nimm apfel", 1), ("nimm kreide", 3))):
        aus, abbruch = _spiel(befehle, platz=grenze)
        passt_noch, satz = _nach(aus, gut[0], gut[1]), _nach(aus, zu_viel[0], zu_viel[1])
        erwarte(not abbruch, "Mit platz = %d bricht das Spiel beim Nehmen ab." % grenze)
        erwarte("Du nimmst" in passt_noch,
                "Mit platz = %d ist der Rucksack schon voll, bevor %d Dinge darin sind." % (grenze, grenze))
        erwarte("Du nimmst" not in satz,
                "Mit platz = %d nimmt das Spiel noch ein Ding mehr, als hineinpasst." % grenze)
        erwarte(VOLL in satz, "Mit platz = %d sagt das Spiel nicht mehr, dass der Rucksack voll ist." % grenze)
        erwarte(re.search(r"\b%d\b" % grenze, satz) is not None and "echs" not in satz,
                "Mit platz = %d nennt der Satz zum vollen Rucksack nicht die %d." % (grenze, grenze))
