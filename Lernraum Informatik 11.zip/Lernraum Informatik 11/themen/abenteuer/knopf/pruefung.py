"""Selbstcheck zu "Oberflächen und Ereignisse" -- prueft wegweiser.py (Aufgabe 3, unter Mehr 7, 9 und 10).

Das erste Thema mit Fenster (Teil III, 25.10.). Der Check oeffnet kein Fenster: pruefen.py baut es unsichtbar und
klickt die Knoepfe ueber ihre Beschriftung (klick, knopf, labeltexte -- LIESMICH „Fenster (tkinter) im Lernraum“).
klick() ist selbst ein Befund, wenn es den Knopf nicht gibt, wenn er mit command=f() keine Funktion bekommen hat
oder wenn die Funktion abbricht. Den Raum stellt der Check selbst ein (_raum): Wer fuer ★★ oben raum = "keller"
stehen laesst, besteht trotzdem ★.

Umbau Lauf i11 (17.11.2026): Die Nummern sind neu (Vorrat 6 -> Mehr 7, Kuer 7 -> Mehr 9), dazu die Expertenaufgabe 10
(die Ampel ohne if). Zwei Pruefungen lesen am Knopf ab, WELCHE Funktion er bekommen hat (_ruft): „Ende“ -- statt wie
bis dahin im Quelltext nach command=fenster.destroy zu suchen (LC6: nie ueber Woerter im Quelltext) -- und die Ampel,
deren Auflage (nichts fragen, nichts merken) genau dann erfuellt ist, wenn der Knopf nach jedem Klick eine andere
Funktion ruft als davor.
"""
import ast
import re

from pruefen import (erwarte, braucht, funktion, fenster, elemente, knopf, klick, labeltexte, ohne_kommentare,
                     quelltext)

TITEL = "Oberflächen und Ereignisse · Selbstcheck"

# Was jede Funktion zurueckgibt -- der Hinweis prueft auch, ob der Type Hint stimmt (wie in zusammen;
# Reihensichtung Teil III, 27.10., Befund 7).
HINTS = {"ziel": "str", "dinge_im": "list[str]", "aufzaehlen": "str", "norden": "None", "osten": "None",
         "sueden": "None", "westen": "None", "was_liegt_hier": "None", "hilfe": "None", "licht": "None"}


def _raum(name):
    """Setzt das Kaestchen raum, das die Knopf-Funktionen lesen (ihre globalen Namen)."""
    f = funktion("ziel") or funktion("norden")
    if f is not None:
        f.__globals__["raum"] = name


def _anzeige():
    """Was nach dem letzten Klick im Fenster steht -- alle Labels zusammen."""
    return " | ".join(labeltexte())


def _ruft(b):
    """Der Name der Funktion, die ein Knopf bekommen hat ("" = keine). tkinter haengt beim Verbinden eine Nummer vor
    den Namen der Funktion (Misc._register: repr(id(...)) + func.__name__); die Nummer faellt hier weg."""
    return re.sub(r"^\d+", "", str(b.cget("command")))


def _ampel():
    """Der Knopf der Ampel -- der erste, dessen Aufschrift mit „Ampel“ beginnt -- oder None."""
    for b in elemente("Button"):
        if str(b.cget("text")).strip().lower().startswith("ampel"):
            return b
    return None


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [k for k in baum.body if isinstance(k, ast.FunctionDef)]


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_fenster():
    """Grundlage · Das Programm baut ein Fenster mit den Knöpfen Norden und Osten"""
    erwarte(fenster() is not None, "Das Programm baut kein Fenster -- steht fenster = tk.Tk() noch da?")
    erwarte(knopf("Norden") is not None and knopf("Osten") is not None,
            "Die Knöpfe Norden und Osten aus der Vorlage fehlen.")
    _raum("flur")
    klick("Norden")
    erwarte("Tor" in _anzeige(), "Nach einem Klick auf Norden steht im Fenster nicht, dass dort das Tor liegt.")


# ── Aufgabe 3 · Der Wegweiser ────────────────────────────────────────────

def pruefe_30_vier():
    """Aufgabe 3 · Süden und Westen sagen, wohin es geht"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil III, 27.10., Befund 1: vorher „x von x passen“ ohne naechsten Schritt).
    erwarte(knopf("Süden") is not None or knopf("Westen") is not None,
            "Noch zeigt der Wegweiser nur Norden und Osten -- Süden und Westen fehlen.")
    _raum("flur")
    klick("Süden")
    erwarte("Lehrerzimmer" in _anzeige(), "Nach Süden steht nicht das Lehrerzimmer im Fenster (sondern: %s)." % _anzeige())
    klick("Westen")
    erwarte("Keller" in _anzeige(), "Nach Westen steht nicht der Keller im Fenster (sondern: %s)." % _anzeige())


def pruefe_31_wand():
    """Aufgabe 3 ★★ · An einer Wand sagt der Wegweiser „eine Wand“"""
    braucht("wand" in ohne_kommentare().lower(), "Noch kein Satz für die Wand.")
    braucht(knopf("Süden") is not None and knopf("Westen") is not None, "Erst alle vier Richtungen.")
    _raum("keller")
    for richtung, steht in (("Norden", "Wand"), ("Osten", "Flur"), ("Westen", "Wand"), ("Süden", "Bibliothek")):
        klick(richtung)
        jetzt = _anzeige()
        erwarte(steht in jetzt, "Im Keller nach %s steht „%s“ -- erwartet war: %s." % (richtung, jetzt, steht))
    _raum("informatikraum")
    klick("Norden")
    erwarte("Wand" in _anzeige(), "Im Informatikraum nach Norden fehlt die Wand.")


def pruefe_32_hier():
    """Aufgabe 3 ★★★ · Was liegt hier? zählt auf wie im Spiel"""
    braucht(knopf("Was liegt hier?") is not None, "Noch kein Knopf „Was liegt hier?“.")
    _raum("flur")
    klick("Was liegt hier?")
    erwarte("Hier liegt: Kreide." in _anzeige(), "Im Flur sollte „Hier liegt: Kreide.“ stehen (es steht: %s)." % _anzeige())
    _raum("informatikraum")
    klick("Was liegt hier?")
    erwarte("Hier liegt: Stick und Kreide." in _anzeige(),
            "Im Informatikraum sollte „Hier liegt: Stick und Kreide.“ stehen (es steht: %s)." % _anzeige())


def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(knopf("Süden") is not None or knopf("Westen") is not None)
    ohne, falsch = [], []
    for k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, HINTS[k.name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 7 · Mehr: Hilfe und Ende ─────────────────────────────────────

def pruefe_70_hilfe():
    """Aufgabe 7 ★★ · Ein Knopf Hilfe schreibt etwas ins Label"""
    braucht(knopf("Hilfe") is not None, "Noch kein Knopf „Hilfe“.")
    _raum("flur")
    klick("Norden")
    vorher = _anzeige()
    klick("Hilfe")
    erwarte(_anzeige() != vorher and _anzeige().strip() != "", "Nach einem Klick auf Hilfe steht im Fenster nichts Neues.")


def pruefe_71_ende():
    """Aufgabe 7 ★★★ · Ein Knopf Ende schließt das Fenster mit fenster.destroy"""
    braucht(knopf("Ende") is not None, "Noch kein Knopf „Ende“.")
    # Der Check klickt hier NICHT: Ein Klick schloesse das eine Fenster, das sich alle Pruefungen teilen. Er liest am
    # Knopf ab, welche Funktion er bekommen hat.
    ruft = _ruft(knopf("Ende"))
    erwarte(ruft != "", "Der Knopf Ende hat keine Funktion bekommen -- ein Klick tut nichts.")
    erwarte(ruft == "destroy", "Der Knopf Ende ruft nicht fenster.destroy -- die fertige Funktion zum Schließen "
            "(er ruft: %s)." % ruft)


# ── Aufgabe 9 · Mehr: Licht an, Licht aus ───────────────────────────────

def _dunkel():
    for w in fenster().winfo_children():
        if w.winfo_class() == "Label" and str(w.cget("bg")).lower() in ("black", "#000000", "#000"):
            return True
    return False


def pruefe_90_licht():
    """Aufgabe 9 ★★★ · Licht aus macht das Label dunkel, Licht an wieder hell"""
    braucht(knopf("Licht aus") is not None or knopf("Licht an") is not None, "Noch kein Schalter.")
    erwarte(knopf("Licht aus") is not None, "Am Anfang sollte der Schalter „Licht aus“ heißen.")
    klick("Licht aus")
    erwarte(_dunkel(), "Nach Licht aus ist kein Label schwarz.")
    erwarte(knopf("Licht an") is not None, "Nach dem Klick sollte der Knopf „Licht an“ heißen.")
    klick("Licht an")
    erwarte(not _dunkel() and knopf("Licht aus") is not None, "Licht an schaltet nicht zurück.")


# ── Aufgabe 10 · Mehr, fuer Expert*innen: Die Ampel ohne if ──────────────
# Sechs Klicks, zwei ganze Runden -- danach steht die Ampel wieder auf rot, wie am Anfang (die Pruefungen teilen sich
# ein Fenster). Die erste Pruefung liest nur die Aufschrift; die zweite die Auflage, am Knopf selbst.

FARBEN = ("grün", "gelb", "rot", "grün", "gelb", "rot")


def _ampel_klicken():
    """Klickt die Ampel sechsmal. Gibt je Klick zurueck: (Aufschrift danach, Funktion davor, Funktion danach)."""
    schritte = []
    for _ in FARBEN:
        b = _ampel()
        if b is None:
            break
        davor = _ruft(b)
        klick(str(b.cget("text")))
        b = _ampel()
        schritte.append((str(b.cget("text")).strip() if b is not None else "", davor, _ruft(b) if b is not None else ""))
    return schritte


def pruefe_a0_ampel_schaltet():
    """Aufgabe 10 ★★★★ · Die Ampel schaltet: rot, grün, gelb und wieder rot"""
    braucht(_ampel() is not None, "Noch keine Ampel.")
    anfang = str(_ampel().cget("text")).strip()
    erwarte(anfang.lower() == "ampel: rot", "Am Anfang sollte auf dem Knopf „Ampel: rot“ stehen (es steht: %s)." % anfang)
    schritte = _ampel_klicken()
    for nr, (farbe, schritt) in enumerate(zip(FARBEN, schritte), start=1):
        steht = schritt[0]
        erwarte(steht.lower() == "ampel: " + farbe,
                "Nach dem %d. Klick sollte „Ampel: %s“ auf dem Knopf stehen (es steht: %s)." % (nr, farbe, steht))
    erwarte(len(schritte) == len(FARBEN), "Nach einem Klick gibt es keinen Knopf mehr, dessen Aufschrift mit „Ampel“ beginnt.")


def pruefe_a1_ampel_auflage():
    """Aufgabe 10 ★★★★ · … ohne zu fragen und ohne sich etwas zu merken"""
    braucht(_ampel() is not None, "Noch keine Ampel.")
    schritte = _ampel_klicken()
    braucht(len(schritte) == len(FARBEN) and all(s[0].lower() == "ampel: " + f for f, s in zip(FARBEN, schritte)),
            "Erst muss die Ampel richtig schalten.")
    gleich = [nr for nr, s in enumerate(schritte, start=1) if s[1] == s[2]]
    erwarte(not gleich, "Die Ampel schaltet richtig. Aber nach dem %d. Klick ruft der Knopf noch dieselbe Funktion wie "
            "davor (%s) -- dann muss diese Funktion etwas fragen oder sich etwas merken, und das verbietet die Auflage."
            % (gleich[0] if gleich else 0, schritte[gleich[0] - 1][1] if gleich else ""))
