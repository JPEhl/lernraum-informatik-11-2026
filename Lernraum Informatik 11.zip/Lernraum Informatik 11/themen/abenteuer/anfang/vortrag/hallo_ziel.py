# Die ersten Zeilen des Spiels. Jede Zeile, die das Spiel sagen soll, ist ein print.
print("DIE SCHULE BEI NACHT")
print("Du stehst im Flur.")
print()
print("Nur deine Lampe", "leuchtet.")
