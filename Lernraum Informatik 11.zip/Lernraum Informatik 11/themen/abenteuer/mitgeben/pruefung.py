"""Selbstcheck zu "Parameter" -- prueft mitgeben.py (Aufgabe 2, 3, 5 ★★, unter Mehr die Aufgaben 8, 9 und 10).

Zwei Wege, wie in "Rückgabewerte":
- Das Spiel mit einer FOLGE von Befehlen anspielen und die Antwort auf jeden Befehl herausschneiden
  (_nach): Steht der Raum in einem Satz da? Kommt man in den Keller?
- Eine Funktion SELBST rufen (_rufen), jetzt mit ARGUMENTEN: aufzaehlen(["seil", "apfel"]),
  ziel("flur", "westen"). Mit eigenen Listen faellt auf, wer im Rumpf noch `rucksack` statt des
  Parameters liest -- beim Rucksack selbst waere es richtig (Fall in Aufgabe 7).
- Aufgabe 10 (Expertenaufgabe) dreht es um: Die Klasse schreibt probe(), der Check setzt an die Stelle von
  wie_oft nacheinander eine richtige und vier kaputte Fassungen (_rufen mit wie_oft=…) und zaehlt die Aufrufe.

Ob eine Funktion von draussen liest (Aufgabe 3 ★★★), sagt ast: Welche der Namen raum, punkte, zuege
werden im Rumpf gelesen, ohne Parameter oder dort zugewiesen zu sein? Die Type Hints (auch an den
Parametern) mahnt der Check an, bewertet sie aber nicht ("Hinweis · …", keine Stufe).

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code haengt (SCHLUSS).
"""
import ast
import io
import re
import sys

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Parameter · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"
WAND = "Da ist eine Wand"
ZU = "Abgeschlossen"
AUF = "Du schließt das Tor auf."
KELLER = "Der Keller."
SCHLUSS = "§SCHLUSS§"

# Der Lageplan: (raum, richtung) -> ziel; alles andere ist Wand ("")
WEGE = {("flur", "norden"): "tor", ("flur", "osten"): "informatikraum", ("flur", "süden"): "lehrerzimmer",
        ("flur", "westen"): "keller", ("informatikraum", "westen"): "flur", ("lehrerzimmer", "norden"): "flur",
        ("keller", "osten"): "flur"}
RAEUME = ["flur", "informatikraum", "lehrerzimmer", "keller"]
RICHTUNGEN = ["norden", "osten", "süden", "westen"]
SAETZE = [("flur", "Der Flur."), ("informatikraum", "Der Informatikraum."),
          ("lehrerzimmer", "Das Lehrerzimmer."), ("keller", "Der Keller."), ("tor", "Das Haupttor.")]

# Was hinter -> stehen soll, wo der Check es weiss
HINTS = {"hilfe": "None", "zeige_raum": "None", "zeige_rucksack": "None", "pruefe_tuer": "bool",
         "beschreibung": "str", "dinge_im": "list[str]", "dinge_hier": "list[str]", "sterne": "str",
         "aufzaehlen": "str", "ziel": "str", "gehe": "str", "wie_oft": "int", "schaltjahr": "bool",
         "wert": "int", "nimm": "int", "probe": "bool",
         "treffer": "int", "merke": "None"}
VON_DRAUSSEN = ("raum", "punkte", "zuege")

KEIN_WERT = object()


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte. Gibt (aus, abbruch)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, _ = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _zeile(text, anfang):
    """Die Zeile, die mit `anfang` beginnt (ohne den Anfang), sonst None."""
    for z in text.splitlines():
        if z.strip().startswith(anfang):
            return z.strip()[len(anfang):].strip()
    return None


def _anzahl(muster):
    """Wie oft passt das Muster (regulaerer Ausdruck) im Quelltext ohne Kommentare?"""
    return len(re.findall(muster, ohne_kommentare()))


def _rufen(name, *argumente, **werte):
    """Die Funktion `name` mit diesen Argumenten rufen, vorher Variablen draussen setzen (rucksack=[…]).
    Gibt (wert, gedruckt, fehler): was zurueckkam, was sie dabei gedruckt hat, ein Abbruch als Text."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    g = f.__globals__
    alt = {k: g.get(k, KEIN_WERT) for k in werte}
    g.update(werte)
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
        for k, v in alt.items():
            if v is KEIN_WERT:
                g.pop(k, None)
            else:
                g[k] = v
    return wert, puffer.getvalue(), fehler


def _baum():
    try:
        return ast.parse(quelltext())
    except SyntaxError:
        return None


def _defs():
    """Die Funktionen auf oberster Ebene: [(name, Knoten)]."""
    baum = _baum()
    return [] if baum is None else [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _parameter(name):
    """Die Parameter der Funktion `name` (Namen), None, wenn es sie nicht gibt."""
    for n, k in _defs():
        if n == name:
            return [a.arg for a in k.args.args]
    return None


def _ruft(name):
    """Die Namen, die die Funktion `name` in ihrem Rumpf aufruft."""
    gerufen = set()
    for n, k in _defs():
        if n == name:
            for c in ast.walk(k):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Name):
                    gerufen.add(c.func.id)
    return gerufen


def _gerufen_ausser(name):
    """Wird `name` irgendwo ausserhalb seiner eigenen Definition gerufen (Spielschleife oder andere Funktion)?"""
    baum = _baum()
    if baum is None:
        return False
    for k in baum.body:
        if isinstance(k, ast.FunctionDef) and k.name == name:
            continue
        for c in ast.walk(k):
            if isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == name:
                return True
    return False


def _liest_draussen():
    """[(funktion, name)]: raum/punkte/zuege im Rumpf gelesen, aber weder Parameter noch dort zugewiesen."""
    funde = []
    for n, k in _defs():
        params = {a.arg for a in k.args.args}
        gelesen, gesetzt = set(), set()
        for c in ast.walk(k):
            if isinstance(c, ast.Name):
                (gelesen if isinstance(c.ctx, ast.Load) else gesetzt).add(c.id)
        for v in VON_DRAUSSEN:
            if v in gelesen and v not in params and v not in gesetzt:
                funde.append((n, v))
    return funde


def _aufzaehlen_da():
    return _parameter("aufzaehlen") is not None and len(_parameter("aufzaehlen")) == 1


def _ziel_da():
    return _parameter("ziel") is not None and len(_parameter("ziel")) == 2


def _gehe_da():
    return _parameter("gehe") is not None and len(_parameter("gehe")) == 2


def _komma_form(text):
    """„Seil, Apfel und Kreide“ und „seil, apfel, kreide“ als dieselbe Folge: [seil, apfel, kreide]."""
    t = str(text).lower().replace(" und ", ", ")
    return [x.strip() for x in t.split(",")] if t.strip() else []


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Rückgabewerte“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- fehlt einem Aufruf ein Argument, oder wird "
            "eine Funktion gerufen, bevor sie definiert ist?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende steht „Deine Sterne:“ nicht mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 · Das Spiel zählt auf ─────────────────────────────────────

def pruefe_20_aufzaehlen():
    """Aufgabe 2 · aufzaehlen(liste) liefert die Dinge in einem Satz -- für jede Liste"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil II, 25.10., Befund 6: vorher „2 von 2 passen“ ohne naechsten Schritt).
    erwarte(_aufzaehlen_da(), "Noch zählen zwei Funktionen je ihre Liste auf -- es gibt keine Funktion aufzaehlen, "
            "die die Liste mitbekommt.")
    for liste in (["seil", "apfel", "kreide"], ["lampe", "stick"], ["pausenbrot"]):
        wert, gedruckt, fehler = _rufen("aufzaehlen", list(liste), rucksack=["lampe"])
        erwarte(fehler is None, "aufzaehlen(%r) bricht ab: %s" % (liste, fehler))
        erwarte(not gedruckt.strip(),
                "aufzaehlen() druckt die Dinge, statt den Satz zurückzugeben -- es kommt %r zurück." % (wert,))
        erwarte(isinstance(wert, str),
                "aufzaehlen(%r) gibt keinen Text zurück, sondern %r." % (liste, wert))
        erwarte(_komma_form(wert) == liste,
                "aufzaehlen(%r) liefert %r -- läuft die Schleife über den Parameter? Mit dem Rucksack "
                "allein fällt es nicht auf." % (liste, wert))


def pruefe_21_im_spiel():
    """Aufgabe 2 · Raum und Rucksack stehen in einem Satz -- mit derselben Funktion"""
    braucht(_aufzaehlen_da())
    # Das Spiel beginnt fuer diese Pruefung im Lehrerzimmer (Startwert oben ersetzt) und fragt mit schau -- bis zum
    # Umbau ging der Check mit „süden“ hin: Dann faerbte jeder Fehler am Gehen (Aufgabe 3, etwa vertauschte
    # Argumente) auch Aufgabe 2 rot, mit einer Meldung, die auf das Aufzaehlen zeigte (Giftprobe, Lauf i11).
    aus, abbruch = _spiel(["schau", "nimm seil", "zeige", "ende"], raum="lehrerzimmer")
    hier, traegt = _zeile(_nach(aus, "schau"), "Hier liegt:"), _zeile(_nach(aus, "zeige"), "Du trägst")
    erwarte(not abbruch, "Bei schau, nimm oder zeige bricht das Spiel ab.")
    erwarte(hier is not None and _komma_form(hier.rstrip(".")) == ["seil", "apfel", "kreide"],
            "Im Lehrerzimmer steht nicht „Hier liegt: seil, apfel, kreide.“ in einer Zeile.")
    erwarte(traegt is not None and _komma_form(traegt.lstrip(":").strip().rstrip(".")) == ["lampe", "seil"],
            "Nach nimm seil und zeige steht nicht „Du trägst: lampe, seil.“ in einer Zeile.")
    erwarte("aufzaehlen" in _ruft("zeige_raum") and "aufzaehlen" in _ruft("zeige_rucksack"),
            "zeige_raum() und zeige_rucksack() rufen nicht beide aufzaehlen().")
    erwarte(_anzahl(r"""print\(\s*["']\s+-["']""") == 0, "Eine Schleife druckt die Dinge noch mit Strich untereinander.")


def pruefe_22_wie_ein_mensch():
    """Aufgabe 2 ★★ · aufzaehlen() zählt auf wie ein Mensch"""
    braucht(_aufzaehlen_da())
    for liste, soll in ((["seil", "apfel", "kreide"], "Seil, Apfel und Kreide"), (["lampe", "stick"], "Lampe und Stick"),
                        (["lampe"], "Lampe"), (["a", "b", "c", "d"], "A, B, C und D")):
        wert, _, fehler = _rufen("aufzaehlen", list(liste), rucksack=["lampe"])
        erwarte(fehler is None, "aufzaehlen(%r) bricht ab: %s" % (liste, fehler))
        erwarte(wert == soll, "aufzaehlen(%r) liefert %r, nicht %r." % (liste, wert, soll))
    aus, abbruch = _spiel(["schau", "ende"], raum="lehrerzimmer")
    erwarte("Hier liegt: Seil, Apfel und Kreide." in _nach(aus, "schau"),
            "Im Lehrerzimmer steht nicht „Hier liegt: Seil, Apfel und Kreide.“")


def pruefe_23_leer():
    """Aufgabe 2 ★★★ · Leere Listen: kein „Hier liegt: .“, ein leerer Rucksack sagt es"""
    braucht(_aufzaehlen_da())
    wert, _, fehler = _rufen("aufzaehlen", [], rucksack=["lampe"])
    erwarte(fehler is None, "aufzaehlen([]) bricht ab: %s" % fehler)
    erwarte(wert == "", "aufzaehlen([]) liefert %r, nicht den leeren Text." % (wert,))
    aus, abbruch = _spiel(["nimm kreide", "schau", "lege kreide", "lege lampe", "zeige", "ende"])
    erwarte(not abbruch, "Bei schau oder zeige mit leeren Listen bricht das Spiel ab.")
    erwarte("Hier liegt" not in _nach(aus, "schau"),
            "Im leeren Flur steht nach schau noch eine Zeile „Hier liegt …“.")
    erwarte("Dein Rucksack ist leer." in _nach(aus, "zeige"),
            "Mit leerem Rucksack (nach lege kreide und lege lampe) steht nach zeige nicht "
            "„Dein Rucksack ist leer.“")


# ── Aufgabe 3 · Ein Weg für alle Richtungen ─────────────────────────────

def pruefe_30_ziel():
    """Aufgabe 3 · ziel(raum, richtung) kennt den ganzen Lageplan"""
    braucht(_ziel_da(), "Es gibt noch keine Funktion ziel mit zwei Parametern.")
    for raum in RAEUME:
        for richtung in RICHTUNGEN:
            soll = WEGE.get((raum, richtung), "")
            wert, gedruckt, fehler = _rufen("ziel", raum, richtung, rucksack=["lampe"])
            erwarte(fehler is None, "ziel(%r, %r) bricht ab: %s" % (raum, richtung, fehler))
            erwarte(not gedruckt.strip(), "ziel() druckt etwas -- sie soll nur den Raum zurückgeben.")
            erwarte(wert is not None, "ziel(%r, %r) liefert None -- fehlt unten return \"\"?" % (raum, richtung))
            erwarte(wert == soll, "ziel(%r, %r) liefert %r, nicht %r." % (raum, richtung, wert, soll))


def pruefe_31_ziel_im_spiel():
    """Aufgabe 3 · Im Spiel führen die Wege, wohin ziel() sagt"""
    braucht(_ziel_da())
    aus, abbruch = _spiel(["westen", "osten", "osten", "osten", "ende"])
    erwarte(not abbruch, "Beim Gehen bricht das Spiel ab.")
    erwarte(KELLER in _nach(aus, "westen"), "Nach westen steht nicht „Der Keller. …“.")
    erwarte("Der Informatikraum." in _nach(aus, "osten", 2), "Vom Flur nach osten kommt ihr nicht in den Informatikraum.")
    erwarte(WAND in _nach(aus, "osten", 3), "Im Informatikraum nach osten steht nicht der Wand-Satz.")
    erwarte(_gerufen_ausser("ziel"), "Niemand fragt ziel() -- weder die Spielschleife noch eine andere Funktion.")


def pruefe_32_gehe():
    """Aufgabe 3 ★★ · gehe(raum, richtung) gibt den neuen Raum zurück"""
    braucht(_gehe_da())
    for raum, richtung, rs, soll, satz in (("flur", "osten", ["lampe"], "informatikraum", ""),
                                           ("informatikraum", "osten", ["lampe"], "informatikraum", WAND),
                                           ("flur", "norden", ["lampe"], "flur", ZU),
                                           ("flur", "norden", ["lampe", "torschlüssel"], "tor", AUF)):
        wert, gedruckt, fehler = _rufen("gehe", raum, richtung, rucksack=rs)
        erwarte(fehler is None, "gehe(%r, %r) bricht ab: %s" % (raum, richtung, fehler))
        erwarte(wert == soll, "gehe(%r, %r)%s liefert %r, nicht %r -- gibt sie den neuen Raum zurück?"
                % (raum, richtung, " mit Torschlüssel" if "torschlüssel" in rs else "", wert, soll))
        erwarte(not satz or satz in gedruckt, "gehe(%r, %r) sagt nicht „%s …“." % (raum, richtung, satz))


def pruefe_33_gehe_im_spiel():
    """Aufgabe 3 ★★ · Die Spielschleife geht mit einer Zeile: raum = gehe(…)"""
    braucht(_gehe_da())
    aus, abbruch = _spiel(["norden", "westen", "nimm torschlüssel", "osten", "norden"])
    erwarte(not abbruch, "Am Tor bricht das Spiel ab.")
    erwarte(ZU in _nach(aus, "norden"), "Ohne Torschlüssel steht nach norden nicht „Abgeschlossen. …“.")
    erwarte(DRAUSSEN in aus, "Mit dem Torschlüssel kommt ihr nicht durchs Tor.")
    erwarte(re.search(r"\braum\s*=\s*gehe\(", ohne_kommentare()) is not None,
            "In der Spielschleife steht nicht raum = gehe(…) -- die Antwort von gehe() muss ins Kästchen raum.")
    erwarte(_anzahl(r'\braum\s*=\s*"(keller|lehrerzimmer|informatikraum)"') == 0,
            "In der Spielschleife steht noch die alte Kette mit raum = \"keller\" …")


def pruefe_34_nicht_von_draussen():
    """Aufgabe 3 ★★★ · Keine Funktion liest raum, punkte oder zuege von draußen"""
    braucht(_gehe_da() and _parameter("beschreibung") not in (None, []))
    for raum, anfang in SAETZE:
        wert, _, fehler = _rufen("beschreibung", raum)
        erwarte(fehler is None, "beschreibung(%r) bricht ab: %s" % (raum, fehler))
        erwarte(isinstance(wert, str) and wert.startswith(anfang),
                "beschreibung(%r) liefert nicht den Satz, der mit „%s“ beginnt." % (raum, anfang))
    erwarte(_parameter("dinge_im") is not None, "Es gibt keine Funktion dinge_im(raum).")
    funde = _liest_draussen()
    erwarte(not funde, "Diese Funktionen lesen noch von draußen: %s -- gebt den Wert als Parameter mit."
            % ", ".join("%s liest %s" % f for f in funde))
    aus, abbruch = _spiel(["westen", "nimm pausenbrot", "zeige", "nimm torschlüssel", "osten", "norden"])
    erwarte(not abbruch and DRAUSSEN in aus, "Das ganze Spiel bis zum Tor läuft nicht mehr durch.")
    erwarte(re.search(r"Punkte:\s*10\s*-\s*Züge übrig:\s*27", _nach(aus, "zeige")) is not None,
            "Nach westen, nimm pausenbrot und zeige steht nicht „Punkte: 10 - Züge übrig: 27“.")


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(_aufzaehlen_da())
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 5 ★★ · Wie im Abitur: wie_oft(ding, liste) ─────────────────

def pruefe_50_wie_oft():
    """Aufgabe 5 ★★ · wie_oft(ding, liste) zählt -- für jedes Ding und jede Liste"""
    braucht(funktion("wie_oft") is not None)
    for ding, liste, soll in (("handschuh", ["handschuh", "schal", "handschuh", "mütze", "handschuh"], 3),
                              ("mütze", ["mütze", "schal", "mütze"], 2), ("schal", ["handschuh", "mütze"], 0),
                              ("kreide", [], 0)):
        wert, gedruckt, fehler = _rufen("wie_oft", ding, list(liste))
        erwarte(fehler is None, "wie_oft(%r, %r) bricht ab: %s" % (ding, liste, fehler))
        erwarte(wert is not None, "wie_oft() gibt nichts zurück (None)%s."
                % (" -- sie druckt, statt zurückzugeben" if gedruckt.strip() else ""))
        erwarte(wert == soll and isinstance(wert, int) and not isinstance(wert, bool),
                "wie_oft(%r, %r) liefert %r, nicht %d%s" % (ding, liste, wert, soll, _warum_wie_oft(wert, soll, ding)))


def _warum_wie_oft(wert, soll, ding):
    """Der Satz hinter der Meldung -- nach dem, was herauskam (Befund 7: vorher hiess es bei jedem Fehler
    „vergleicht sie mit dem Parameter ding?“, auch wenn ein return IN der Schleife zu frueh antwortete)."""
    if not isinstance(wert, int) or isinstance(wert, bool):
        return " -- sie gibt keine ganze Zahl zurück."
    if 0 < wert < soll:
        return " -- antwortet sie, bevor die ganze Liste durchgezählt ist?"
    if ding != "handschuh":
        return " -- zählt sie, was als ding mitkommt, oder etwas Festes?"
    if wert < soll:
        return " -- antwortet sie, bevor die ganze Liste durchgezählt ist?"
    return "."


# ── Aufgabe 8 · Mehr: Schaltjahr ─────────────────────────────────────────

def pruefe_80_schaltjahr():
    """Aufgabe 8 ★★ · schaltjahr(jahr): durch 4 teilbar"""
    braucht(funktion("schaltjahr") is not None)
    for jahr, soll in ((2024, True), (2026, False), (2023, False), (2028, True)):
        wert, gedruckt, fehler = _rufen("schaltjahr", jahr)
        erwarte(fehler is None, "schaltjahr(%d) bricht ab: %s" % (jahr, fehler))
        erwarte(not gedruckt.strip(), "schaltjahr() druckt etwas -- sie soll nur antworten.")
        erwarte(wert is soll, "schaltjahr(%d) liefert %r, nicht %r." % (jahr, wert, soll))


def pruefe_81_ausnahme():
    """Aufgabe 8 ★★★ · schaltjahr(jahr): die Ausnahme mit 100 und 400"""
    braucht(funktion("schaltjahr") is not None)
    for jahr, soll in ((1900, False), (2000, True), (2100, False), (2024, True)):
        wert, _, fehler = _rufen("schaltjahr", jahr)
        erwarte(fehler is None, "schaltjahr(%d) bricht ab: %s" % (jahr, fehler))
        erwarte(wert is soll, "schaltjahr(%d) liefert %r, nicht %r." % (jahr, wert, soll))


# ── Aufgabe 9 ★★★★ · Mehr: Was ein Fund wert ist ────────────────────────

def pruefe_90_wert():
    """Aufgabe 9 ★★★★ · wert(ding): Stick 30, Torschlüssel 20, sonst 10"""
    braucht(funktion("wert") is not None and funktion("nimm") is not None)
    for ding, soll in (("stick", 30), ("torschlüssel", 20), ("seil", 10), ("kreide", 10)):
        wert, _, fehler = _rufen("wert", ding)
        erwarte(fehler is None, "wert(%r) bricht ab: %s" % (ding, fehler))
        erwarte(wert == soll, "wert(%r) liefert %r, nicht %d." % (ding, wert, soll))


def pruefe_91_nimm():
    """Aufgabe 9 ★★★★ · nimm(ding, raum) gibt die Punkte zurück -- das Hauptprogramm zählt"""
    braucht(funktion("wert") is not None and funktion("nimm") is not None)
    aus, abbruch = _spiel(["osten", "nimm stick", "nimm seil", "zeige", "westen", "westen",
                           "nimm torschlüssel", "zeige", "ende"])
    erwarte(not abbruch, "Beim Nehmen bricht das Spiel ab.")
    erwarte("kein seil" in _nach(aus, "nimm seil"), "Im Informatikraum sagt nimm seil nicht „Hier gibt es kein seil.“")
    erwarte(re.search(r"Punkte:\s*30\b", _nach(aus, "zeige")) is not None,
            "Nach nimm stick und nimm seil (das nicht da ist) steht bei zeige nicht „Punkte: 30“.")
    erwarte(re.search(r"Punkte:\s*50\b", _nach(aus, "zeige", 2)) is not None,
            "Nach dem Torschlüssel steht bei zeige nicht „Punkte: 50“.")
    voll, _ = _spiel(["nimm kreide", "osten", "nimm stick", "nimm kreide", "westen", "süden", "nimm seil",
                      "nimm apfel", "nimm kreide", "zeige", "ende"])
    erwarte("voll" in _nach(voll, "nimm kreide", 3) and re.search(r"Punkte:\s*70\b", _nach(voll, "zeige")),
            "Mit vollem Rucksack bringt nimm noch Punkte -- oder sagt nicht, dass er voll ist.")
    erwarte(re.search(r"\bpunkte\s*=\s*punkte\s*\+\s*nimm\(", ohne_kommentare()) is not None,
            "Im Hauptprogramm steht nicht punkte = punkte + nimm(…).")


# ── Aufgabe 10 ★★★★ · Mehr, Expertenaufgabe: Eine Probe für vier Fehler ─
# Die Klasse schreibt probe() -> bool: EIN Aufruf von wie_oft, verglichen mit der erwarteten Antwort. Der Check
# setzt an die Stelle von wie_oft eine richtige Fassung (probe() muss True liefern, mit genau einem Aufruf) und
# dann jede der vier kaputten aus der Aufgabe (probe() muss False liefern -- oder abbrechen: auch das faellt auf).
# So besteht nicht, wer nur True hinschreibt, und nicht, wer die naheliegende Probe aus dem Spiel nimmt
# (wie_oft("handschuh", fundkiste) == 3 lassen A und B durch).

FUNDKISTE = ["handschuh", "schal", "handschuh", "mütze", "handschuh"]


def _wie_oft_richtig(ding, liste):
    anzahl = 0
    for x in liste:
        if x == ding:
            anzahl = anzahl + 1
    return anzahl


def _wie_oft_a(ding, liste):
    """Fassung A: vergleicht mit dem festen Text statt mit dem Parameter."""
    anzahl = 0
    for x in liste:
        if x == "handschuh":
            anzahl = anzahl + 1
    return anzahl


def _wie_oft_b(ding, liste):
    """Fassung B: laeuft ueber die Fundkiste von draussen statt ueber den Parameter."""
    anzahl = 0
    for x in FUNDKISTE:
        if x == ding:
            anzahl = anzahl + 1
    return anzahl


def _wie_oft_c(ding, liste):
    """Fassung C: return in der Schleife -- nach dem ersten Element ist Schluss (leere Liste: None)."""
    anzahl = 0
    for x in liste:
        if x == ding:
            anzahl = anzahl + 1
        return anzahl


def _wie_oft_d(liste, ding):
    """Fassung D: Parameter im Kopf vertauscht."""
    anzahl = 0
    for x in liste:
        if x == ding:
            anzahl = anzahl + 1
    return anzahl


KAPUTT = (("A", _wie_oft_a), ("B", _wie_oft_b), ("C", _wie_oft_c), ("D", _wie_oft_d))


def _probe_mit(fassung):
    """probe() rufen, waehrend `fassung` an der Stelle von wie_oft steht. Gibt (wert, fehler, aufrufe)."""
    aufrufe = [0]

    def ersatz(*argumente, **benannt):
        aufrufe[0] = aufrufe[0] + 1
        return fassung(*argumente, **benannt)

    wert, _, fehler = _rufen("probe", wie_oft=ersatz, fundkiste=list(FUNDKISTE))
    return wert, fehler, aufrufe[0]


def _probe_da():
    return _parameter("probe") == []


def _probe_stimmt():
    """Fuer braucht(): Liefert probe() mit der richtigen Fassung True, mit genau einem Aufruf?"""
    if not _probe_da():
        return False
    wert, fehler, aufrufe = _probe_mit(_wie_oft_richtig)
    return fehler is None and aufrufe == 1 and wert is True


def pruefe_a0_probe_stimmt():
    """Aufgabe 10 ★★★★ · probe() besteht mit einer richtigen wie_oft -- mit genau einem Aufruf"""
    braucht(_probe_da())
    wert, fehler, aufrufe = _probe_mit(_wie_oft_richtig)
    erwarte(fehler is None, "probe() bricht ab: %s" % fehler)
    erwarte(aufrufe > 0, "probe() ruft wie_oft gar nicht -- sie soll die Funktion mit euren Argumenten fragen.")
    erwarte(aufrufe == 1, "probe() ruft wie_oft %d-mal -- die Auflage ist: genau ein Aufruf." % aufrufe)
    erwarte(wert is True or wert is False,
            "probe() gibt %r zurück -- sie soll mit True oder False antworten, ob die Antwort stimmt." % (wert,))
    erwarte(wert is True, "Mit einer richtigen wie_oft gibt probe() False zurück -- stimmt die Antwort, die ihr "
            "erwartet, für eure Argumente?")


def pruefe_a1_probe_findet():
    """Aufgabe 10 ★★★★ · probe() fällt bei jeder der vier kaputten Fassungen durch"""
    braucht(_probe_stimmt())
    bestanden = []
    for name, fassung in KAPUTT:
        wert, fehler, aufrufe = _probe_mit(fassung)
        if fehler is None and wert is True:
            bestanden.append(name)
    erwarte(not bestanden, "Diese kaputten Fassungen bestehen eure Probe: %s -- bei euren Argumenten liefern sie "
            "zufällig dieselbe Antwort wie eine richtige." % ", ".join(bestanden))


# ── Aufgabe 11 · Expertenspur ④: Der Musikraum ────────────────────────────
# Die Spur steht in keinem Stand (planung/expertenspur/stufen.py): Wer sie geht, kopiert ihren Stand in das Spiel.
# Alle Pruefungen warten, bis es den Befehl spiele gibt. Der Check spielt das Spiel an, setzt oben andere Werte ein
# (_spur_spiel(..., ersetzen={...})) und stellt den Zufall fest ein (folge=[...]: die Toene, die random.choice der
# Reihe nach aus einer Liste von Tasten waehlt -- steht der Ton nicht darin, der erste; folge=k: immer das Element auf
# Platz k % len; randint liefert immer b -- keine Sicherung, kein Kater).
import io as _spur_io
import random as _spur_random
import sys as _spur_sys

SPUR_SCHLUSS = "§SPURSCHLUSS§"
SPUR_VORN = """import random as _spur_r
_spur_folge = %r
_spur_gewuerfelt = []
def _spur_wahl(liste):
    if len(liste) > 0 and all(len(x) == 1 and x in "cdefgah" for x in liste):
        _spur_gewuerfelt.append(1)
        if isinstance(_spur_folge, int):
            return liste[_spur_folge %% len(liste)]
        if _spur_folge:
            ton = _spur_folge.pop(0)
            return ton if ton in liste else liste[0]
    return liste[0]
_spur_r.choice = _spur_wahl
_spur_r.randint = lambda a, b: b
"""


def _spur_da():
    return '"spiele ' in ohne_kommentare() or "'spiele " in ohne_kommentare()


def _spur_spiel(befehle, ersetzen=None, folge=None, vorn=""):
    """Das Spiel mit diesen Befehlen. ersetzen: {name: wert} fuer die erste Zeile `name = ...` ganz links; folge:
    der Zufall fest (siehe oben); vorn: Code, der vor dem Spiel laeuft. Gibt (aus, abbruch, ns)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in (ersetzen or {}).items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    if folge is not None:
        vorn = SPUR_VORN % (folge if isinstance(folge, int) else list(folge),) + vorn
    pruefen._QUELLE = vorn + q + "\nprint(%r)\n" % SPUR_SCHLUSS
    echt = (_spur_random.choice, _spur_random.randint)
    try:
        aus, ns = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
        _spur_random.choice, _spur_random.randint = echt
    fertig = SPUR_SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet), ns


def _spur_nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _spur_toene(*toene):
    return ["spiele %s" % t for t in toene]


def _spur_punkte(aus):
    m = re.search(r"Spielzeit:.*?(-?\d+)\s*Punkte", aus)
    return int(m.group(1)) if m else None

import builtins as _spur_builtins


def _spur_beide_da():
    return _parameter("treffer") is not None and len(_parameter("treffer")) == 2 and \
        _parameter("merke") is not None and len(_parameter("merke")) == 3


def _spur_von_draussen(name):
    """Namen, die die Funktion `name` liest, ohne dass sie Parameter, dort gesetzt, eingebaut oder eine Funktion sind."""
    funktionen = {n for n, _ in _defs()}
    for n, k in _defs():
        if n != name:
            continue
        params = {a.arg for a in k.args.args}
        gelesen, gesetzt = set(), set()
        for c in ast.walk(k):
            if isinstance(c, ast.Name):
                (gelesen if isinstance(c.ctx, ast.Load) else gesetzt).add(c.id)
        return sorted(gelesen - params - gesetzt - funktionen - set(dir(_spur_builtins)))
    return []


def pruefe_e0_zwei_funktionen():
    """Aufgabe 11 ★★★★ · treffer(gespielt, melodie) und merke(ton, gespielt, laenge) arbeiten mit dem, was sie bekommen"""
    braucht(_spur_da())
    erwarte(_spur_beide_da(), "Es gibt noch nicht beide Funktionen: treffer mit zwei Parametern und merke mit drei.")
    draussen = {"gespielt": ["z"], "melodie": ["z"], "gespielt_glocke": ["z"], "melodie_glocke": ["z"]}
    for a, b, soll in ((["g", "x", "c"], ["g", "e", "c"], 2), (["c", "c", "h"], ["c", "c", "g"], 2), (["a"], ["a"], 1)):
        wert, gedruckt, fehler = _rufen("treffer", a, b, **draussen)
        erwarte(fehler is None and wert == soll and gedruckt == "",
                "treffer(%s, %s) gibt %r zurück (soll: %d, ohne etwas anzuzeigen)%s."
                % (a, b, wert if fehler is None else "nichts", soll, " -- " + fehler if fehler else ""))
    liste = ["x", "y"]
    _, _, fehler = _rufen("merke", "a", liste, 2, **draussen)
    erwarte(fehler is None and liste == ["y", "a"],
            "merke(\"a\", [\"x\", \"y\"], 2) macht aus der Liste %s, nicht [\"y\", \"a\"]%s."
            % (liste, " -- " + fehler if fehler else ""))
    liste = []
    _rufen("merke", "c", liste, 3, **draussen)
    erwarte(liste == ["c"], "merke(\"c\", [], 3) macht aus der leeren Liste %s, nicht [\"c\"]." % liste)


def pruefe_e1_glockenspiel():
    """Aufgabe 11 ★★★★ · Das Glockenspiel im Keller: c, c, g bringt 20 Punkte, einmal"""
    braucht(_spur_da() and _spur_beide_da())
    aus, abbruch, _ = _spur_spiel(["westen"] + _spur_toene("c", "c", "g", "c", "c", "g") + ["ende"])
    erwarte(not abbruch, "Im Keller bricht spiele ab.")
    erwarte("Ding: c" in _spur_nach(aus, "spiele c"), "Im Keller klingt spiele c nicht „Ding: c“.")
    erwarte(aus.count("Gummibärchen") == 1 and _spur_punkte(aus) == 20,
            "Im Keller, zweimal c, c, g: %d-mal Gummibärchen, %s Punkte -- einmal, 20 Punkte."
            % (aus.count("Gummibärchen"), _spur_punkte(aus)))
    aus, _, _ = _spur_spiel(["süden", "spiele c", "ende"])
    erwarte("Hier steht kein Instrument" in _spur_nach(aus, "spiele c"),
            "Im Lehrerzimmer sagt spiele c nicht „Hier steht kein Instrument.“")


def pruefe_e2_getrennt():
    """Aufgabe 11 ★★★★ · Klavier und Glockenspiel merken sich ihre Töne getrennt"""
    braucht(_spur_da() and _spur_beide_da())
    aus, abbruch, _ = _spur_spiel(["spiele g", "westen"] + _spur_toene("c", "c", "g") + ["osten"]
                                  + _spur_toene("e", "c") + ["ende"])
    erwarte(not abbruch and "Gummibärchen" in aus and "Die Bank springt auf" in aus and _spur_punkte(aus) == 50,
            "Im Flur g, im Keller c, c, g, im Flur e, c: Es springen nicht beide auf (50 Punkte). Teilen sich die "
            "Instrumente eine Liste?")


def pruefe_e3_nichts_von_draussen():
    """Aufgabe 11 ★★★★ · Die Auflage: treffer und merke lesen nichts von draußen"""
    braucht(_spur_da() and _spur_beide_da())
    for name in ("treffer", "merke"):
        fremd = _spur_von_draussen(name)
        erwarte(not fremd, "%s liest %s von draußen -- was sie braucht, kommt in die Klammer."
                % (name, " und ".join(fremd)))
