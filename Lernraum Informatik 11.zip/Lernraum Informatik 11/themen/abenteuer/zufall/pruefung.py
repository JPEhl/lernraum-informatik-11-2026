"""Selbstcheck zu "Zufall und Bibliotheken" -- prueft zufall.py (Aufgabe 2, 3; unter Mehr 8, 9 und 10).

Das Spiel wuerfelt jetzt. Damit der Check nicht selbst wuerfelt, stellt er den Zufall fest ein, solange er
das Spiel anspielt (_spiel(..., k=…, wahl=…, art=…)) -- dasselbe Mittel wie staende_testen.sh.

Fest auf k (Reihensichtung Teil II, 25.10., Befund 1): Vorher lieferte randint nur a oder nur b -- jede
Bedingung, die bei a zutrifft und bei b nicht, bestand (`<= 2` statt `== 1`, `randint(0, 6)`, der Kater an der
Wand). Jetzt laeuft das Spiel RUNDE = 60 Mal, Lauf k liefert randint(a, b) = a + k % (b - a + 1), random() den
k-ten Teil von 1 und choice das Element auf Platz k % len. Weil 60 durch 1 … 6 teilbar ist, kommt jeder Wert
eines Wuerfels gleich oft dran: „einer von sechs“ heisst genau 10 Treffer in 60 Laeufen, „einer von fuenf“
genau 12 -- gleich, ob jemand `== 1`, `== 6` oder `randint(1, 12) <= 2` schreibt. Wie oft es passiert, misst
der Check am Verhalten, nicht an Woertern im Quelltext.

Dazu: wahl="vorne"/"hinten" -- choice waehlt das erste bzw. letzte Element (der Kater nimmt ein bestimmtes
Ding); art="reihum" -- randint geht der Reihe nach durch a … b (600 Wuerfe: jede Augenzahl genau 100-mal);
art="doppelt" -- jeder Wert kommt zweimal hintereinander (die Kaffeemaschine darf sich nicht wiederholen);
k mit art="ziffern" -- der n-te Zufallsaufruf liefert die n-te Ziffer von k zur Basis 5 (Bytes Runde: 60 Laeufe,
in denen der Zufall auch innerhalb eines Laufs wechselt); ohne Angabe der echte Zufall mit fester Saat (zwei
Wuerfel, der erste Lauf mit EINGABEN). Bei zwei Wuerfeln traegt die Saat das Urteil nicht: Die Pruefung verlangt die 7
um vier # laenger als 2 und 12; richtig gewuerfelt (auch mit choice oder zwei Listen) waren es ueber 500 Saaten nie
weniger als fuenf, mit randint(2, 12) oder 2 * randint(1, 6) bestand keine (Lauf i11, 17.11.).

Aufgabe 10 (Expertenaufgabe, Lauf i11): Der Befehl runde soll bei JEDEM Zufall fertig werden, mit hoechstens fuenf
Zufallsaufrufen. Dafuer zaehlt der Check mit (_spiel(..., zaehler={})): Jeder Aufruf von randint/choice/random wird
gezaehlt, nach ZU_OFT Aufrufen bricht der Lauf ab (im Lauf k liefert der Zufall immer denselben Wert -- wer waehlt,
bis etwas Neues kommt, wuerde sonst endlos laufen); jede andere Funktion aus random (shuffle, sample …) wird
vermerkt, nicht gezaehlt.

Wie in "Parameter": die Antwort auf einen Befehl herausschneiden (_nach), eine Funktion selbst
rufen (_rufen). Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile hinter dem Code (SCHLUSS).
"""
import ast
import io
import random
import re
import sys

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Zufall und Bibliotheken · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

TREPPE = "wartest auf den Morgen"
KLACK = "KLACK"
KATER = "Byte"
SCHLUSS = "§SCHLUSS§"
KAFFEE = "benutze kaffeemaschine"
SAGT = "Die Kaffeemaschine sagt"
RUNDE_SATZ = "Byte dreht seine Runde"
RAEUME = ["flur", "informatikraum", "lehrerzimmer", "keller", "tor"]
ZU_OFT = 200        # so viele Zufallsaufrufe braucht keine Runde -- danach bricht der Lauf ab
FREMD = ("shuffle", "sample", "choices", "randrange", "uniform", "getrandbits", "randbytes")

RUNDE = 60          # durch 1 … 6 teilbar: jeder Wuerfelwert gleich oft
SAAT = 14

HINTS = {"hilfe": "None", "zeige_raum": "None", "zeige_rucksack": "None", "pruefe_tuer": "bool",
         "beschreibung": "str", "dinge_im": "list[str]", "sterne": "str", "aufzaehlen": "str", "ziel": "str",
         "gehe": "str", "kater": "None", "haeufigkeit": "int", "balken": "str", "kaffee": "str",
         "treffer": "int", "merke": "None", "neue_melodie": "list[str]"}

# Der erste Lauf der Arbeitsdatei (mit EINGABEN, vor allen Pruefungen) wuerfelt echt -- ohne feste Saat stand die
# Warnung „Das Programm bricht beim Anspielen ab“ bei einem Fehler, der nur manchmal kommt, mal da und mal nicht
# (Lauf i11, 17.11.: `zum_schnappen[random.randint(0, len(zum_schnappen))]`, 3 von 8 Selbstchecks). Diese Datei wird
# vor dem ersten Lauf geladen; mit fester Saat sagt derselbe Code jedes Mal dasselbe.
random.seed(SAAT)

KEIN_WERT = object()
_ECHT = (random.randint, random.choice, random.random)
_FREMD_ECHT = {name: getattr(random, name) for name in FREMD if hasattr(random, name)}


class _ZuOft(BaseException):
    """Mehr Zufallsaufrufe als ZU_OFT -- der Lauf endet hier (BaseException: kein except der Klasse faengt sie)."""


def _mitzaehlen(zaehler):
    """Zaehlt jeden Aufruf des (schon fest eingestellten) Zufalls in zaehler["aufrufe"]; nach ZU_OFT Aufrufen
    zaehler["zu_oft"] und Abbruch des Laufs. Eine andere Funktion aus random setzt zaehler["fremd"].
    Gibt eine Funktion zurueck, die die fremden Funktionen wieder einsetzt."""
    zaehler.update({"aufrufe": 0, "zu_oft": False, "fremd": ""})

    def zaehlend(f):
        def g(*argumente):
            zaehler["aufrufe"] += 1
            if zaehler["aufrufe"] > ZU_OFT:
                zaehler["zu_oft"] = True
                raise _ZuOft()
            return f(*argumente)
        return g

    def vermerkt(name, f):
        def g(*argumente, **benannt):
            zaehler["fremd"] = name
            return f(*argumente, **benannt)
        return g
    random.randint, random.choice, random.random = (zaehlend(f) for f in (random.randint, random.choice, random.random))
    for name, f in _FREMD_ECHT.items():
        setattr(random, name, vermerkt(name, f))

    def zurueck():
        for name, f in _FREMD_ECHT.items():
            setattr(random, name, f)
    return zurueck


def _zufall_fest(k=None, wahl="", art=""):
    """Stellt randint/choice/random fest ein; gibt eine Funktion zurueck, die alles zuruecksetzt.
    k: Lauf k von RUNDE (siehe oben). wahl: "vorne"/"hinten" fuer choice. art: "reihum"/"doppelt" (ohne k)."""
    randint, choice, _ = _ECHT
    random.seed(SAAT)
    zaehler = {}
    teiler = 2 if art == "doppelt" else 1

    def naechster(schluessel):
        n = zaehler.get(schluessel, 0)
        zaehler[schluessel] = n + 1
        return n // teiler

    def breite(a, b):
        if b < a:
            randint(a, b)           # derselbe Fehler wie echt (ValueError: empty range)
        return b - a + 1
    if k is not None and art == "ziffern":
        # Der n-te Zufallsaufruf im Lauf k liefert die n-te Ziffer von k zur Basis 5 -- so wechselt der Zufall auch
        # INNERHALB eines Laufs (wer fuenfmal aus demselben Bereich wuerfelt, bekaeme sonst fuenfmal dasselbe)
        def ziffer(n):
            return k // 5 ** naechster("ziffern") % n
        random.randint = lambda a, b: a + ziffer(breite(a, b))
        random.random = lambda: (ziffer(RUNDE) + 0.5) / RUNDE
        random.choice = lambda folge: folge[ziffer(len(folge))] if len(folge) else choice(folge)
    elif k is not None:
        random.randint = lambda a, b: a + k % breite(a, b)
        random.random = lambda: (k % RUNDE + 0.5) / RUNDE
    elif art in ("reihum", "doppelt"):
        random.randint = lambda a, b: a + naechster((a, b)) % breite(a, b)
    if wahl in ("vorne", "hinten"):
        random.choice = (lambda folge: folge[0]) if wahl == "vorne" else (lambda folge: folge[-1])
    elif k is not None and art == "ziffern":
        pass
    elif k is not None:
        random.choice = lambda folge: folge[k % len(folge)] if len(folge) else choice(folge)
    elif art in ("reihum", "doppelt"):
        random.choice = lambda folge: folge[naechster(tuple(folge)) % len(folge)] if len(folge) else choice(folge)

    def zurueck():
        random.randint, random.choice, random.random = _ECHT
    return zurueck


def _spiel(befehle, k=None, wahl="", art="", zaehler=None):
    """Das Spiel mit diesen Befehlen, der Zufall fest eingestellt. Gibt (aus, abbruch).
    zaehler: ein Dict -- dann wird jeder Zufallsaufruf mitgezaehlt (_mitzaehlen)."""
    alt = pruefen._QUELLE
    pruefen._QUELLE = alt + "\nprint(%r)\n" % SCHLUSS
    zurueck = _zufall_fest(k, wahl, art)
    fremd_zurueck = _mitzaehlen(zaehler) if zaehler is not None else None
    try:
        aus, _ = anspielen(befehle)
    finally:
        zurueck()
        if fremd_zurueck:
            fremd_zurueck()
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _treffer(befehle, wort, befehl, n=1, fremd=None):
    """Alle RUNDE Laeufe: in welchen steht `wort` in der Antwort auf den n-ten `befehl`?
    Gibt (treffer, abbruch): die Liste der k mit Treffer, ob irgendein Lauf abbrach.
    fremd: ein Abbruch in einem Lauf, in dem dieses Wort in der Antwort steht, zaehlt nicht -- er gehoert zu der
    Pruefung, die das Wort prueft (Lauf i11, 17.11.: der Kater mit `randint(0, len(rucksack))` faerbte die Sicherung)."""
    treffer, abbruch = [], False
    for k in range(RUNDE):
        aus, ab = _spiel(befehle, k=k)
        antwort = _nach(aus, befehl, n)
        abbruch = abbruch or (ab and not (fremd and fremd in antwort))
        if wort in antwort:
            treffer.append(k)
    return treffer, abbruch


def _erster(befehle, wort, befehl, wahl=""):
    """Der erste Lauf k, in dem `wort` in der Antwort auf `befehl` steht; None: in keinem."""
    for k in range(RUNDE):
        if wort in _nach(_spiel(befehle, k=k, wahl=wahl)[0], befehl):
            return k
    return None


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _rufen(name, *argumente):
    """Die Funktion `name` mit diesen Argumenten rufen. Gibt (wert, gedruckt, fehler)."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
    return wert, puffer.getvalue(), fehler


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _random_da():
    return re.search(r"^\s*(import\s+random\b|from\s+random\s+import\b)", ohne_kommentare(), re.M) is not None


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Parameter“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- kennt Python jeden Namen, den das Programm "
            "oben braucht, und ist jede Funktion definiert, bevor sie gerufen wird?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende steht „Deine Sterne:“ nicht mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 · Die Sicherung ───────────────────────────────────────────

def pruefe_20_sicherung():
    """Aufgabe 2 · Im Keller fliegt manchmal die Sicherung raus"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil II, 25.10., Befund 6: vorher „2 von 2 passen“ ohne naechsten Schritt).
    erwarte(KLACK in quelltext(), "Im Keller fliegt noch keine Sicherung raus -- das Spiel würfelt noch nicht.")
    erwarte(_random_da(), "Das Spiel holt die Bibliothek für den Zufall noch nicht.")
    treffer, abbruch = _treffer(["westen", "zeige", "ende"], KLACK, "westen", fremd=KATER)
    erwarte(not abbruch, "Bei westen oder zeige bricht das Spiel ab -- bei manchen Würfen.")
    erwarte(treffer, "Im Keller fliegt die Sicherung nie raus -- bei keinem der 60 festen Würfe.")
    erwarte(len(treffer) < RUNDE, "Die Sicherung fliegt bei jedem Betreten des Kellers -- sie soll nur manchmal fliegen.")
    erwarte(len(treffer) == RUNDE // 6,
            "Bei 60 festen Würfen fliegt die Sicherung %d-mal -- „einer von sechs“ wären 10." % len(treffer))
    aus, _ = _spiel(["westen", "zeige", "ende"], k=treffer[0])
    erwarte(re.search(r"Züge übrig:\s*26", _nach(aus, "zeige")) is not None,
            "Fliegt die Sicherung, steht nach westen und zeige nicht „Züge übrig: 26“ -- kostet sie 2 Züge?")
    erwarte(KLACK not in _spiel(["osten", "westen", "süden", "ende"], k=treffer[0])[0],
            "Die Sicherung fliegt auch außerhalb des Kellers.")


def pruefe_21_nur_betreten():
    """Aufgabe 2 ★★ · Die Sicherung fliegt nur beim Betreten, nicht an der Wand"""
    braucht(_random_da() and KLACK in quelltext())
    k = _erster(["westen", "ende"], KLACK, "westen")
    braucht(k is not None)
    aus, abbruch = _spiel(["westen", "westen", "westen", "ende"], k=k)
    erwarte(not abbruch or KATER in aus, "Im Keller an der Wand bricht das Spiel ab.")
    erwarte(aus.count(KLACK) == 1, "Westen im Keller ist eine Wand -- die Sicherung fliegt dort noch einmal. "
            "Sie soll nur fliegen, wenn ihr den Keller betretet.")


# ── Aufgabe 3 · Der Kater ───────────────────────────────────────────────

def pruefe_30_kater():
    """Aufgabe 3 · Wer einen Raum betritt, trifft manchmal den Kater"""
    braucht(_random_da() and KATER in quelltext(), "Noch kein Kater im Spiel.")
    treffer, abbruch = _treffer(["osten", "ende"], KATER, "osten")
    erwarte(not abbruch, "Kommt der Kater, bricht das Spiel ab -- bei manchen Würfen.")
    erwarte(treffer, "Nach osten kommt der Kater nie -- bei keinem der 60 festen Würfe.")
    erwarte(len(treffer) < RUNDE, "Der Kater kommt jedes Mal -- er soll nur manchmal kommen.")
    erwarte(len(treffer) == RUNDE // 5,
            "Bei 60 festen Würfen kommt der Kater %d-mal -- „einer von fünf“ wären 12." % len(treffer))
    aus, _ = _spiel(["osten", "osten", "ende"], k=treffer[0])
    erwarte(KATER not in _nach(aus, "osten", 2),
            "Im Informatikraum führt osten gegen eine Wand -- und trotzdem kommt der Kater. Er soll nur kommen, "
            "wenn ihr einen Raum betretet.")


def pruefe_31_schnappen():
    """Aufgabe 3 ★★ · Der Kater schnappt sich ein Ding und lässt es im Raum fallen"""
    braucht(_random_da() and ("choice" in ohne_kommentare() or "schnappt" in quelltext()))
    # Kreide aus dem Flur nehmen, dann in den Informatikraum. Gesucht ist ein Lauf, in dem er die Kreide nimmt
    # (choice: das letzte Ding; wer selbst einen Platz wuerfelt, trifft sie in einem anderen Lauf) -- so besteht
    # auch, wer die Lampe noch nicht schuetzt; das prueft erst ★★★.
    befehle = ["nimm kreide", "osten", "zeige", "ende"]
    braucht(_erster(befehle, KATER, "osten", "hinten") is not None)
    k = None
    for kk in range(RUNDE):
        neu = _nach(_spiel(befehle, k=kk, wahl="hinten")[0], "osten")
        if KATER in neu and "kreide" in neu.split("Hier liegt")[0].lower():
            k = kk
            break
    erwarte(k is not None, "Der Kater sagt nicht, was er sich schnappt -- oder er nimmt nie die Kreide, auch wenn "
            "sie neben der Lampe euer einziges Ding ist.")
    aus, abbruch = _spiel(befehle, k=k, wahl="hinten")
    erwarte(not abbruch, "Wenn der Kater kommt, bricht das Spiel ab.")
    neu = _nach(aus, "osten")
    erwarte("kreide" not in _nach(aus, "zeige").lower(), "Nach dem Kater steckt die Kreide noch im Rucksack.")
    hier = next((z for z in neu.splitlines() if z.startswith("Hier liegt")), "")
    erwarte(hier.lower().count("kreide") == 2,
            "Im Informatikraum liegt danach nicht zweimal Kreide (die eigene und eure) -- lässt der Kater sie im neuen Raum "
            "fallen? (gesehen: %s)" % (hier or "keine Zeile „Hier liegt“"))


def pruefe_32_nicht_die_lampe():
    """Aufgabe 3 ★★★ · Die Lampe lässt er liegen -- und mit leerem Rucksack bricht nichts ab"""
    braucht(_random_da() and ("choice" in ohne_kommentare() or "schnappt" in quelltext()))
    treffer, abbruch = _treffer(["osten", "ende"], KATER, "osten")
    # bricht der Kater schon mit der Lampe allein ab, meldet es Aufgabe 3 ★ -- hier wird gewartet
    braucht(treffer and not abbruch)
    # Abbruch und Lampe getrennt (Lauf i11, 17.11.): Wer den Platz selbst wuerfelt und das `- 1` vergisst, bricht nur
    # manchmal ab -- vorher hiess die Meldung dann „Der Kater hat die Lampe genommen“, obwohl er sie nie nahm.
    bricht = lampe_weg = nur_lampe_bricht = nur_lampe_weg = leer = False
    for k in treffer:
        for wahl in ("vorne", "hinten"):
            # vorne: choice nimmt das erste Ding -- ohne Schutz waere das die Lampe
            aus, abbruch = _spiel(["westen", "nimm pausenbrot", "osten", "zeige", "ende"], k=k, wahl=wahl)
            # ein Abbruch gleich nach KLACK gehoert zur Sicherung (Aufgabe 2), nicht zum Kater
            bricht = bricht or (abbruch and KLACK not in _nach(aus, "westen"))
            lampe_weg = lampe_weg or (not abbruch and "lampe" not in _nach(aus, "zeige").lower())
        aus, abbruch = _spiel(["osten", "zeige", "ende"], k=k, wahl="vorne")
        nur_lampe_bricht = nur_lampe_bricht or abbruch
        nur_lampe_weg = nur_lampe_weg or (not abbruch and "lampe" not in _nach(aus, "zeige").lower())
        leer = leer or _spiel(["lege lampe", "osten", "westen", "ende"], k=k, wahl="vorne")[1]
    erwarte(not bricht, "Mit Lampe und Pausenbrot im Rucksack bricht das Spiel bei manchen Würfen ab, wenn der Kater "
            "kommt.")
    erwarte(not lampe_weg, "Der Kater hat die Lampe genommen -- die soll er liegen lassen.")
    erwarte(not nur_lampe_bricht, "Tragt ihr nur die Lampe, bricht das Spiel ab, wenn der Kater kommt.")
    erwarte(not nur_lampe_weg, "Tragt ihr nur die Lampe, nimmt der Kater sie.")
    erwarte(not leer, "Mit leerem Rucksack bricht das Spiel ab, wenn der Kater kommt -- aus nichts lässt sich "
            "nichts wählen.")


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(_random_da())
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 8 · Mehr: Die Würfelmaschine ────────────────────────────────

def _balken_zeilen(aus, von, bis):
    """Je Zahl von..bis: die Zahl der # in ihrer Zeile, None, wenn die Zeile fehlt."""
    werte = {}
    for z in aus.splitlines():
        m = re.match(r"\s*(?:> )?\s*(\d+)\s+(#*)\s*$", z)
        if m and von <= int(m.group(1)) <= bis:
            werte[int(m.group(1))] = len(m.group(2))
    return [werte.get(n) for n in range(von, bis + 1)]


def pruefe_80_haeufigkeit():
    """Aufgabe 8 ★★ · haeufigkeit(augen, wuerfe) zählt -- und würfeln zeigt sechs Balken"""
    braucht(_random_da() and funktion("haeufigkeit") is not None)
    for augen, wuerfe, soll in ((6, [6, 1, 6, 3], 2), (1, [2, 3], 0), (3, [], 0), (2, [2, 2, 2], 3)):
        wert, gedruckt, fehler = _rufen("haeufigkeit", augen, list(wuerfe))
        erwarte(fehler is None, "haeufigkeit(%r, %r) bricht ab: %s" % (augen, wuerfe, fehler))
        erwarte(wert == soll, "haeufigkeit(%r, %r) liefert %r, nicht %d." % (augen, wuerfe, wert, soll))
    # reihum: Der Wuerfel geht der Reihe nach durch alle Augenzahlen -- 600 Wuerfe sind genau 100 je Zahl, also
    # zehn # je Zeile (vorher echter Zufall und 5 … 16 #: zu weit, Befund 1)
    aus, abbruch = _spiel(["würfeln", "ende"], art="reihum")
    zeilen = _balken_zeilen(_nach(aus, "würfeln"), 0, 7)
    erwarte(not abbruch, "Bei würfeln bricht das Spiel ab.")
    fehlt = [str(n) for n, x in zip(range(1, 7), zeilen[1:7]) if x is None]
    erwarte(not fehlt, "Nach würfeln fehlt die Zeile mit Balken für: %s." % ", ".join(fehlt))
    erwarte(zeilen[0] is None and zeilen[7] is None,
            "Nach würfeln steht auch eine Zeile für 0 oder 7 -- ein Würfel zeigt 1 bis 6.")
    erwarte(all(9 <= x <= 11 for x in zeilen[1:7]),
            "Kommt jede Augenzahl gleich oft, sind die Balken nicht je zehn # lang -- 600 Würfe, ein # je zehn, "
            "und jede Augenzahl dabei? (gemessen: %s)" % ", ".join(str(x) for x in zeilen[1:7]))


def pruefe_81_zwei():
    """Aufgabe 8 ★★★ · zwei würfel: die Summen 2 bis 12, die 7 am längsten"""
    braucht(_random_da() and funktion("haeufigkeit") is not None and "zwei würfel" in quelltext())
    aus, abbruch = _spiel(["zwei würfel", "ende"])
    zeilen = _balken_zeilen(_nach(aus, "zwei würfel"), 2, 12)
    erwarte(not abbruch, "Bei zwei würfel bricht das Spiel ab.")
    fehlt = [str(n) for n, x in zip(range(2, 13), zeilen) if x is None]
    erwarte(not fehlt, "Nach zwei würfel fehlt die Zeile für: %s." % ", ".join(fehlt))
    erwarte(not fehlt and zeilen[5] >= max(zeilen[0], zeilen[10]) + 4,
            "Die 7 ist nicht deutlich länger als die 2 und die 12 -- würfelt ihr wirklich zwei Würfel und addiert?")


# ── Aufgabe 9 ★★★★ · Mehr: Die Kaffeemaschine ───────────────────────────

def _meldung(aus, n=1):
    """Was die Kaffeemaschine beim n-ten Benutzen sagt (ohne „Die Kaffeemaschine sagt“), sonst None."""
    teil = _nach(aus, KAFFEE, n)
    if SAGT not in teil:
        return None
    return teil.split(SAGT, 1)[1].lstrip(": ").splitlines()[0].strip()


def pruefe_90_kaffeemaschine():
    """Aufgabe 9 ★★★★ · benutze kaffeemaschine: zufällig, nur im Lehrerzimmer, nie zweimal dasselbe"""
    braucht(_random_da() and "kaffeemaschine" in ohne_kommentare().replace("Die Kaffeemaschine beobachtet dich", ""))
    vorne, abbruch = _spiel(["süden", KAFFEE, "ende"], k=0, wahl="vorne")
    hinten, _ = _spiel(["süden", KAFFEE, "ende"], k=RUNDE - 1, wahl="hinten")
    erwarte(not abbruch, "Bei benutze kaffeemaschine bricht das Spiel ab.")
    erwarte(_meldung(vorne) is not None,
            "Im Lehrerzimmer steht nach benutze kaffeemaschine nicht „Die Kaffeemaschine sagt: …“.")
    erwarte(_meldung(vorne) != _meldung(hinten),
            "Die Kaffeemaschine sagt immer dasselbe -- kommt die Meldung aus dem Zufall?")
    flur, _ = _spiel([KAFFEE, "ende"], k=0, wahl="vorne")
    erwarte("keine Kaffeemaschine" in _nach(flur, KAFFEE),
            "Im Flur steht nach benutze kaffeemaschine nicht „Hier steht keine Kaffeemaschine.“")
    # doppelt: Jeder Zufallswert kommt zweimal hintereinander -- wer nur wuerfelt, wiederholt sich; wer die letzte
    # Meldung ausschliesst (oder neu wuerfelt, bis es eine andere ist), nicht (Befund 8: eine Stufe schwerer)
    aus, abbruch = _spiel(["süden", KAFFEE, KAFFEE, KAFFEE, KAFFEE, "ende"], art="doppelt")
    folge = [_meldung(aus, n) for n in range(1, 5)]
    erwarte(not abbruch and None not in folge,
            "Viermal hintereinander benutzt, sagt die Kaffeemaschine nicht jedes Mal „Die Kaffeemaschine sagt: …“ "
            "-- oder das Spiel bricht ab.")
    gleich = [folge[i] for i in range(3) if folge[i] == folge[i + 1]]
    erwarte(not gleich, "Die Kaffeemaschine sagt zweimal hintereinander dasselbe (%s) -- sie soll jedes Mal "
            "etwas anderes sagen als eben." % (gleich[0] if gleich else ""))


# ── Aufgabe 10 ★★★★ · Mehr, Expertenaufgabe: Bytes Runde ────────────────

def _runde(aus, n=1):
    """Die Raeume in der Antwort auf das n-te runde, in der Reihenfolge, in der sie dastehen -- und die Zeile selbst.
    Gibt (folge, zeile); zeile ist "", wenn der Satz fehlt. Ein Raum, der doppelt dasteht, steht doppelt in folge."""
    zeile = next((z for z in _nach(aus, "runde", n).splitlines() if RUNDE_SATZ in z), "")
    text = zeile.split(RUNDE_SATZ, 1)[1].lower() if zeile else ""
    stellen = []
    for name in RAEUME:
        i = text.find(name)
        while i >= 0:
            stellen.append((i, name))
            i = text.find(name, i + 1)
    return [name for _, name in sorted(stellen)], zeile


def _runde_fertig():
    """Fuer braucht(): Wird runde bei festem Zufall fertig, und mit dem vereinbarten Zufall? Was hier fehlt, meldet
    pruefe_a0_runde_sicher -- die zweite Pruefung wartet dann (ein Fehler faerbt nur seine eigene Pruefung)."""
    try:
        zaehler = {}
        aus, abbruch = _spiel(["runde", "ende"], k=0, zaehler=zaehler)
    except AssertionError:
        return False
    return (not zaehler["zu_oft"] and not zaehler["fremd"] and zaehler["aufrufe"] > 0 and not abbruch
            and RUNDE_SATZ in _nach(aus, "runde"))


def pruefe_a0_runde_sicher():
    """Aufgabe 10 ★★★★ · runde wird bei jedem Zufall fertig -- mit höchstens fünf Zufallsaufrufen"""
    braucht(_random_da() and RUNDE_SATZ in quelltext())
    meiste = 0
    for k in range(RUNDE):
        zaehler = {}
        aus, abbruch = _spiel(["runde", "ende"], k=k, zaehler=zaehler)
        erwarte(not zaehler["zu_oft"],
                "Liefert der Zufall immer wieder denselben Wert, wird eure Runde nicht fertig -- nach %d "
                "Zufallsaufrufen war noch kein Ende in Sicht." % ZU_OFT)
        erwarte(not zaehler["fremd"],
                "Für die Runde sind nur random.randint und random.choice vereinbart -- eine andere Funktion aus "
                "random zählt der Check nicht mit.")
        erwarte(not abbruch, "Bei runde bricht das Spiel ab -- bei manchen Würfen.")
        erwarte(RUNDE_SATZ in _nach(aus, "runde"), "Nach runde steht nicht „Byte dreht seine Runde: …“ in der Shell.")
        meiste = max(meiste, zaehler["aufrufe"])
    erwarte(meiste > 0, "Eure Runde ruft den Zufall gar nicht -- die Reihenfolge soll aus dem Zufall kommen.")
    erwarte(meiste <= len(RAEUME),
            "Eure Runde ruft den Zufall bis zu %d-mal -- vereinbart sind höchstens fünf Aufrufe, einer je Raum." % meiste)


def pruefe_a1_runde():
    """Aufgabe 10 ★★★★ · runde: jeder Raum genau einmal, die Reihenfolge aus dem Zufall, sonst bleibt alles"""
    braucht(_random_da() and RUNDE_SATZ in quelltext())
    braucht(_runde_fertig())
    folgen = set()
    for k in range(RUNDE):
        # ziffern: Der Zufall wechselt auch innerhalb des Laufs -- sonst saehe eine Runde, die fuenfmal aus demselben
        # Bereich wuerfelt und tauscht, nach „nur fuenf verschiedenen Runden“ aus
        aus, _ = _spiel(["runde", "ende"], k=k, art="ziffern", zaehler={})
        folge, zeile = _runde(aus)
        erwarte(sorted(folge) == sorted(RAEUME),
                "In der Runde steht nicht jeder der fünf Räume genau einmal (gesehen: %s)." % (zeile or "keine Runde"))
        folgen.add(tuple(folge))
    erwarte(len(folgen) > 1, "Die Runde hat bei jedem festen Wurf dieselbe Reihenfolge -- kommt sie aus dem Zufall?")
    erwarte(len(folgen) > 10,
            "Bei 60 festen Würfen entstehen nur %d verschiedene Runden -- kommt jeder Platz der Runde aus dem Zufall, "
            "oder nur der Anfang?" % len(folgen))
    # erst der Standort, dann das zweite runde: Wer raum ueberschreibt, steht danach am Tor -- das Spiel ist zu Ende,
    # und das zweite runde kaeme gar nicht mehr dran
    for k in range(0, RUNDE, 7):
        aus, _ = _spiel(["runde", "schau", "ende"], k=k, zaehler={})
        erwarte("Der Flur" in _nach(aus, "schau"),
                "Nach runde steht ihr nicht mehr im Flur -- oder das Spiel ist schon zu Ende. Die Runde dreht Byte, "
                "nicht ihr: Welches Kästchen sagt, wo ihr steht?")
    for k in range(0, RUNDE, 7):
        aus, abbruch = _spiel(["runde", "runde", "ende"], k=k, zaehler={})
        folge, zeile = _runde(aus, 2)
        erwarte(not abbruch and sorted(folge) == sorted(RAEUME),
                "Beim zweiten runde stehen nicht mehr alle fünf Räume da (gesehen: %s) -- ist die Liste raeume nach "
                "dem ersten Befehl noch dieselbe?" % (zeile or "keine Runde"))


# ── Aufgabe 11 · Expertenspur ⑤: Der Musikraum ────────────────────────────
# Die Spur steht in keinem Stand (planung/expertenspur/stufen.py): Wer sie geht, kopiert ihren Stand in das Spiel.
# Alle Pruefungen warten, bis es den Befehl spiele gibt. Der Check spielt das Spiel an, setzt oben andere Werte ein
# (_spur_spiel(..., ersetzen={...})) und stellt den Zufall fest ein (folge=[...]: die Toene, die random.choice der
# Reihe nach aus einer Liste von Tasten waehlt -- steht der Ton nicht darin, der erste; folge=k: immer das Element auf
# Platz k % len; randint liefert immer b -- keine Sicherung, kein Kater).
import io as _spur_io
import random as _spur_random
import sys as _spur_sys

SPUR_SCHLUSS = "§SPURSCHLUSS§"
SPUR_VORN = """import random as _spur_r
_spur_folge = %r
_spur_gewuerfelt = []
def _spur_wahl(liste):
    if len(liste) > 0 and all(len(x) == 1 and x in "cdefgah" for x in liste):
        _spur_gewuerfelt.append(1)
        if isinstance(_spur_folge, int):
            return liste[_spur_folge %% len(liste)]
        if _spur_folge:
            ton = _spur_folge.pop(0)
            return ton if ton in liste else liste[0]
    return liste[0]
_spur_r.choice = _spur_wahl
_spur_r.randint = lambda a, b: b
"""


def _spur_da():
    return '"spiele ' in ohne_kommentare() or "'spiele " in ohne_kommentare()


def _spur_spiel(befehle, ersetzen=None, folge=None, vorn=""):
    """Das Spiel mit diesen Befehlen. ersetzen: {name: wert} fuer die erste Zeile `name = ...` ganz links; folge:
    der Zufall fest (siehe oben); vorn: Code, der vor dem Spiel laeuft. Gibt (aus, abbruch, ns)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in (ersetzen or {}).items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    if folge is not None:
        vorn = SPUR_VORN % (folge if isinstance(folge, int) else list(folge),) + vorn
    pruefen._QUELLE = vorn + q + "\nprint(%r)\n" % SPUR_SCHLUSS
    echt = (_spur_random.choice, _spur_random.randint)
    try:
        aus, ns = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
        _spur_random.choice, _spur_random.randint = echt
    fertig = SPUR_SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet), ns


def _spur_nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _spur_toene(*toene):
    return ["spiele %s" % t for t in toene]


def _spur_punkte(aus):
    m = re.search(r"Spielzeit:.*?(-?\d+)\s*Punkte", aus)
    return int(m.group(1)) if m else None

SPUR_TASTEN = ["c", "d", "e", "f", "g", "a", "h"]


def _spur_gehoert(aus, n=1):
    """Die Töne aus „Das Klavier spielt: G, E und C.“ als Liste (klein), sonst None."""
    m = None
    for m in re.finditer(r"Das Klavier spielt:\s*(.*?)\.?\s*$", aus, re.M):
        n -= 1
        if n == 0:
            break
    if m is None or n > 0:
        return None
    return [t.strip().lower() for t in m.group(1).replace(" und ", ", ").split(",") if t.strip()]


def _spur_hoer_da():
    return '"hör zu"' in ohne_kommentare() or "'hör zu'" in ohne_kommentare()


def pruefe_f0_hoer_zu():
    """Aufgabe 11 ★★★★ · hör zu spielt eine Melodie aus dem Zufall vor -- gewürfelt erst am Klavier"""
    braucht(_spur_da())
    erwarte(_spur_hoer_da(), "Es gibt noch keinen Befehl hör zu.")
    aus, abbruch, ns = _spur_spiel(["ende"], folge=[])
    braucht(not abbruch)
    erwarte(not ns.get("_spur_gewuerfelt"),
            "Das Spiel würfelt die Melodie schon beim Start, obwohl niemand ans Klavier geht -- erst beim ersten "
            "spiele oder hör zu.")
    aus, abbruch, _ = _spur_spiel(["hör zu", "ende"], folge=["c", "g", "e"])
    erwarte(not abbruch and _spur_gehoert(aus) == ["c", "g", "e"],
            "Liefert random.choice nacheinander c, g, e, spielt das Klavier bei hör zu nicht „C, G und E“ vor "
            "(es stand da: %s)." % (_spur_nach(aus, "hör zu").strip() or "nichts"))
    aus, _, _ = _spur_spiel(["westen", "hör zu", "ende"], folge=["c", "g", "e"])
    erwarte(_spur_gehoert(aus) is None, "Im Keller spielt das Klavier trotzdem vor -- es steht im Flur.")


def pruefe_f1_verschieden():
    """Aufgabe 11 ★★★★ · Die Auflage: drei verschiedene Töne -- mit genau drei Würfen, bei jedem Zufall"""
    braucht(_spur_da() and _spur_hoer_da())
    for k in range(7):
        aus, abbruch, ns = _spur_spiel(["hör zu", "hör zu", "ende"], folge=k)
        toene = _spur_gehoert(aus) or []
        erwarte(not abbruch, "Liefert random.choice immer das Element auf Platz %d, bricht hör zu ab." % k)
        erwarte(len(toene) == 3 and len(set(toene)) == 3,
                "Liefert random.choice immer das Element auf Platz %d, spielt das Klavier %s vor -- verlangt sind drei "
                "verschiedene Töne." % (k, ", ".join(toene) or "nichts"))
        wuerfe = len(ns.get("_spur_gewuerfelt", []))
        erwarte(wuerfe == 3, "Für die Melodie hat das Spiel %d-mal gewürfelt -- die Auflage sagt: genau drei Würfe "
                "(und nur einmal je Spiel)." % wuerfe)
        erwarte(_spur_gehoert(aus, 2) == toene, "Beim zweiten hör zu ist die Melodie eine andere -- sie wird nur "
                "einmal gewürfelt.")


def pruefe_f2_bank():
    """Aufgabe 11 ★★★★ · Die gewürfelte Melodie öffnet die Bank -- auch ohne hör zu"""
    braucht(_spur_da() and _spur_hoer_da())
    aus, abbruch, _ = _spur_spiel(_spur_toene("a", "h", "d") + ["ende"], folge=["a", "h", "d"])
    erwarte(not abbruch and "Die Bank springt auf" in _spur_nach(aus, "spiele d"),
            "Würfelt der Zufall a, h, d, springt die Bank nach spiele a, spiele h, spiele d nicht auf.")


def pruefe_f3_jeder_wurf():
    """Aufgabe 11 ★★★★ · Bei jedem echten Wurf: drei verschiedene Tasten -- und nicht immer dieselben"""
    braucht(_spur_da() and _spur_hoer_da())
    gesehen = set()
    for saat in range(25):
        aus, abbruch, _ = _spur_spiel(["hör zu", "ende"], vorn="import random as _r\n_r.seed(%d)\n" % saat)
        toene = _spur_gehoert(aus) or []
        erwarte(not abbruch and len(toene) == 3 and len(set(toene)) == 3 and all(t in SPUR_TASTEN for t in toene),
                "Bei einem echten Wurf spielt das Klavier %s vor -- verlangt sind drei verschiedene Tasten."
                % (", ".join(toene) or "nichts"))
        gesehen.add(tuple(toene))
    erwarte(len(gesehen) > 3, "In 25 Läufen kamen nur %d verschiedene Melodien -- kommt die Melodie aus dem Zufall?"
            % len(gesehen))
