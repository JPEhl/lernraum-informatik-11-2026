punkte = [140, 95, 120, 60, 110]
anzahl = 0
summe = 0
maximum = punkte[0]
for p in punkte:
    if p > 100:
        anzahl = anzahl + 1
    summe = summe + p
    if p > maximum:
        maximum = p
print(anzahl, "Nächte über 100")
print("Durchschnitt:", summe / len(punkte))
print("Maximum:", maximum)
