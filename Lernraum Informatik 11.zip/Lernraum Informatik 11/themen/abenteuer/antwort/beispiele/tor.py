rucksack = ["lampe", "torschlüssel"]
raum = "flur"


def pruefe_tuer() -> bool:
    return "torschlüssel" in rucksack


if pruefe_tuer():
    raum = "tor"
    print("Du schließt das Tor auf.")
else:
    print("Abgeschlossen.")
print("Raum:", raum)
