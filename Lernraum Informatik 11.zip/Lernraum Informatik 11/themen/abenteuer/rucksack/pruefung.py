"""Selbstcheck zu "Listen" (Der Rucksack) -- prueft rucksack.py (Aufgabe 2, Aufgabe 5 und
unter Mehr die Expertenaufgabe 8).

Spielt das Spiel mit einer FOLGE von Befehlen an und setzt vorher oben einen anderen
Rucksack (rucksack = [...]) -- so sieht der Check, ob das Spiel wirklich die Liste
fragt und nicht noch die drei Taschen. Geprueft wird das Verhalten: Wer kommt durchs
Tor, was liegt nach lege noch im Rucksack, was sagt zeige, wann ist er voll? Nicht der
Wortlaut des Codes. Verraet keine Zeile, nur woran es haengt.

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code
haengt (SCHLUSS, wie in "Zuege und Punkte"): Fehlt sie, ist es unterwegs abgebrochen --
anspielen() schneidet die Fehlermeldung ab. Fragt das Spiel nach den Befehlen weiter,
endet die Ausgabe mit "> ".

Die Auflage der Expertenaufgabe (nur append, remove, in, len und der Index) prueft der Check am
VERHALTEN, wie in "Die for-Schleife" die gezaehlten Vergleiche: Er setzt oben einen Rucksack ein,
der sich merkt, ob pop, del, insert, reverse oder ein Ausschnitt [ : ] ihn angefasst haben.
"""
import re

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen

TITEL = "Listen · Selbstcheck"

# So spielt der Check das Programm an (wie in Aufgabe 2 ★): in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"
VOLL = "Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht. Leg etwas ab."
SCHLUSS = "§SCHLUSS§"


# Ein Rucksack, der sich merkt, welche Handgriffe ihn anfassen (Auflage der Expertenaufgabe 8): Er ist eine
# Liste wie jede andere -- print, len, in, append, remove und der Index wirken wie immer.
PROBE = """
class _Probe(list):
    griffe = []
    def pop(self, *a):
        _Probe.griffe.append("pop")
        return list.pop(self, *a)
    def __delitem__(self, i):
        _Probe.griffe.append("del")
        return list.__delitem__(self, i)
    def insert(self, *a):
        _Probe.griffe.append("insert")
        return list.insert(self, *a)
    def reverse(self):
        _Probe.griffe.append("reverse")
        return list.reverse(self)
    def __getitem__(self, i):
        if isinstance(i, slice):
            _Probe.griffe.append("[ : ]")
        return list.__getitem__(self, i)
"""


def _zuweisung_ersetzen(q, name, neu):
    """Die erste Zuweisung name = ... ganz links ersetzen -- eine Liste auch, wenn sie ueber mehrere Zeilen geht
    (bis zur passenden Klammer). neu bekommt den alten Wert als Text."""
    m = re.search(r"^%s[ \t]*=[ \t]*" % name, q, flags=re.M)
    if not m:
        return q
    a = m.end()
    e = q.find("\n", a)
    e = len(q) if e < 0 else e
    if q[a:a + 1] == "[":
        tiefe = 0
        for i in range(a, len(q)):
            tiefe += {"[": 1, "]": -1}.get(q[i], 0)
            if tiefe == 0:
                e = i + 1
                break
    return q[:m.start()] + "%s = %s" % (name, neu(q[a:e])) + q[e:]


def _spiel(befehle, probe=False, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte (rucksack=[...]). Gibt
    (text, abbruch, ns): was nach dem Anfang in der Shell steht, ob das Programm unterwegs
    abgebrochen ist, und die Variablen, wie sie zuletzt standen. probe=True: der Rucksack
    oben ist ein _Probe, der die Handgriffe mitschreibt (ns["_Probe"].griffe)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = _zuweisung_ersetzen(q, name, lambda _alt, wert=wert: repr(wert))
    if probe:
        q = PROBE + _zuweisung_ersetzen(q, "rucksack", lambda w: "_Probe(%s)" % w)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, ns = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    abbruch = not fertig and not wartet
    marke = "leuchtet.\n"
    return (aus[aus.find(marke) + len(marke):] if marke in aus else aus), abbruch, ns


def _hat_liste():
    """Oben steht ein Rucksack als Liste (nicht eingerueckt)."""
    return re.search(r"^rucksack[ \t]*=[ \t]*\[", ohne_kommentare(), re.M) is not None


def _in_schleife():
    """Steht eine Liste rucksack = [...] direkt im Rumpf der Spielschleife (eine Stufe eingerueckt) -- dann faengt
    er jeden Zug von vorn an. Tiefer, in einem Befehl (wirf baut den Rucksack neu), ist es kein Fehler."""
    return re.search(r"^(?:    |\t)rucksack[ \t]*=[ \t]*\[", ohne_kommentare(), re.M) is not None


def _liste_ok():
    """Oben die Liste, und keine zweite in der Schleife -- erst dann sagen die anderen Pruefungen etwas."""
    return _hat_liste() and not _in_schleife()


def _taschen():
    """Steht im Code noch eine der drei Taschen?"""
    return re.search(r"\bgegenstand[123]\b", ohne_kommentare()) is not None


def _punkte_am_ende(aus):
    """Die Punkte aus der Zeile „Spielzeit: … - n Punkte“, sonst None."""
    m = re.search(r"Spielzeit:.*?(\d+)\s*Punkte", aus)
    return int(m.group(1)) if m else None


def _als_text(r):
    """Eine Liste so, wie sie oben im Code stuende: ["lampe", "karte"]."""
    return "[" + ", ".join('"%s"' % d for d in r) + "]"


def _zeige(aus):
    """Was zeige zuletzt gesagt hat: alles ab dem letzten „Du trägst“."""
    i = aus.rfind("Du trägst")
    return aus[i:] if i >= 0 else ""


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Ganzzahldivision und Modulo“ konnte"""
    aus, abbruch, _ = _spiel(["warte 2", "ende"])
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Spielzeit" in aus, "Am Ende steht keine Spielzeit mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 ★ · Liste, nimm und Tor ────────────────────────────────────

def pruefe_20_liste():
    """Aufgabe 2 · Oben steht der Rucksack als Liste, darin die Lampe"""
    erwarte(_hat_liste(), "Oben steht noch keine Liste rucksack = [...] -- und zwar ganz links, vor der Schleife.")
    erwarte(not _in_schleife(),
            "rucksack = [...] steht eingerückt, in der Schleife -- dann fängt der Rucksack in jedem Zug von vorn "
            "an. Er gehört nach oben, vor die Schleife.")
    _, _, ns = _spiel(["ende"])
    r = ns.get("rucksack")
    erwarte(isinstance(r, list) and "lampe" in r, "Am Anfang liegt keine Lampe im Rucksack.")


def pruefe_21_nimm():
    """Aufgabe 2 · nimm hängt an -- vier Dinge passen, jedes bringt 10 Punkte"""
    braucht(_liste_ok())
    aus, abbruch, ns = _spiel(["nimm karte", "nimm seil", "nimm kreide", "nimm heft", "ende"])
    erwarte("Kein Platz" not in aus, "Beim vierten Ding sagt das Spiel noch „Kein Platz mehr.“ -- fragt nimm noch die drei Taschen?")
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte("heft" in r and "karte" in r,
            "Nach nimm karte … nimm heft liegen Karte und Heft nicht im Rucksack. Hängt nimm das Ding an die Liste an?")
    punkte = _punkte_am_ende(aus)
    erwarte(not abbruch and punkte == 40,
            "Vier Dinge sind 40 Punkte -- in der Zeile mit der Spielzeit steht etwas anderes (oder sie fehlt).")


# Der Torschluessel auf wechselnden Plaetzen (Reihensichtung Teil II, #7): Lag er im Test immer auf
# Platz 1, bestand auch ein Tor, das nur rucksack[1] fragt. Vorn, hinten, in der Mitte -- je einmal.
MIT_SCHLUESSEL = [["lampe", "torschlüssel"], ["torschlüssel"], ["karte", "torschlüssel", "seil", "lampe"]]
OHNE_SCHLUESSEL = [["lampe"], ["karte", "seil", "lampe", "kreide"], []]


def pruefe_22_tor():
    """Aufgabe 2 · Das Tor fragt den Rucksack"""
    braucht(_liste_ok())
    for r in MIT_SCHLUESSEL:
        aus, _, _ = _spiel(["norden", "ende"], rucksack=r)
        erwarte(DRAUSSEN in aus,
                "Mit oben rucksack = %s geht das Tor nicht auf. Fragt das Tor den ganzen Rucksack -- egal, auf "
                "welchem Platz der Schlüssel liegt?" % _als_text(r))
    for r in OHNE_SCHLUESSEL:
        aus, _, _ = _spiel(["norden", "ende"], rucksack=r)
        erwarte(DRAUSSEN not in aus, "Mit oben rucksack = %s, ohne Torschlüssel, geht das Tor trotzdem auf." % _als_text(r))


def pruefe_23_keller():
    """Aufgabe 2 · Den Torschlüssel gibt es nur im Keller"""
    braucht(_liste_ok())
    aus, _, ns = _spiel(["nimm torschlüssel", "ende"])
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte("Hier liegt kein Torschlüssel" in aus and "torschlüssel" not in r,
            "Im Flur steckt nimm torschlüssel den Schlüssel trotzdem ein -- der Satz „Hier liegt kein Torschlüssel.“ gehört weiter davor.")


# ── Aufgabe 2 ★★ · lege und schau ───────────────────────────────────────

def pruefe_24_lege():
    """Aufgabe 2 ★★ · lege nimmt heraus -- aber nur, was da ist"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["lege karte", "lege karte", "ende"], rucksack=["lampe", "karte"])
    erwarte("Du legst weg: karte" in aus, "Mit oben rucksack = [\"lampe\", \"karte\"] legt lege karte die Karte nicht weg.")
    erwarte(not abbruch,
            "Beim zweiten lege karte bricht das Spiel ab. Was fragt ihr, bevor ihr remove schreibt?")
    erwarte("Das hast du nicht" in aus, "Beim zweiten lege karte fehlt „Das hast du nicht.“")


def pruefe_25_vergisst_nicht():
    """Aufgabe 2 ★★ · Der Rucksack vergisst nichts zwischen zwei Zügen"""
    braucht(_hat_liste())
    braucht("remove" in ohne_kommentare())
    aus, _, _ = _spiel(["nimm karte", "lege karte", "ende"])
    erwarte("Du legst weg: karte" in aus,
            "Erst nimm karte, dann lege karte -- und das Spiel sagt, ihr habt sie nicht. Fängt der Rucksack "
            "in jedem Durchlauf der Schleife von vorn an?")


def pruefe_26_schau():
    """Aufgabe 2 ★★ · schau fragt, ob die Lampe im Rucksack ist"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["schau", "ende"], rucksack=["karte"])
    erwarte(not abbruch, "Bei schau bricht das Spiel ab -- steht dort noch eine der drei Taschen?")
    erwarte("Stockdunkel" in aus, "Mit oben rucksack = [\"karte\"] (ohne Lampe) ist es bei schau nicht stockdunkel.")
    aus, _, _ = _spiel(["westen", "schau", "ende"], rucksack=["karte", "lampe"])
    erwarte("Der Keller" in aus, "Mit der Lampe im Rucksack beschreibt schau im Keller den Raum nicht.")


# ── Aufgabe 2 ★★★ · zeige ───────────────────────────────────────────────

def pruefe_27_zeige():
    """Aufgabe 2 ★★★ · zeige sagt Anzahl und Liste"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["zeige", "ende"], rucksack=["karte", "seil"])
    z = _zeige(aus)
    erwarte(not abbruch, "Bei zeige bricht das Spiel ab -- steht dort noch eine der drei Taschen?")
    erwarte(re.search(r"\b2 Dinge", z) is not None and "'karte', 'seil'" in z,
            "Mit oben rucksack = [\"karte\", \"seil\"] sagt zeige nicht „Du trägst 2 Dinge: ['karte', 'seil']“.")


def pruefe_28_zeige_leer():
    """Aufgabe 2 ★★★ · zeige stimmt auch beim leeren Rucksack"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["zeige", "ende"], rucksack=[])
    erwarte(not abbruch and re.search(r"\b0 Dinge", _zeige(aus)) is not None,
            "Mit oben rucksack = [] bricht zeige ab oder sagt nicht „0 Dinge“.")


def pruefe_29_keine_taschen():
    """Aufgabe 2 ★★★ · Die drei Taschen sind ganz weg"""
    braucht(_liste_ok())
    erwarte(not _taschen(), "Im Code steht noch gegenstand1, gegenstand2 oder gegenstand3 -- sucht mit Strg+F (Mac ⌘+F).")


# ── Aufgabe 5 · Wie im Abitur: Der volle Rucksack ────────────────────────

SECHS = ["nimm heft", "nimm buch", "nimm apfel", "nimm seil", "nimm kreide", "nimm stift"]


def pruefe_40_voll():
    """Aufgabe 5 · Mit sechs Dingen ist der Rucksack voll"""
    braucht(_liste_ok())
    aus, abbruch, ns = _spiel(SECHS + ["ende"])
    braucht(not abbruch)
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte(len(r) == 6,
            "Lampe und sechsmal nimm: Im Rucksack liegen %d Dinge, nicht sechs. Das sechste nimm muss liegen bleiben." % len(r))
    erwarte(VOLL in aus, "Beim siebten Ding sagt das Spiel nicht „%s“" % VOLL)
    erwarte(aus.count("Du nimmst:") == 5, "Ein Ding, das nicht mehr hineinpasst, wird trotzdem „genommen“.")


def pruefe_41_punkte():
    """Aufgabe 5 · Punkte nur für Dinge, die wirklich mitkommen"""
    braucht(_liste_ok())
    braucht(VOLL in ohne_kommentare())
    aus, _, _ = _spiel(SECHS + ["ende"])
    punkte = _punkte_am_ende(aus)
    erwarte(punkte == 50,
            "Fünf Dinge kommen in den Rucksack, das sind 50 Punkte -- am Ende stehen %s. Gibt es Punkte für das "
            "Ding, das liegen bleibt?" % punkte)


def pruefe_42_wieder_platz():
    """Aufgabe 5 · Wer etwas ablegt, hat wieder Platz"""
    braucht(_liste_ok())
    braucht(VOLL in ohne_kommentare())
    aus, abbruch, ns = _spiel(SECHS[:5] + ["lege heft", "nimm stift", "ende"])
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte(not abbruch and "stift" in r and VOLL not in aus,
            "Lampe und fünf Dinge, dann lege heft und nimm stift -- der Stift kommt nicht hinein. Steht die Grenze "
            "bei nimm und fragt sie, wie viele Dinge JETZT im Rucksack sind?")


# ── Aufgabe 8 · Für Expert*innen: Wirf! ───────────────────────────────────

def _wirf_da():
    return '"wirf' in ohne_kommentare() or "'wirf" in ohne_kommentare()


def _liste(ns):
    r = ns.get("rucksack")
    return list(r) if isinstance(r, list) else []


def pruefe_90_wirf():
    """Aufgabe 8 ★★★★ · wirf wirft das zuletzt genommene Ding weg"""
    braucht(_wirf_da())
    braucht(_liste_ok())
    aus, abbruch, ns = _spiel(["nimm karte", "nimm seil", "wirf", "ende"])
    r = _liste(ns)
    nimm = "Du nimmst: seil"
    danach = aus[aus.rfind(nimm) + len(nimm):] if nimm in aus else ""
    erwarte(not abbruch, "Bei wirf bricht das Spiel ab.")
    erwarte("seil" not in r and "karte" in r,
            "Nach nimm karte, nimm seil, wirf liegt nicht genau das Seil weg -- das zuletzt genommene Ding.")
    erwarte("seil" in danach, "wirf sagt nicht, welches Ding es weggeworfen hat.")


def pruefe_91_wirf_leer():
    """Aufgabe 8 ★★★★ · wirf beim leeren Rucksack bricht nicht ab"""
    braucht(_wirf_da())
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["wirf", "ende"], rucksack=[])
    erwarte(not abbruch and TREPPE in aus,
            "Mit oben rucksack = [] bricht wirf ab -- was fragt ihr, bevor ihr etwas herausnehmt?")
    erwarte("nichts zum Werfen" in aus, "Beim leeren Rucksack fehlt „Du hast nichts zum Werfen.“")


def pruefe_92_wirf_gleiche():
    """Aufgabe 8 ★★★★ · wirf trifft das zuletzt genommene Ding -- auch bei zwei gleichen"""
    braucht(_wirf_da())
    braucht(_liste_ok())
    _, abbruch, ns = _spiel(["nimm kreide", "nimm seil", "nimm kreide", "wirf", "wirf", "ende"])
    r = _liste(ns)
    erwarte(not abbruch, "Nach nimm kreide, nimm seil, nimm kreide und zweimal wirf bricht das Spiel ab.")
    erwarte(r == ["lampe", "kreide"],
            "Nach nimm kreide, nimm seil, nimm kreide und zweimal wirf liegt im Rucksack %s -- die erste Kreide "
            "müsste noch da sein, das Seil nicht. Welche Kreide nimmt euer wirf heraus?" % _als_text(r))


def pruefe_93_auflage():
    """Aufgabe 8 ★★★★ · Die Auflage: nur die Handgriffe aus der Erklärung"""
    braucht(_wirf_da())
    braucht(_liste_ok())
    _, abbruch, ns = _spiel(["nimm karte", "nimm seil", "wirf", "wirf", "ende"], probe=True)
    probe = ns.get("_Probe")
    braucht(probe is not None and not abbruch)
    griffe = sorted(set(probe.griffe))
    erwarte(not griffe,
            "Euer wirf benutzt %s -- die Auflage erlaubt nur append, remove, in, len und den Index."
            % " und ".join(griffe))


# ── Aufgabe 9 · Expertenspur ①: Der Musikraum ────────────────────────────
# Die Spur steht in keinem Stand (planung/expertenspur/stufen.py): Wer sie geht, kopiert ihren Stand in das Spiel.
# Alle Pruefungen warten, bis es den Befehl spiele gibt. Der Check spielt das Spiel an, setzt oben andere Werte ein
# (_spur_spiel(..., ersetzen={...})) und stellt den Zufall fest ein (folge=[...]: die Toene, die random.choice der
# Reihe nach aus einer Liste von Tasten waehlt -- steht der Ton nicht darin, der erste; folge=k: immer das Element auf
# Platz k % len; randint liefert immer b -- keine Sicherung, kein Kater).
import io as _spur_io
import random as _spur_random
import sys as _spur_sys

SPUR_SCHLUSS = "§SPURSCHLUSS§"
SPUR_VORN = """import random as _spur_r
_spur_folge = %r
_spur_gewuerfelt = []
def _spur_wahl(liste):
    if len(liste) > 0 and all(len(x) == 1 and x in "cdefgah" for x in liste):
        _spur_gewuerfelt.append(1)
        if isinstance(_spur_folge, int):
            return liste[_spur_folge %% len(liste)]
        if _spur_folge:
            ton = _spur_folge.pop(0)
            return ton if ton in liste else liste[0]
    return liste[0]
_spur_r.choice = _spur_wahl
_spur_r.randint = lambda a, b: b
"""


def _spur_da():
    return '"spiele ' in ohne_kommentare() or "'spiele " in ohne_kommentare()


def _spur_spiel(befehle, ersetzen=None, folge=None, vorn=""):
    """Das Spiel mit diesen Befehlen. ersetzen: {name: wert} fuer die erste Zeile `name = ...` ganz links; folge:
    der Zufall fest (siehe oben); vorn: Code, der vor dem Spiel laeuft. Gibt (aus, abbruch, ns)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in (ersetzen or {}).items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    if folge is not None:
        vorn = SPUR_VORN % (folge if isinstance(folge, int) else list(folge),) + vorn
    pruefen._QUELLE = vorn + q + "\nprint(%r)\n" % SPUR_SCHLUSS
    echt = (_spur_random.choice, _spur_random.randint)
    try:
        aus, ns = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
        _spur_random.choice, _spur_random.randint = echt
    fertig = SPUR_SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet), ns


def _spur_nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _spur_toene(*toene):
    return ["spiele %s" % t for t in toene]


def _spur_punkte(aus):
    m = re.search(r"Spielzeit:.*?(-?\d+)\s*Punkte", aus)
    return int(m.group(1)) if m else None

# Die Auflage „nie mehr als drei“: oben steht statt gespielt = [] eine Liste, die nach jedem append ihre Laenge
# mitschreibt (wie _Probe fuer wirf).
SPUR_MERKT = """
class _SpurMerkt(list):
    laengen = []
    def append(self, x):
        list.append(self, x)
        _SpurMerkt.laengen.append(len(self))
"""


def _spur_gespielt_liste():
    return re.search(r"^gespielt[ \t]*=[ \t]*\[", ohne_kommentare(), re.M) is not None


def pruefe_b0_klavier():
    """Aufgabe 9 ★★★★ · Das Klavier steht im Flur und kennt seine sieben Tasten"""
    braucht(_spur_da())
    braucht(_liste_ok())
    aus, abbruch, _ = _spur_spiel(_spur_toene("c", "x") + ["westen", "spiele c", "ende"])
    erwarte(not abbruch, "Bei spiele bricht das Spiel ab.")
    erwarte("Pling: c" in _spur_nach(aus, "spiele c"), "Im Flur sagt spiele c nicht mehr „Pling: c“.")
    x = _spur_nach(aus, "spiele x")
    erwarte("Diese Taste gibt es nicht" in x and "Pling" not in x,
            "spiele x sagt nicht „Diese Taste gibt es nicht.“ -- das Klavier hat nur c, d, e, f, g, a und h.")
    erwarte("Hier steht kein Klavier" in _spur_nach(aus, "spiele c", 2),
            "Im Keller spielt das Klavier trotzdem -- es steht im Flur.")


def pruefe_b1_bank():
    """Aufgabe 9 ★★★★ · g, e, c öffnet die Klavierbank -- einmal, mit 30 Punkten"""
    braucht(_spur_da())
    braucht(_liste_ok())
    aus, abbruch, _ = _spur_spiel(_spur_toene("g", "e", "c") + ["ende"])
    erwarte(not abbruch and "Die Bank springt auf" in _spur_nach(aus, "spiele c"),
            "Nach spiele g, spiele e, spiele c springt die Bank nicht auf.")
    erwarte(_spur_punkte(aus) == 30, "Nach g, e, c stehen am Ende %s Punkte, nicht 30." % _spur_punkte(aus))
    aus, _, _ = _spur_spiel(_spur_toene("g", "e", "c", "g", "e", "c") + ["ende"])
    erwarte(aus.count("Die Bank springt auf") == 1 and _spur_punkte(aus) == 30,
            "Zweimal g, e, c: Die Bank springt %d-mal auf (%s Punkte) -- sie geht nur einmal auf."
            % (aus.count("Die Bank springt auf"), _spur_punkte(aus)))


def pruefe_b2_letzte_drei():
    """Aufgabe 9 ★★★★ · Es zählen die letzten drei Töne -- und nur echte Tasten"""
    braucht(_spur_da())
    braucht(_liste_ok())
    for toene, auf in ((("c", "g", "e", "c"), True), (("g", "c", "e", "c"), False), (("g", "e", "d", "c"), False),
                       (("g", "e", "x", "c"), True), (("e", "g", "e", "c"), True)):
        aus, abbruch, _ = _spur_spiel(_spur_toene(*toene) + ["ende"])
        folge = ", ".join(toene)
        erwarte(not abbruch, "Bei den Tönen %s bricht das Spiel ab." % folge)
        if auf:
            erwarte("Die Bank springt auf" in aus,
                    "Nach den Tönen %s springt die Bank nicht auf -- die letzten drei Tasten waren g, e, c." % folge)
        else:
            erwarte("Die Bank springt auf" not in aus,
                    "Nach den Tönen %s springt die Bank auf -- die letzten drei waren nicht g, e, c." % folge)


def pruefe_b3_nie_mehr_als_drei():
    """Aufgabe 9 ★★★★ · Die Auflage: gespielt hat nie mehr als drei Töne"""
    braucht(_spur_da())
    braucht(_liste_ok())
    braucht(_spur_gespielt_liste())
    alt = pruefen._QUELLE
    pruefen._QUELLE = SPUR_MERKT + re.sub(r"^gespielt[ \t]*=[ \t]*\[\]", "gespielt = _SpurMerkt()", alt,
                                           count=1, flags=re.M)
    try:
        _, abbruch, ns = _spur_spiel(_spur_toene("c", "d", "e", "f", "g", "e", "c") + ["ende"])
    finally:
        pruefen._QUELLE = alt
    k = ns.get("_SpurMerkt")
    braucht(k is not None and not abbruch)
    meiste = max(k.laengen) if k.laengen else 0
    erwarte(meiste > 0, "In gespielt kommt nie ein Ton an -- hängt spiele den Ton an die Liste an?")
    erwarte(meiste <= 3,
            "Nach einem append hatte gespielt %d Töne -- die Auflage sagt: nie mehr als drei, auch nicht für einen "
            "Augenblick." % meiste)
