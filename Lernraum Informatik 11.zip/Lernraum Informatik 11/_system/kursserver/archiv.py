"""Kurse im Lehrerpult archivieren, wiederherstellen und loeschen (Lehrer 25.11.2026: „die Möglichkeit, Kurse zu
archivieren und zu löschen (archivieren hätte dann immer die Möglichkeit, den Kurs wiederherzustellen)“; Attrappe
https://claude.ai/artifact/5Daki1KgdN6VsAsQpBPiSG, „Atrappe sieht gut aus“ -- vier Entscheidungen angenommen).

  1  Archivieren merkt die Klasse nicht: das Pult blendet den Kurs aus Kursmenue und „Meine Kurse“ aus; Staende,
     Abgaben, Nadeln, Werkbuch bleiben, wo sie sind.
  2  Das Archiv steht unter „Meine Kurse“; Wiederherstellen stellt alles zurueck. Nur bei Beamer aus.
  3  Loeschen nur aus dem Archiv und nur mit dem Namen des Kurses. Es nimmt den Kursordner im Pult samt seinen Spuren
     weg (vorher bietet die Seite die Abgaben als ZIP an). Im Projekt wandert der Kursordner ins Archiv der Werkstatt.
  4  Kapitel gehen nie mit: ein Kurs, der eigene Kapitel traegt (ein Heimatkurs), laesst sich nur archivieren.

Der Stand jedes Kurses ist eine SPUR im Pult (<pult>/_archiv/archiv.json; der Abzug bewahrt den Ordner wie _angelegt/)
-- sie gilt vor dem, was das Projekt in pult.json geschrieben hat; das Projekt traegt sie beim naechsten Bau in
informatik/lehrerpult.md nach (uebernehmen.archiv_abgleichen).

Nur die Standardbibliothek (das Pult laeuft am Schulrechner in Thonny).
"""
import datetime
import io
import json
import os
import pathlib
import shutil
import tempfile
import time
import zipfile

ORDNER = "_archiv"
DATEI = "archiv.json"
ZUSTAENDE = ("aktiv", "archiviert", "geloescht")


def _pfad(pult):
    return pathlib.Path(pult) / ORDNER / DATEI


def lesen(pult):
    """{kurs: {"zustand", "zeit", "name"}} -- leer, wenn noch nie etwas archiviert wurde oder die Datei unlesbar ist."""
    p = _pfad(pult)
    try:
        d = json.loads(p.read_text("utf-8"))
    except (OSError, ValueError):
        return {}
    k = d.get("kurse") if isinstance(d, dict) else None
    return {n: e for n, e in (k or {}).items() if isinstance(e, dict) and e.get("zustand") in ZUSTAENDE}


def setzen(pult, kurs, zustand, name=""):
    """Schreibt den Zustand eines Kurses (ersetzt die Datei in einem Zug -- OneDrive meldet beim Hochladen kurz
    „Zugriff verweigert“, deshalb mehrere Versuche wie stand.ersetzen)."""
    if zustand not in ZUSTAENDE:
        raise ValueError("Zustand: " + zustand)
    alle = lesen(pult)
    alle[kurs] = {"zustand": zustand, "zeit": datetime.datetime.now().isoformat(timespec="seconds"), "name": name}
    p = _pfad(pult)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".archiv_", dir=p.parent)
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps({"kurse": alle}, ensure_ascii=False, indent=1) + "\n")
        f.flush()
        os.fsync(f.fileno())
    for i in range(12):
        try:
            os.replace(tmp, p)
            break
        except PermissionError:
            if i == 11:
                raise
            time.sleep(0.25)
    return alle[kurs]


def zaehlen(kursordner):
    """Was im Pult zu einem Kurs liegt -- fuer die Archivkarte und das Loeschfenster."""
    k = pathlib.Path(kursordner)
    abgaben = sum(1 for _ in (k / "abgaben").rglob("*.zip")) if (k / "abgaben").is_dir() else 0
    nadeln = 0
    try:
        d = json.loads((k / "_durchsicht" / "durchsicht.json").read_text("utf-8"))
        nadeln = len(d.get("nadeln") or [])
    except (OSError, ValueError, AttributeError):
        pass
    anmerkungen = sum(1 for _ in (k / "_anmerkungen").glob("*.json")) if (k / "_anmerkungen").is_dir() else 0
    return {"abgaben": abgaben, "nadeln": nadeln, "anmerkungen": anmerkungen}


def abgaben_zip(kursordner, kurs):
    """Die Abgaben und Anmerkungen eines Kurses als eine ZIP (bytes) -- zum Sichern vor dem Loeschen."""
    k = pathlib.Path(kursordner)
    puffer = io.BytesIO()
    with zipfile.ZipFile(puffer, "w", zipfile.ZIP_DEFLATED) as z:
        for teil in ("abgaben", "_anmerkungen"):
            for datei in sorted((k / teil).rglob("*")) if (k / teil).is_dir() else []:
                if datei.is_file():
                    z.write(datei, "%s/%s/%s" % (kurs, teil, datei.relative_to(k / teil).as_posix()))
    return puffer.getvalue()


def ordner_loeschen(ordner, versuche=12):
    """Den Kursordner im Pult entfernen; OneDrive haelt Dateien beim Hochladen kurz fest."""
    ordner = pathlib.Path(ordner)
    for i in range(versuche):
        try:
            if ordner.exists():
                shutil.rmtree(ordner)
            return
        except PermissionError:
            if i == versuche - 1:
                raise
            time.sleep(0.25)
