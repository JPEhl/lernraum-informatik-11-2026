"""Das Fenster der Klasse geht VOR dem Browser auf (Probelauf 2, 28.10., S14).

Unter Windows oeffnete sich ein tk-Fenster, das aus dem Lernraum gestartet wird,
hinter dem Browser (nur in der Taskleiste zu sehen). ausfuehren.Lauf legt diesen
Ordner auf PYTHONPATH; Python laedt sitecustomize.py beim Start von selbst, noch
vor der Datei der Klasse -- deren Traceback bleibt so ohne fremde Zeilen.

Jedes neue Hauptfenster (tk.Tk) steht kurz „immer im Vordergrund“, wird nach
vorn geholt und ist danach ein gewoehnliches Fenster. Der Selbstcheck laeuft mit
-I, sieht PYTHONPATH nicht und bleibt unsichtbar (pruefen._still_stellen).

Diese Datei VERDECKT eine sitecustomize.py des Pythons selbst (Homebrew legt eine
an, die die Pfade richtet -- ohne sie fehlte _tkinter, Browsertest 28.10.). Darum
zuerst den eigenen Ordner aus sys.path nehmen und jene ausfuehren, falls es sie gibt.
"""
import importlib.machinery
import importlib.util
import os
import sys

_HIER = os.path.dirname(os.path.abspath(__file__))
sys.path[:] = [p for p in sys.path if os.path.abspath(p or os.curdir) != _HIER]
_spec = importlib.machinery.PathFinder.find_spec("sitecustomize", sys.path)
if _spec is not None and _spec.loader is not None:
    _spec.loader.exec_module(importlib.util.module_from_spec(_spec))

try:
    import tkinter as _tk
except ImportError:
    _tk = None

if _tk is not None:
    _bauen = _tk.Tk.__init__

    def _vorne(self, *a, **kw):
        _bauen(self, *a, **kw)
        if os.environ.get("LERNRAUM_UNSICHTBAR"):     # Testlaeufe (frisch.sh, fensterseite.py): nie ein Fenster auf dem Schirm
            try:
                self.withdraw()
            except _tk.TclError:
                pass
            return
        try:
            self.attributes("-topmost", True)
            self.lift()
            self.after(400, self._lernraum_normal)
        except _tk.TclError:
            pass

    def _normal(self):
        try:
            self.attributes("-topmost", False)
            self.focus_force()
        except _tk.TclError:
            pass

    _tk.Tk.__init__ = _vorne
    _tk.Tk._lernraum_normal = _normal

# -- Fenster im Browser (13.11.2026, Lehrer: Vortrag A, Uebung B) ------------------------------------------------------
# Ein Programm, das NUR auf eine Zeichenflaeche malt (das Schachbrett der Q1), oeffnet kein echtes Fenster mehr: Es
# sprang am Beamer ueber die Folie, nahm den Fokus und ging an Schulrechnern hinter dem Browser auf. Setzt der Server
# LERNRAUM_FENSTER (eine Datei), bleibt jedes Hauptfenster versteckt; bei mainloop() -- oder am Ende des Programms, wenn
# es keins aufruft oder abbricht -- schreibt diese Datei die Zeichenflaechen dorthin (dasselbe Format wie die Ereignisse
# des Debuggers, aufzeichnen.py), und mainloop kehrt sofort zurueck. Hat das Fenster Knoepfe, Eingabefelder oder
# Ereignisse (after, bind, protocol), wartet das Programm auf jemanden: dann das echte Fenster, wie bisher.
_DATEI = os.environ.get("LERNRAUM_FENSTER")
# Der Debugger (aufzeichnen.py) zeichnet selbst nach, was auf der Flaeche liegt -- er braucht keine Datei, aber auch kein
# echtes Fenster fuer ein Programm, das nur zeichnet (Durchsicht iq1 benutzen 13.11.: „Am Ende geht nochmal eine GUI
# und der Debugger auf, warum?“). LERNRAUM_FENSTER_STILL setzt ausfuehren.Lauf fuer ihn.
_STILL = os.environ.get("LERNRAUM_FENSTER_STILL")
# -- Das Fenster im Browser ist klickbar (16.11.2026) ------------------------------------------------------------------
# Durchsicht iq1 schach (W10, W12, W3): „Das Feld öffnet als GUI und nicht als Fenster im Browser, Absicht?“ · „In
# vielen Vorträgen öffnet sich eine GUI und immer mit dem gleichen Bild vom Brett“. Seit dem Neuschnitt wird ab `brett`
# am Brett geklickt -- und jedes Programm mit Klick bekam das echte Fenster. Jetzt: Ein Programm, das nur zeichnet UND
# auf einer Zeichenflaeche auf die linke Maustaste hoert (sonst auf nichts), bleibt unsichtbar am Leben. Die Seite
# schickt jeden Klick ueber den Server in LERNRAUM_FENSTER_KLICKS (je Zeile „nr x y“); hier wird er zu einem echten
# Tk-Ereignis, und danach steht die neue Zeichnung in LERNRAUM_FENSTER (mit "klickbar" und "stand" = Nummer des letzten
# Klicks). Der Server fasst die Klickdatei an, solange jemand zusieht; bleibt das aus (Seite zu, Server weg), geht das
# unsichtbare Fenster von selbst. Alles andere, was auf jemanden wartet -- Knoepfe, Eingabefelder, after, Tasten --,
# bekommt weiter das echte Fenster.
_KLICKS = os.environ.get("LERNRAUM_FENSTER_KLICKS")
_MAUS_LINKS = {"<Button-1>", "<ButtonPress-1>", "<1>", "<ButtonRelease-1>", "<B1-Motion>"}
try:                # Sekunden ohne Zuschauer, dann endet das unsichtbare Fenster (der Test stellt es kürzer)
    _PULS = float(os.environ.get("LERNRAUM_FENSTER_PULS") or 20)
except ValueError:
    _PULS = 20
if _tk is not None and (_DATEI or _STILL):
    import atexit
    import base64
    import json

    import time as _zeit

    _wurzeln = []
    _zustand = {"ereignisse": False, "geschrieben": False, "klicks": False, "stand": 0, "taub": False}
    _after = _tk.Misc.after                # die echten, bevor sie als „wartet auf jemanden“ zaehlen
    _bind_class = _tk.Misc.bind_class
    _ZEICHEN = {"rectangle": "rechteck", "oval": "oval", "line": "linie", "polygon": "vieleck",
                "text": "text", "image": "bild"}
    _NUR_ZEICHNEN = {"Tk", "Toplevel", "Canvas", "Frame"}

    def _versteckt(self, *a, **kw):
        _bauen(self, *a, **kw)
        try:
            self.withdraw()
        except _tk.TclError:
            pass
        _wurzeln.append(self)

    def _merkt(name):
        alt = getattr(_tk.Misc, name)

        def neu(self, *a, **kw):
            _zustand["ereignisse"] = True
            return alt(self, *a, **kw)
        setattr(_tk.Misc, name, neu)
    for _name in ("after", "bind_all", "bind_class"):
        _merkt(_name)
    _bind = _tk.Misc.bind

    def _bind_neu(self, sequence=None, func=None, add=None):
        # die linke Maustaste auf einer Zeichenflaeche: Das kann die Seite nachspielen. Alles andere wartet auf jemanden.
        try:
            flaeche = self.winfo_class() == "Canvas"
        except _tk.TclError:
            flaeche = False
        if _KLICKS and flaeche and func is not None and sequence in _MAUS_LINKS:
            _zustand["klicks"] = True
        else:
            _zustand["ereignisse"] = True
        return _bind(self, sequence, func, add)
    _tk.Misc.bind = _bind_neu
    _protokoll = _tk.Wm.wm_protocol

    def _protocol(self, name=None, func=None):
        # tkinter selbst setzt beim Bau jedes Tk WM_DELETE_WINDOW auf destroy -- das ist kein Ereignis der Klasse
        if func is not None and getattr(func, "__name__", "") != "destroy":
            _zustand["ereignisse"] = True
        return _protokoll(self, name, func)
    _tk.Wm.wm_protocol = _tk.Wm.protocol = _protocol

    def _alle(w):
        aus = [w]
        for k in w.winfo_children():
            aus += _alle(k)
        return aus

    def _nur_flaechen():
        for r in _wurzeln:
            try:
                for w in _alle(r):
                    if w.winfo_class() not in _NUR_ZEICHNEN:
                        return False
            except _tk.TclError:
                pass
        return True

    def _nur_zeichnen():
        return not _zustand["ereignisse"] and not _zustand["klicks"] and _nur_flaechen()

    def _klickbar():
        return bool(_KLICKS and _DATEI) and _zustand["klicks"] and not _zustand["ereignisse"] and _nur_flaechen()

    def _flaeche(c):
        def opt(i, k):
            try:
                return str(c.itemcget(i, k))
            except _tk.TclError:
                return ""
        dinge, bilder = [], {}
        for i in c.find_all():
            was = _ZEICHEN.get(c.type(i))
            if not was or opt(i, "state") == "hidden":
                continue
            d = {"was": was, "id": str(i), "k": [round(float(v), 1) for v in c.coords(i)]}
            if was in ("rechteck", "oval", "vieleck"):
                d.update(fill=opt(i, "fill"), outline=opt(i, "outline"), width=opt(i, "width"))
            elif was == "linie":
                # die Pfeilspitze (iq1 beziehung W1, 14.11.: „als Pfeil darstellen mit Pfeilspitze“)
                d.update(fill=opt(i, "fill"), width=opt(i, "width"), arrow=opt(i, "arrow"),
                         arrowshape=opt(i, "arrowshape"))
            elif was == "text":
                d.update(text=opt(i, "text"), fill=opt(i, "fill"), font=opt(i, "font"), anchor=opt(i, "anchor"))
            else:
                name = opt(i, "image")
                try:
                    datei = str(c.tk.call(name, "cget", "-file")) if name else ""
                    d.update(anchor=opt(i, "anchor"), datei=os.path.basename(datei),
                             breite=int(c.tk.call("image", "width", name)), hoehe=int(c.tk.call("image", "height", name)))
                except _tk.TclError:
                    continue
                if datei and d["datei"] not in bilder and os.path.isfile(datei) and os.path.getsize(datei) < 200000:
                    with open(datei, "rb") as f:
                        bilder[d["datei"]] = base64.b64encode(f.read()).decode("ascii")
            dinge.append(d)
        return {"b": int(float(c.cget("width"))), "h": int(float(c.cget("height"))), "bg": str(c.cget("bg")),
                "dinge": dinge}, bilder

    def _schreiben(lebt=False):
        """Die Zeichenflaechen in die Datei -- einmal (ein Programm, das nur zeichnet) oder nach jedem Klick (lebt)."""
        if not _DATEI or (_zustand["geschrieben"] and not lebt):
            return
        _zustand["geschrieben"] = True
        flaechen, bilder, titel = [], {}, ""
        for r in _wurzeln:
            try:
                for w in _alle(r):
                    if w.winfo_class() == "Canvas":
                        f, b = _flaeche(w)
                        flaechen.append(f)
                        bilder.update(b)
                titel = r.title()
            except _tk.TclError:
                continue
        if not flaechen:
            return
        daten = {"titel": titel, "flaechen": flaechen, "bilder": bilder}
        if lebt:
            daten.update(klickbar=True, stand=_zustand["stand"])
            if _zustand["taub"]:
                daten["taub"] = True
        try:
            # erst daneben schreiben, dann tauschen: Der Server liest, waehrend das Programm lebt
            with open(_DATEI + ".neu", "w", encoding="utf-8") as f:
                json.dump(daten, f)
            os.replace(_DATEI + ".neu", _DATEI)
        except OSError:
            pass

    _MARKE = "LernraumSeitenklick"
    _gesehen = []

    def _bedienen(self, n=0):
        """Das unsichtbare Fenster lebt: Klicks aus der Seite werden echte Tk-Ereignisse, danach steht die neue
        Zeichnung in der Datei. Tk stellt ein Ereignis nur einem Fenster zu, das es schon angelegt hat -- deshalb
        winfo_id() (gemessen am Klick des Selbstchecks, pruefen.klick_auf); kommt der Klick trotzdem nicht an, sagt
        die Datei das ("taub"), und die Seite oeffnet das echte Fenster."""
        flaechen = []
        for r in _wurzeln:
            try:
                flaechen += [w for w in _alle(r) if w.winfo_class() == "Canvas"]
            except _tk.TclError:
                pass
        for c in flaechen:
            try:
                c.winfo_id()
                c.bindtags((_MARKE,) + tuple(c.bindtags()))
            except _tk.TclError:
                pass
        try:
            _bind_class(self, _MARKE, "<Button-1>", lambda ereignis: _gesehen.append(1))
            self.update()
        except _tk.TclError:
            pass
        _schreiben(lebt=True)
        gelesen = [0]

        def takt():
            try:
                still = _zeit.time() - os.path.getmtime(_KLICKS)
            except OSError:
                still = _PULS + 1
            if still > _PULS:                 # niemand sieht mehr zu
                for r in list(_wurzeln):
                    try:
                        r.destroy()
                    except _tk.TclError:
                        pass
                return
            try:
                with open(_KLICKS, encoding="utf-8") as f:
                    text = f.read()
            except OSError:
                text = ""
            zeilen = text[:text.rfind("\n") + 1].splitlines()      # nur fertige Zeilen
            neu = zeilen[gelesen[0]:]
            gelesen[0] = len(zeilen)
            for zeile in neu:
                try:
                    nr, x, y = [int(v) for v in zeile.split()[:3]]
                except ValueError:
                    continue
                if flaechen:
                    del _gesehen[:]
                    try:
                        flaechen[0].event_generate("<Button-1>", x=x, y=y)
                        flaechen[0].event_generate("<ButtonRelease-1>", x=x, y=y)
                        self.update()
                    except _tk.TclError:
                        pass
                    if not _gesehen:
                        _zustand["taub"] = True
                _zustand["stand"] = nr
            if neu:
                _schreiben(lebt=True)
            try:
                _after(self, 30, takt)
            except _tk.TclError:
                pass
        _after(self, 30, takt)
        return _schleife(self, n)

    _schleife = _tk.Misc.mainloop

    def _mainloop(self, n=0):
        if _nur_zeichnen():
            _schreiben()
            return
        if _klickbar():                 # nur zeichnen und auf den Klick hoeren: Das Fenster lebt unsichtbar, die Seite klickt
            return _bedienen(self, n)
        for r in _wurzeln:              # Knoepfe, Eingaben, Ereignisse: das echte Fenster, nach vorn
            if os.environ.get("LERNRAUM_UNSICHTBAR"):
                break
            try:
                r.deiconify()
                r.attributes("-topmost", True)
                r.lift()
                _bauen_normal = r._lernraum_normal
                _tk.Misc.after(r, 400, _bauen_normal)
            except _tk.TclError:
                pass
        _zustand["geschrieben"] = True  # ein echtes Fenster: nichts in die Seite
        return _schleife(self, n)

    _tk.Tk.__init__ = _versteckt
    _tk.Misc.mainloop = _mainloop
    _tk._lernraum_nur_zeichnen = _nur_zeichnen     # fuer aufzeichnen.py: keine Meldung „Das Fenster steht“, kein Warten
    _tk.mainloop = lambda n=0: _mainloop(_wurzeln[0] if _wurzeln else _tk._default_root, n)
    atexit.register(_schreiben)
