"""Programme ausfuehren: ein Unterprozess mit demselben Python, das start.py
gestartet hat. Ausgabe wird gestreamt, ein Stopp beendet den Prozess, ein
Traceback wird in Zeile + deutschen Satz + Original zerlegt.

Kein Zeitlimit beim normalen Ausfuehren -- tkinter-Fenster laufen, bis man
sie schliesst (KONZEPT Block 6). Zeitlimits haben nur Selbstcheck und
Aufzeichnung.
"""
import os
import pathlib
import re
import subprocess
import sys
import threading
import time
import uuid

_LAEUFE = {}
_SPERRE = threading.Lock()

# Ein deutscher Satz je Fehlerart -- die Diagnose, nicht der Ausweg.
DEUTSCH = {
    "SyntaxError": "Python versteht diese Zeile nicht: Irgendwo fehlt oder stört ein Zeichen.",
    "IndentationError": "Die Einrückung stimmt nicht: Diese Zeile steht zu weit links oder rechts.",
    "NameError": "Ein Name wird benutzt, den Python hier nicht kennt – Tippfehler oder noch nicht angelegt.",
    "TypeError": "Zwei Dinge passen nicht zusammen – etwa Text und Zahl, oder ein Aufruf mit den falschen Angaben.",
    "ValueError": "Der Wert hat die richtige Art, aber den falschen Inhalt – etwa int() mit einem Text, der keine Zahl ist.",
    "IndexError": "Diesen Platz gibt es in der Liste nicht – die Plätze heißen 0 bis Anzahl minus 1.",
    "KeyError": "Diesen Schlüssel gibt es nicht.",
    "AttributeError": "Das Ding hat keine solche Eigenschaft oder Methode – Tippfehler oder falsche Art.",
    "ZeroDivisionError": "Durch null kann man nicht teilen.",
    "ModuleNotFoundError": "Diese Bibliothek gibt es hier nicht.",
    "ImportError": "Aus dieser Bibliothek lässt sich das nicht holen.",
    "RecursionError": "Eine Funktion ruft sich immer wieder selbst, ohne Ende.",
    "FileNotFoundError": "Diese Datei gibt es nicht.",
    "UnboundLocalError": "Der Name wird in der Funktion benutzt, bevor er dort einen Wert bekommt.",
    "KeyboardInterrupt": "Das Programm ist angehalten worden.",
}


def umgebung():
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def fehler_lesen(ausgabe, datei):
    """Traceback -> {"zeile": n, "art": ..., "satz": ..., "original": ...} oder None."""
    if "Traceback (most recent call last)" not in ausgabe and "Error" not in ausgabe:
        return None
    zeilen = ausgabe.rstrip().splitlines()
    original = ""
    art = ""
    for z in reversed(zeilen):
        m = re.match(r"^(\w+(?:Error|Exception|Interrupt|Warning))\b(.*)$", z.strip())
        if m:
            art, original = m.group(1), z.strip()
            break
    if not art:
        return None
    zeile = None
    name = pathlib.Path(datei).name
    ordner = pathlib.Path(datei).parent
    modul = None
    for z in zeilen:
        m = re.search(r'File "([^"]+)", line (\d+)', z)
        if m and pathlib.Path(m.group(1)).name == name:
            zeile = int(m.group(2))     # die LETZTE Stelle in der Arbeitsdatei
            modul = None
        elif m and pathlib.Path(m.group(1)).is_absolute() and pathlib.Path(m.group(1)).parent == ordner:
            # Python-Ordner (11.11.2026): die tiefste Stelle in einer ANDEREN Datei desselben Ordners -- der Fehler
            # steht in figur.py, nicht in der Zeile von partie.py, die die Methode ruft
            modul = {"datei": pathlib.Path(m.group(1)).name, "zeile": int(m.group(2))}
    aus = {"zeile": zeile, "art": art, "satz": DEUTSCH.get(art, "Das Programm ist mit einem Fehler abgebrochen."),
           "original": original}
    if modul:
        aus["modul"] = modul        # zeile bleibt die Stelle im Programm, das gestartet wurde (der Aufruf)
    return aus


TK_MARKE = "Exception in Tkinter callback"


def klickfehler_lesen(ausgabe, datei):
    """Fehler in Knopf-Funktionen (Teil III, 25.10.): tkinter faengt sie ab, druckt den Traceback hinter
    TK_MARKE und laesst das Fenster weiterlaufen -- das Programm endet nicht mit Fehler, fehler_lesen kaeme
    nie dran. Je vollstaendigem Block ein Fehler wie bei fehler_lesen, der Reihe nach."""
    if TK_MARKE not in ausgabe:
        return []
    aus = []
    for block in ausgabe.split(TK_MARKE)[1:]:
        f = fehler_lesen(block, datei)
        if f:
            aus.append(f)
    return aus


class Lauf:
    def __init__(self, datei, argumente=None, zeitlimit=None, modul=None, env_extra=None, echtes_fenster=False):
        self.id = uuid.uuid4().hex[:10]
        self.datei = pathlib.Path(datei)
        self.ausgabe = []          # Liste von Textstuecken
        self.weg = 0               # so viele Stuecke vorne sind schon verworfen (Endlosschleife, s. _anhaengen)
        self.zeichen = 0           # Zeichen, die noch in self.ausgabe stehen
        self._sperre = threading.Lock()
        self.begrenzt = modul is None   # der Debugger (modul=aufzeichnen.py) braucht jedes Ereignis, nichts gekuerzt
        self.fertig = False
        self.code = None
        self.gestoppt = False
        self.zeitlimit = zeitlimit
        self.fehlerbuch = None     # server.py: {thema, ort} -- dann zaehlt eine rote Meldung im Fehlerbuch
        self.start = time.time()
        befehl = [sys.executable, "-u"]
        if modul:
            befehl += modul
        befehl += [str(self.datei)] + list(argumente or [])
        env = umgebung()
        # vorne/sitecustomize.py holt jedes tk-Fenster vor den Browser (Probelauf 2, 28.10.)
        env["PYTHONPATH"] = os.pathsep.join(p for p in (str(pathlib.Path(__file__).parent / "vorne"),
                                                         env.get("PYTHONPATH")) if p)
        if env_extra:
            env.update(env_extra)
        # Fenster im Browser (13.11.2026): Ein Programm, das nur zeichnet, schreibt seine Zeichenflaechen in diese Datei
        # statt ein Fenster zu oeffnen (vorne/sitecustomize.py); der Bericht bringt sie mit. Nicht im Debugger (modul)
        # und nicht, wenn jemand ausdruecklich das echte Fenster will („als Fenster öffnen“).
        self.fensterdatei = None
        self._fenster = None
        # Das Fenster im Browser ist klickbar (16.11.2026, vorne/sitecustomize.py): Ein Programm, das nur zeichnet und
        # auf den Klick hoert, lebt unsichtbar weiter. klickdatei traegt die Klicks der Seite hinein (je Zeile „nr x
        # y“) und ist zugleich der Puls: Solange jemand den Lauf liest, wird sie angefasst.
        self.klickdatei = None
        self.klickbar = False
        self._fenster_zeit = None
        self._klicknr = 0
        self._klicksperre = threading.Lock()
        self._gelesen = time.time()
        self._puls = 0.0
        if modul is not None and not echtes_fenster:
            env["LERNRAUM_FENSTER_STILL"] = "1"      # der Debugger: kein echtes Fenster fuer ein Programm, das nur zeichnet
        if modul is None and not echtes_fenster:
            import tempfile
            fd, self.fensterdatei = tempfile.mkstemp(prefix="lernraum_fenster_", suffix=".json")
            os.close(fd)
            os.unlink(self.fensterdatei)
            env["LERNRAUM_FENSTER"] = self.fensterdatei
            self.klickdatei = self.fensterdatei[:-5] + "_klicks.txt"
            with open(self.klickdatei, "w", encoding="utf-8"):
                pass
            env["LERNRAUM_FENSTER_KLICKS"] = self.klickdatei
        self.prozess = subprocess.Popen(
            befehl, cwd=str(self.datei.parent), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE)
        threading.Thread(target=self._lesen, daemon=True).start()
        if self.klickdatei:
            threading.Thread(target=self._waechter, daemon=True).start()
        if zeitlimit:
            threading.Thread(target=self._wecker, daemon=True).start()

    def _lesen(self):
        # Stueckweise, wie es ankommt -- nicht zeilenweise: Die Eingabeaufforderung von input() („> “) hat kein
        # Zeilenende und blieb bis zur naechsten Zeile liegen; das Echo der Eingabe ueberholte sie (Code-Film, 21.10.).
        # Der schrittweise Dekoder zerreisst kein Zeichen, das auf zwei Stuecke faellt (Umlaute).
        import codecs
        dek = codecs.getincrementaldecoder("utf-8")("replace")
        with self.prozess.stdout:
            while True:
                roh = self.prozess.stdout.read1(65536)
                if not roh:
                    break
                text = dek.decode(roh)
                if text:
                    self._anhaengen(text)
            rest = dek.decode(b"", final=True)
            if rest:
                self._anhaengen(rest)
        self.code = self.prozess.wait()
        if self.klickbar:
            self._fenster_lesen()          # der letzte Stand, bevor die Dateien gehen
        self.fertig = True
        for datei in (self.klickdatei, (self.fensterdatei or "") + ".neu", self.fensterdatei if self.klickbar else None):
            try:
                if datei:
                    os.unlink(datei)
            except OSError:
                pass

    # Ein unsichtbares Fenster, dem niemand mehr zusieht, darf nicht ewig laufen: Liest die Seite den Lauf 30 s lang
    # nicht (Reiter zu, Thema gewechselt), endet er -- auch wenn das Programm in einer Endlosschleife haengt und seinen
    # eigenen Puls nicht mehr fuehlt.
    OHNE_ZUSCHAUER = 30

    def _waechter(self):
        while not self.fertig:
            if self.klickbar and time.time() - self._gelesen > self.OHNE_ZUSCHAUER:
                self.stopp(grund="niemand sieht zu")
                return
            time.sleep(1.0)

    def _fenster_lesen(self):
        """Die Zeichnung des lebenden Fensters, wenn sie neu ist. True, wenn sich etwas geaendert hat."""
        if not self.fensterdatei:
            return False
        try:
            zeit = os.stat(self.fensterdatei).st_mtime_ns
        except OSError:
            return False
        if zeit == self._fenster_zeit:
            return False
        try:
            import json
            with open(self.fensterdatei, encoding="utf-8") as f:
                daten = json.load(f)
        except (OSError, ValueError):
            return False
        self._fenster_zeit = zeit
        if not daten.get("klickbar"):
            return False                    # ein Programm, das nur zeichnet: Das liest bericht() am Ende
        self._fenster = daten
        self.klickbar = True
        return True

    def klick(self, x, y, warten=3.0):
        """Ein Klick der Seite auf die Zeichenflaeche. Wartet, bis das Programm ihn verarbeitet hat, und gibt die neue
        Zeichnung zurueck -- oder {"haengt": True}, wenn die Funktion hinter dem Klick nicht fertig wird."""
        if self.fertig or not self.klickbar:
            return {"ok": False}
        with self._klicksperre:
            self._klicknr += 1
            nr = self._klicknr
            try:
                with open(self.klickdatei, "a", encoding="utf-8") as f:
                    f.write("%d %d %d\n" % (nr, int(x), int(y)))
            except OSError:
                return {"ok": False}
        self._gelesen = time.time()
        ende = time.time() + warten
        while time.time() < ende and not self.fertig:
            self._fenster_lesen()
            if self._fenster and self._fenster.get("stand", 0) >= nr:
                return {"ok": True, "fenster": self._fenster}
            time.sleep(0.015)
        return {"ok": False, "haengt": not self.fertig}

    def _wecker(self):
        while not self.fertig:
            if time.time() - self.start > self.zeitlimit:
                self.stopp(grund="Zeitlimit")
                return
            time.sleep(0.2)

    def stopp(self, grund="Stopp"):
        if not self.fertig:
            self.gestoppt = grund
            try:
                self.prozess.terminate()
                try:
                    self.prozess.wait(timeout=1.5)
                except subprocess.TimeoutExpired:
                    self.prozess.kill()
            except OSError:
                pass

    def eingabe(self, text, echo=True):
        """Eine Zeile an stdin des Programms -- fuer input(). echo=False: der Debugger (die Aufzeichnung
        meldet die Eingabe selbst als Ereignis; ein rohes Echo stuende zwischen den JSON-Zeilen)."""
        if self.fertig:
            return False
        try:
            self.prozess.stdin.write((text + "\n").encode("utf-8"))
            self.prozess.stdin.flush()
            if echo:
                self._anhaengen(text + "\n")      # Echo, wie in einer Shell
            return True
        except (OSError, ValueError):
            return False

    # Eine Endlosschleife mit print (T10, „eine Zeile weg“) schreibt Megabytes in Sekunden: Der Server behaelt nur
    # das Ende (AUFHEBEN Zeichen), eine Antwort traegt hoechstens LESEN Zeichen -- sonst wuchs der Speicher ohne
    # Grenze, und die Seite fror ein, weil jede Abfrage alles seit der letzten mitbrachte (Messlauf 22.10.).
    AUFHEBEN = 400_000
    LESEN = 40_000

    def _anhaengen(self, text):
        with self._sperre:
            self.ausgabe.append(text)
            self.zeichen += len(text)
            while self.begrenzt and self.zeichen > self.AUFHEBEN and len(self.ausgabe) > 1:
                self.zeichen -= len(self.ausgabe.pop(0))
                self.weg += 1

    def text(self, ab=0):
        """Der Text ab Stueck ab (gezaehlt seit dem Start) und das Ende; zu viel auf einmal kommt gekuerzt, vorn ein
        Vermerk."""
        with self._sperre:
            von = max(ab - self.weg, 0)
            text = "".join(self.ausgabe[von:])
            bis = self.weg + len(self.ausgabe)
            luecke = ab < self.weg
        if self.begrenzt and len(text) > self.LESEN:
            text, luecke = text[-self.LESEN:], True
            if "\n" in text[:2000]:
                text = text[text.index("\n") + 1:]     # an einer Zeilengrenze anfangen
        if luecke:
            text = "\n… (so viel Ausgabe, dass nur das Ende zu sehen ist) …\n" + text
        return text, bis

    def bericht(self, ab=0, fenster_ab=None):
        """fenster_ab: der Stand der Zeichnung, den die Seite schon hat (Nummer des letzten Klicks) -- die Zeichnung
        eines lebenden Fensters reist nur mit, wenn sie neuer ist."""
        self._gelesen = time.time()
        if self.klickdatei and not self.fertig and self._gelesen - self._puls > 1.0:
            self._puls = self._gelesen
            try:
                os.utime(self.klickdatei)          # der Puls: Jemand sieht zu
            except OSError:
                pass
        text, bis = self.text(ab)
        aus = {"id": self.id, "text": text, "bis": bis, "fertig": self.fertig,
               "code": self.code, "gestoppt": self.gestoppt}
        if self.klickdatei and not self.fertig:
            self._fenster_lesen()
        if self.klickbar and self._fenster and (fenster_ab is None or self._fenster.get("stand", 0) > fenster_ab):
            aus["fenster"] = self._fenster
        if self.fertig and self.code not in (0, None):
            with self._sperre:
                alles = "".join(self.ausgabe)
            aus["fehler"] = fehler_lesen(alles, self.datei)
        if self.fertig and self.fensterdatei and not self.klickbar:
            if self._fenster is None:
                self._fenster = False
                try:
                    import json
                    with open(self.fensterdatei, encoding="utf-8") as f:
                        self._fenster = json.load(f)
                    os.unlink(self.fensterdatei)
                except (OSError, ValueError):
                    pass
            if self._fenster:
                aus["fenster"] = self._fenster
        if self.begrenzt:
            with self._sperre:
                alles = "".join(self.ausgabe)
            kf = klickfehler_lesen(alles, self.datei)
            if kf:
                aus["klickfehler"] = kf[-20:]
                aus["klickfehler_zahl"] = len(kf)
        return aus


def starten(datei, **kw):
    lauf = Lauf(datei, **kw)
    with _SPERRE:
        _LAEUFE[lauf.id] = lauf
        # alte, fertige Laeufe vergessen
        for k in [k for k, v in _LAEUFE.items() if v.fertig and time.time() - v.start > 600]:
            del _LAEUFE[k]
    return lauf


def holen(lauf_id):
    return _LAEUFE.get(lauf_id)


def alle_stoppen():
    for lauf in list(_LAEUFE.values()):
        lauf.stopp()


def einmal(befehl, cwd, zeitlimit, env_extra=None, isoliert=True):
    """Ein Unterprozess bis zum Ende, mit Zeitlimit -- fuer Selbstcheck und
    Nachlaufen. Gibt (code, text, zeit_ueberschritten)."""
    env = umgebung()
    if env_extra:
        env.update(env_extra)
    # -X utf8 auf der Befehlszeile (Probelauf 2, 28.10.): -I schaltet PYTHONUTF8/PYTHONIOENCODING aus der
    # Umgebung ab; unter Windows schrieb der Selbstcheck dann cp1252 und brach an „→“ mit UnicodeEncodeError ab.
    # -B ebenso (11.11.2026): -I schaltet auch PYTHONDONTWRITEBYTECODE ab -- der Selbstcheck eines Python-Ordners legte
    # sonst __pycache__/ neben die Dateien der Klasse (auf den Stick) und, beim Pruefen, in die Quelle des Themas
    voll = [sys.executable, "-X", "utf8", "-B"]
    if isoliert:
        voll.append("-I")
    voll += befehl
    try:
        p = subprocess.run(voll, cwd=str(cwd), env=env, capture_output=True,
                           timeout=zeitlimit, stdin=subprocess.DEVNULL)
        return p.returncode, (p.stdout + p.stderr).decode("utf-8", "replace"), False
    except subprocess.TimeoutExpired as e:
        text = ((e.stdout or b"") + (e.stderr or b"")).decode("utf-8", "replace")
        return None, text, True
