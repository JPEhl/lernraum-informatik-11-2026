"""Aktualisierung im laufenden Schuljahr (Lehrerentscheidung 2026-10-14, Weg B).

Eine Aktualisierung ist eine ZIP mit der ganzen gebauten Schuelerfassung und
ihrem Manifest (_system/manifest.json: je Datei SHA-256 und Art). Sie kommt
  * per Knopf: Python holt fassung.json von der festen Adresse des Kurses
    (inhalt.json "aktualisierung"), zeigt die Aenderungsliste, holt die ZIP
    und prueft ihre SHA-256 gegen fassung.json -- NUR auf Knopfdruck;
  * von Hand (ohne Netz): dieselbe ZIP ueber die Kursseite hereinnehmen.
Die Seite selbst geht nie ins Netz (CSP bleibt 'self').

Ersetzt wird, was der Kurs mitbringt: start.py, _system/ (Seite, Server,
Inhalt), Themeninhalte. BEWAHRT wird, was der Person gehoert: _stand/,
_anmerkungen/, abgaben/ (die Pfade sind in der ZIP verboten) und die
Arbeitsdateien (Art "arbeit": nur angelegt, wenn sie fehlen, nie ersetzt).

Sorgfalt, in dieser Reihenfolge:
  1. pruefen     jeder Name: relativ, ohne "..", ohne Backslash, kein Symlink,
                 nur erlaubte Ziele; Groessen begrenzt; Manifest == Inhalt der
                 ZIP, SHA-256 je Datei; Kurs gleich; Fassungsnummer GROESSER
  2. entpacken   nach _aktualisierung/neu/ (gleiches Laufwerk -> os.replace)
  3. sichern     was ersetzt oder entfernt wird -> _aktualisierung/alt/
  4. Protokoll   _aktualisierung/laeuft.json: was zurueck, was weg muss
  5. tauschen    Datei fuer Datei (os.replace); inhalt.json und Manifest zuletzt
  6. fertig      Protokoll weg, Verlauf fortschreiben
Scheitert 5, wird sofort zurueckgerollt. Stirbt der Prozess mittendrin, rollt
start.py beim naechsten Start mit demselben Protokoll zurueck -- kein halber
Stand. Das Format von laeuft.json ist darum fest: {"zurueck": [...], "weg": [...]}.
"""
import hashlib
import json
import re
import os
import pathlib
import posixpath
import shutil
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

MANIFEST = "_system/manifest.json"
ERLAUBT_DATEIEN = ("start.py", "SO_FAENGST_DU_AN.pdf")   # bis 25.10. die .md
ERLAUBT_ORDNER = ("_system/", "themen/")
VERBOTEN = ("_system/lehrer/",)
ARTEN = ("system", "inhalt", "arbeit")
# Grenzen (24.11.2026 angehoben fuer den Lernraum je Abiturjahrgang: Q1 und Q2 zusammen haben 2184 Dateien, ein
# Manifest von 334 KB und eine ZIP von 13 MB; die Q-Phase ganz etwa das Doppelte). Vorher 5000 Dateien, 80 MB entpackt,
# 40 MB ZIP, 256 KB Manifest -- das Manifest von iq1 allein stand schon bei 226 KB. Die ZIP bleibt unter den 100 MB,
# die GitHub je Datei annimmt. fassung.py erzeugen prueft dieselben Grenzen, bevor eine Fassung die Klasse erreicht.
GRENZE_ANZAHL = 20000
GRENZE_ENTPACKT = 300 * 1024 * 1024
GRENZE_ZIP = 90 * 1024 * 1024
GRENZE_JSON = 256 * 1024                   # fassung.json aus dem Netz
GRENZE_MANIFEST = 4 * 1024 * 1024
ARBEIT = "_aktualisierung"


class Abgelehnt(Exception):
    """Eine Aktualisierung, die nicht eingespielt wird -- der Text geht an die Seite."""


def sha256(daten):
    return hashlib.sha256(daten).hexdigest()


def name_pruefen(name):
    """Ein Name aus der ZIP -> derselbe Name, wenn er ein erlaubtes Ziel ist; sonst Abgelehnt.
    Zip-Slip: absolute Pfade, Laufwerke, '..', '.', Backslashes, leere Teile -- alles raus."""
    if not isinstance(name, str) or not name or "\\" in name or "\x00" in name:
        raise Abgelehnt("Unerlaubter Dateiname in der ZIP: %r" % name)
    if name.startswith("/") or (len(name) > 1 and name[1] == ":"):
        raise Abgelehnt("Absoluter Pfad in der ZIP: %s" % name)
    teile = name.split("/")
    if any(t in ("", ".", "..") for t in teile) or posixpath.normpath(name) != name:
        raise Abgelehnt("Pfad mit '..' oder Leerstelle in der ZIP: %s" % name)
    if name.startswith(VERBOTEN):
        raise Abgelehnt("Die ZIP will Lehrerdateien schreiben: %s" % name)
    if not (name in ERLAUBT_DATEIEN or name.startswith(ERLAUBT_ORDNER) or INFO_MUSTER.match(name)):
        raise Abgelehnt("Die ZIP will etwas ausserhalb von Seite und Themen schreiben: %s" % name)
    return name


# die Info-Datei im Lernraum, an deren Namen man den Kurs sieht („Kurs - Informatik Q-Phase - Abitur 2028.txt“, 24.11.2026)
INFO_MUSTER = re.compile(r"^Kurs - [A-Za-z0-9 .,()-]+\.txt$")


def ordner_in_zip(z):
    """Seit 24.11.2026 steht der Lernraum in der ZIP in EINEM Ordner („Lernraum Informatik Q-Phase/“) -- nach dem
    Entpacken liegt dann der Ordner da, den die Anleitung nennt. Gibt diesen Ordner mit „/“ zurueck, oder "" fuer eine
    ZIP ohne Ordner (die bisherige Form, sie gilt weiter)."""
    namen = z.namelist()
    if MANIFEST in namen:
        return ""
    # der Ordner, in dem das Manifest liegt (genau einer) -- liegt daneben noch etwas, lehnt pruefen() es ab
    ordner = {n[:-len(MANIFEST)] for n in namen if n.endswith("/" + MANIFEST) and n.count("/") == MANIFEST.count("/") + 1}
    return ordner.pop() if len(ordner) == 1 else ""


def ist_symlink(info):
    return (info.external_attr >> 16) & 0o170000 == 0o120000


def inhalt_lesen(wurzel):
    try:
        return json.loads((pathlib.Path(wurzel) / "_system" / "inhalt.json").read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def manifest_lesen(wurzel):
    try:
        return json.loads((pathlib.Path(wurzel) / MANIFEST).read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def _still(stufe, jetzt, von):
    pass


# -- Stick gezogen (P5, Lehrer 23.11.2026: „Idealerweise sollte dann nichts kaputt gehen“) -----------------------
# Ein USB-Stick (FAT/exFAT) hat kein Journal: Was nur im Zwischenspeicher des Rechners liegt, ist weg, wenn der Stick
# gezogen wird. Deshalb wird alles, was ein Zuruecknehmen braucht (neu/, alt/, laeuft.json), auf den Stick gezwungen
# (fsync), BEVOR die erste Datei getauscht wird -- und laeuft.json ist entweder ganz da oder gar nicht.
def _fest(pfad):
    """Eine geschriebene Datei auf den Datentraeger zwingen."""
    with open(pfad, "rb+") as f:
        os.fsync(f.fileno())


def _ordner_fest(ordner):
    """Den Ordnereintrag hinterher (POSIX; unter Windows laesst sich ein Ordner nicht oeffnen -- dort reicht der
    Dateiinhalt, und „Schnelles Entfernen“ schreibt ohnehin durch)."""
    try:
        fd = os.open(str(ordner), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _json_fest(ziel, daten):
    """JSON ganz oder gar nicht: daneben schreiben, fest, ersetzen, Ordner fest."""
    ziel = pathlib.Path(ziel)
    tmp = ziel.with_name(ziel.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(json.dumps(daten, ensure_ascii=False, indent=1))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, ziel)
    _ordner_fest(ziel.parent)


def pruefen(wurzel, zip_pfad, erwartet_sha=None, melden=_still):
    """Prueft eine Aktualisierungs-ZIP gegen diesen Lernraum und gibt den Plan
    zurueck -- schreibt NICHTS. Jede Unstimmigkeit ist ein Abgelehnt.
    melden(stufe, jetzt, von): der Fortschritt fuer die Ladeanzeige (P4, 24.11.2026) -- „pruefen“, Datei fuer Datei."""
    wurzel = pathlib.Path(wurzel)
    zip_pfad = pathlib.Path(zip_pfad)
    if zip_pfad.stat().st_size > GRENZE_ZIP:
        raise Abgelehnt("Die ZIP ist zu gross (%d MB)." % (zip_pfad.stat().st_size // 2**20))
    if erwartet_sha and sha256(zip_pfad.read_bytes()) != erwartet_sha:
        raise Abgelehnt("Die Pruefsumme der ZIP stimmt nicht mit fassung.json ueberein -- "
                        "unvollstaendig geladen oder veraendert. Nichts eingespielt.")
    try:
        z = zipfile.ZipFile(zip_pfad)
    except zipfile.BadZipFile:
        raise Abgelehnt("Das ist keine ZIP-Datei.")
    with z:
        infos = z.infolist()
        vor = ordner_in_zip(z)
        # Ein Stand statt einer Fassung (16.11.2026): gleich sagen, wohin er gehoert -- sonst meldete die Namenspruefung
        # unten „will etwas ausserhalb von Seite und Themen schreiben: stand.json“
        if not vor and MANIFEST not in z.namelist() and "stand.json" in z.namelist():
            raise Abgelehnt("Das ist ein Stand, keine neue Fassung. Stände nimmt das Zahnrad oben rechts: „Stand hereinnehmen“.")
        if len(infos) > GRENZE_ANZAHL:
            raise Abgelehnt("Zu viele Dateien in der ZIP.")
        namen, summe = set(), 0
        for i in infos:
            name = i.filename
            if vor:
                if name == vor:
                    continue
                if not name.startswith(vor):
                    raise Abgelehnt("Die ZIP enthaelt mehr als den Ordner des Lernraums: %s" % name)
                name = name[len(vor):]
            if ist_symlink(i):
                raise Abgelehnt("Die ZIP enthaelt eine Verknuepfung (Symlink): %s" % i.filename)
            if name.endswith("/"):
                name_pruefen(name.rstrip("/"))
                continue
            name_pruefen(name)
            if name in namen:
                raise Abgelehnt("Datei doppelt in der ZIP: %s" % name)
            namen.add(name)
            summe += i.file_size
            if summe > GRENZE_ENTPACKT:
                raise Abgelehnt("Die ZIP waere entpackt zu gross.")
        if MANIFEST not in namen:
            raise Abgelehnt("Das ist keine neue Fassung des Lernraums – gebraucht wird die ZIP des Lernraums, so wie sie ausgeteilt wurde (nicht entpackt und neu gepackt).")
        if z.getinfo(vor + MANIFEST).file_size > GRENZE_MANIFEST:
            raise Abgelehnt("Manifest zu gross.")
        try:
            m = json.loads(z.read(vor + MANIFEST).decode("utf-8"))
        except ValueError:
            raise Abgelehnt("Das Manifest ist unlesbar.")
        hier = inhalt_lesen(wurzel)
        if m.get("kurs") != hier.get("kurs"):
            raise Abgelehnt("Diese Aktualisierung gehoert zu einem anderen Kurs (%s, hier %s)." % (m.get("kurs"), hier.get("kurs")))
        try:
            nr, alt_nr = int(m.get("fassung_nr")), int(hier.get("fassung_nr") or 0)
        except (TypeError, ValueError):
            raise Abgelehnt("Die Fassungsnummer im Manifest ist keine Zahl.")
        if nr == alt_nr:
            raise Abgelehnt("Fassung %d ist schon da -- nichts zu tun." % nr)
        if nr < alt_nr:
            raise Abgelehnt("Fassung %d ist aelter als die hier (Fassung %d) -- zurueck geht es nie." % (nr, alt_nr))
        dateien = m.get("dateien")
        if not isinstance(dateien, dict) or set(dateien) != namen - {MANIFEST}:
            fehlt = sorted(set(dateien or {}) ^ (namen - {MANIFEST}))[:3]
            raise Abgelehnt("Manifest und ZIP passen nicht zusammen (%s)." % ", ".join(fehlt))
        melden("pruefen", 0, len(dateien))
        for n, (rel, d) in enumerate(dateien.items(), 1):
            melden("pruefen", n, len(dateien))
            if d.get("art") not in ARTEN or (d["art"] == "arbeit" and not rel.startswith("themen/")):
                raise Abgelehnt("Unbekannte Art im Manifest: %s" % rel)
            if sha256(z.read(vor + rel)) != d.get("sha256"):
                raise Abgelehnt("Datei veraendert oder beschaedigt: %s" % rel)
    # -- der Plan: was ersetzt, neu angelegt, bewahrt, entfernt wird -------------
    plan = {"nr": nr, "alt_nr": alt_nr, "datum": m.get("fassung_datum", ""), "aenderungen": list(m.get("aenderungen") or []),
            "ersetzen": [], "neu": [], "arbeit_neu": [], "arbeit_bewahrt": [], "entfernen": [],
            "themen_neu": [t for t in (m.get("themen") or {}) if t not in (manifest_lesen(wurzel).get("themen") or {})],
            "themen": m.get("themen") or {}}
    for rel, d in sorted(dateien.items()):
        da = (wurzel / rel).is_file()
        if d["art"] == "arbeit":
            plan["arbeit_bewahrt" if da else "arbeit_neu"].append(rel)
        else:
            plan["ersetzen" if da else "neu"].append(rel)
    alt = manifest_lesen(wurzel).get("dateien") or {}
    for rel, d in sorted(alt.items()):
        if rel in dateien or d.get("art") == "arbeit":
            continue
        try:
            name_pruefen(rel)
        except Abgelehnt:
            continue
        if (wurzel / rel).is_file():
            plan["entfernen"].append(rel)
    return plan


def zusammenfassung(plan):
    """Fuer die Seite: Zahlen statt Dateilisten, dazu die Aenderungsliste."""
    return {"nr": plan["nr"], "alt_nr": plan["alt_nr"], "datum": plan["datum"], "aenderungen": plan["aenderungen"],
            "themen_neu": [plan["themen"].get(t, t) for t in plan["themen_neu"]],
            "zahlen": {k: len(plan[k]) for k in ("ersetzen", "neu", "entfernen", "arbeit_neu", "arbeit_bewahrt")}}


# -- Zurueckrollen: dieselbe Logik steht in start.py (laeuft, bevor kursserver geladen ist) --
def zurueckrollen(wurzel):
    """Gibt True zurueck, wenn ein abgebrochener Tausch zurueckgerollt wurde."""
    wurzel = pathlib.Path(wurzel)
    a = wurzel / ARBEIT
    j = a / "laeuft.json"
    (a / "laeuft.json.tmp").unlink(missing_ok=True)     # ein halb geschriebenes Protokoll: der Tausch begann nie
    if not j.exists():
        return False
    try:
        p = json.loads(j.read_text("utf-8"))
        if not isinstance(p, dict):
            raise ValueError
    except (OSError, ValueError):
        # unlesbar (seit P5 kann das nur ein Protokoll alter Art sein): alles aus alt/ zurueck -- war der Tausch nie
        # begonnen, sind das dieselben Dateien wie jetzt; begann er, ist es der alte Stand
        alt_o = a / "alt"
        p = {"zurueck": [q.relative_to(alt_o).as_posix() for q in alt_o.rglob("*") if q.is_file()] if alt_o.is_dir() else [],
             "weg": []}
    for rel in p.get("weg", []):
        z = wurzel / rel
        if z.is_file():
            z.unlink()
    for rel in p.get("zurueck", []):
        q = a / "alt" / rel
        if q.is_file():
            (wurzel / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(q, wurzel / rel)
            _fest(wurzel / rel)
    j.unlink()
    shutil.rmtree(a / "neu", ignore_errors=True)
    shutil.rmtree(a / "alt", ignore_errors=True)
    return True


def einspielen(wurzel, zip_pfad, erwartet_sha=None, _scheitern_nach=None, melden=_still):
    """Prueft, entpackt, sichert, tauscht. Gibt den Bericht zurueck oder wirft
    Abgelehnt -- dann ist der Lernraum wie vorher. _scheitern_nach: nur fuer
    den Test (wirft nach so vielen Tauschschritten). melden: „pruefen“, dann „einspielen“ als „Datei n von m“ (m =
    die Dateien, die geschrieben werden; Entpacken, Sichern und Tauschen zusammen auf diese Zahl umgerechnet)."""
    wurzel = pathlib.Path(wurzel)
    zurueckrollen(wurzel)                      # ein alter Abbruch zuerst
    plan = pruefen(wurzel, zip_pfad, erwartet_sha, melden)
    a = wurzel / ARBEIT
    shutil.rmtree(a / "neu", ignore_errors=True)
    shutil.rmtree(a / "alt", ignore_errors=True)
    (a / "neu").mkdir(parents=True)
    (a / "alt").mkdir(parents=True)
    schreiben = plan["ersetzen"] + plan["neu"] + plan["arbeit_neu"]
    # inhalt.json und Manifest zuletzt: die Fassungsnummer kippt erst, wenn alles andere da ist
    letzte = [r for r in ("_system/inhalt.json",) if r in schreiben]
    schreiben = [r for r in schreiben if r not in letzte] + letzte + [MANIFEST]
    vorher = [r for r in schreiben if (wurzel / r).is_file()]
    gesamt, getan = 2 * len(schreiben) + len(vorher) + 2 * len(plan["entfernen"]), [0]

    def weiter():
        getan[0] += 1
        melden("einspielen", min(len(schreiben), round(getan[0] * len(schreiben) / max(gesamt, 1))), len(schreiben))
    melden("einspielen", 0, len(schreiben))
    with zipfile.ZipFile(zip_pfad) as z:
        vor = ordner_in_zip(z)
        m = json.loads(z.read(vor + MANIFEST).decode("utf-8"))
        for rel in schreiben:
            daten = z.read(vor + rel)
            if rel != MANIFEST and sha256(daten) != m["dateien"][rel]["sha256"]:
                raise Abgelehnt("Datei beim Entpacken veraendert: %s" % rel)
            ziel = a / "neu" / rel
            ziel.parent.mkdir(parents=True, exist_ok=True)
            with open(ziel, "wb") as f:
                f.write(daten)
                f.flush()
                os.fsync(f.fileno())
            weiter()
    for rel in vorher + plan["entfernen"]:
        ziel = a / "alt" / rel
        ziel.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(wurzel / rel, ziel)
        _fest(ziel)
        weiter()
    for o in (a / "neu", a / "alt"):
        _ordner_fest(o)
    protokoll = {"nr": plan["nr"], "alt_nr": plan["alt_nr"], "zeit": time.strftime("%Y-%m-%dT%H:%M:%S"),
                 "zurueck": vorher + plan["entfernen"], "weg": [r for r in schreiben if r not in vorher]}
    _json_fest(a / "laeuft.json", protokoll)     # erst jetzt beginnt der Tausch -- alles fuers Zurueck steht fest
    schritte = 0
    try:
        for rel in plan["entfernen"]:
            (wurzel / rel).unlink()
            weiter()
            schritte += 1
            if _scheitern_nach is not None and schritte >= _scheitern_nach:
                raise OSError("Testabbruch")
        for rel in schreiben:
            ziel = wurzel / rel
            ziel.parent.mkdir(parents=True, exist_ok=True)
            os.replace(a / "neu" / rel, ziel)
            weiter()
            schritte += 1
            if _scheitern_nach is not None and schritte >= _scheitern_nach:
                raise OSError("Testabbruch")
    except OSError as e:
        zurueckrollen(wurzel)
        raise Abgelehnt("Beim Tauschen ging etwas schief (%s) -- alles ist zurueckgerollt, der Lernraum ist wie vorher." % e)
    verlauf = a / "verlauf.json"
    try:
        alt = json.loads(verlauf.read_text("utf-8")) if verlauf.exists() else []
    except ValueError:
        alt = []
    alt.append({"von": plan["alt_nr"], "auf": plan["nr"], "zeit": protokoll["zeit"], "zahlen": zusammenfassung(plan)["zahlen"]})
    _json_fest(verlauf, alt)
    # die getauschten Dateien fest, bevor das Protokoll faellt -- sonst stuende ohne Protokoll ein halber Tausch da
    for rel in schreiben:
        try:
            _fest(wurzel / rel)
        except OSError:
            pass
    if hasattr(os, "sync"):
        os.sync()
    (a / "laeuft.json").unlink()
    _ordner_fest(a)
    shutil.rmtree(a / "neu", ignore_errors=True)
    shutil.rmtree(a / "alt", ignore_errors=True)
    melden("fertig", len(schreiben), len(schreiben))
    return zusammenfassung(plan)


# -- Netz (nur auf Knopfdruck) -------------------------------------------------------
def _adresse_pruefen(adresse):
    u = urllib.parse.urlsplit(adresse)
    if u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost")):
        return adresse
    raise Abgelehnt("Die Adresse der Aktualisierung muss mit https:// beginnen: %s" % adresse)


def _laden(adresse, grenze, zeit=15, melden=_still, gesamt=0):
    """In Bloecken lesen (P4, 24.11.2026): melden("laden", Bytes, Bytes gesamt) nach jedem Block -- gesamt aus
    Content-Length, sonst die Groesse aus fassung.json."""
    req = urllib.request.Request(_adresse_pruefen(adresse), headers={"User-Agent": "Lernraum-Aktualisierung/1", "Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=zeit, context=ssl.create_default_context()) as r:
            try:
                gesamt = int(r.headers.get("Content-Length") or 0) or gesamt
            except ValueError:
                pass
            teile, n = [], 0
            melden("laden", 0, gesamt)
            while n <= grenze:
                b = r.read(256 * 1024)
                if not b:
                    break
                teile.append(b)
                n += len(b)
                melden("laden", n, max(gesamt, n))
            daten = b"".join(teile)
    except urllib.error.HTTPError as e:
        raise Abgelehnt("Der Server antwortet mit %d (%s)." % (e.code, adresse))
    except (urllib.error.URLError, OSError) as e:
        grund = getattr(e, "reason", e)
        raise Abgelehnt("Keine Verbindung (%s). Ohne Netz geht es von Hand: die Aktualisierungs-ZIP "
                        "über „Von Hand hereinnehmen“ wählen." % grund)
    if len(daten) > grenze:
        raise Abgelehnt("Antwort zu gross: %s" % adresse)
    return daten


def suchen(adresse, inhalt):
    """fassung.json holen und lesen -- schreibt nichts."""
    try:
        f = json.loads(_laden(adresse, GRENZE_JSON).decode("utf-8"))
    except ValueError:
        raise Abgelehnt("fassung.json ist unlesbar.")
    if f.get("kurs") != inhalt.get("kurs"):
        raise Abgelehnt("Unter dieser Adresse liegt ein anderer Kurs (%s)." % f.get("kurs"))
    try:
        nr = int(f["nr"])
    except (KeyError, TypeError, ValueError):
        raise Abgelehnt("fassung.json nennt keine Fassungsnummer.")
    if not isinstance(f.get("sha256"), str) or not isinstance(f.get("zip"), str):
        raise Abgelehnt("fassung.json nennt keine ZIP mit Pruefsumme.")
    return {"nr": nr, "datum": str(f.get("datum", "")), "aenderungen": [str(x) for x in f.get("aenderungen") or []][:60],
            "zip": f["zip"], "sha256": f["sha256"], "groesse": int(f.get("groesse") or 0),
            "neu": nr > int(inhalt.get("fassung_nr") or 0)}


def holen(adresse, info, ziel, melden=_still):
    """Die ZIP neben fassung.json holen und gegen deren Pruefsumme pruefen."""
    url = urllib.parse.urljoin(adresse, urllib.parse.quote(info["zip"]))     # „Lernraum Informatik Q-Phase.zip“: Leerzeichen
    daten = _laden(url, GRENZE_ZIP, zeit=90, melden=melden, gesamt=int(info.get("groesse") or 0))
    if sha256(daten) != info["sha256"]:
        raise Abgelehnt("Die geholte ZIP passt nicht zur Pruefsumme in fassung.json -- nichts eingespielt. Spaeter noch einmal versuchen.")
    ziel = pathlib.Path(ziel)
    ziel.parent.mkdir(parents=True, exist_ok=True)
    ziel.write_bytes(daten)
    return ziel
