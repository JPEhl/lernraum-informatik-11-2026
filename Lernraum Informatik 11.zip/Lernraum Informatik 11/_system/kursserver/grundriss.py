"""grundriss -- die Probe der Werkstatt „Grundriss“ (i11 projekt/verabredung, 18.11.2026).

Fragt EINEN Raum so, wie das Spiel ihn fragt, und sagt je Stecker der Verabredung, ob er passt -- und wenn nicht,
woran es hängt:

    name · beschreibung() · befehle() · antwort(befehl, rucksack)

Aufruf (so ruft es der Server, im Unterprozess wie den Selbstcheck, isoliert, mit Zeitlimit von außen):

    python -I grundriss.py <raum.py> --json

Ausgabe: eine Zeile „@@GRUNDRISS@@{…}“ mit

    datei     der Dateiname
    leer      true, wenn in der Datei nur Kommentare stehen (noch nichts eingesteckt)
    kopf      die erste Kommentarzeile hinter „--“ („der Raum von Farida und Malte“)
    laden     null -- oder der Satz, warum sich der Raum nicht einstecken lässt (Abbruch, input(), Anzeige beim import)
    name      der Wert von name, wenn es ein Text ist
    stecker   vier Einträge {stecker, ok, grund}; ok ist true, false oder null (nicht geprüft, weil das Laden scheitert)
    rundgang  nur wenn alles passt: {beschreibung, schritte: [[befehl, antwort], …], rucksack}

Die Probe bewertet nichts und schreibt nichts. Was der Raum innen tut, sieht sie nur von außen: Sie ruft seine
Funktionen mit eigenen Werten, fängt ab, was er in der Shell anzeigen würde, und liest den Quelltext nur für print,
input und global (dieselben Regeln wie der Selbstcheck des Themas, pruefung.py `_raum_befunde`). Den Namen prüft sie
auf seine Form -- ob ihn ein anderer Raum schon trägt, weiß nur die Werkstatt, die alle Räume sieht.
"""
import ast
import builtins
import importlib.util
import inspect
import io
import json
import pathlib
import re
import sys
import time
import traceback

MARKE = "@@GRUNDRISS@@"
ZEITGRENZE = 3.0
UNBEKANNT = "tanze im kreis"
FUELLWORT = "hallo"
STECKER = ("name", "beschreibung()", "befehle()", "antwort(befehl, rucksack)")
VOLL = ["lampe", "seil", "apfel", "kreide", "stick", "karte"]


class _ZuLang(BaseException):
    pass


class _KeinInput(BaseException):
    pass


def _kein_input(*_):
    raise _KeinInput()


def _mit_zeitgrenze(fn):
    ende = time.monotonic() + ZEITGRENZE
    zaehler = [0]

    def spur(frame, ereignis, arg):
        zaehler[0] += 1
        if zaehler[0] % 1000 == 0 and time.monotonic() > ende:
            raise _ZuLang()
        return spur
    alt = sys.gettrace()
    sys.settrace(spur)
    try:
        return fn()
    finally:
        sys.settrace(alt)


def _kurz(text, laenge=60):
    text = " ".join(str(text).split())
    return text if len(text) <= laenge else text[:laenge - 1] + "…"


def _zeile(e, pfad):
    """Die Zeile im Raum, an der der Fehler entstand (die letzte Stelle des Tracebacks in der Datei des Raums)."""
    for rahmen in reversed(traceback.extract_tb(e.__traceback__)):
        try:
            if pathlib.Path(rahmen.filename).resolve() == pfad:
                return rahmen.lineno
        except (OSError, ValueError):
            continue
    return getattr(e, "lineno", None) if isinstance(e, SyntaxError) else None


def _abbruch(e, pfad):
    if isinstance(e, _ZuLang):
        return "läuft endlos weiter"
    z = _zeile(e, pfad)
    return "bricht ab: %s: %s%s" % (type(e).__name__, _kurz(e, 70), " (Zeile %d)" % z if z else "")


def _still(fn):
    """fn() mit abgefangener Shell und ohne input(). Gibt (wert, gezeigt, fehler) -- fehler ist eine Ausnahme oder None."""
    puffer, vorher, eingabe = io.StringIO(), sys.stdout, builtins.input
    sys.stdout, builtins.input = puffer, _kein_input
    try:
        return _mit_zeitgrenze(fn), puffer.getvalue(), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        return None, puffer.getvalue(), e
    finally:
        sys.stdout, builtins.input = vorher, eingabe


def laden(pfad):
    """Den Raum frisch als Modul laden. Gibt (modul, gezeigt, fehler)."""
    spec = importlib.util.spec_from_file_location("_raum_%s_%d" % (pfad.stem, time.monotonic_ns()), str(pfad))
    modul = importlib.util.module_from_spec(spec)
    _, gezeigt, fehler = _still(lambda: spec.loader.exec_module(modul))
    return modul, gezeigt, fehler


def _verbotenes(baum):
    """print/input je Funktion (None = außerhalb jeder Funktion) und ob global vorkommt."""
    funde, mit_global = {}, False
    for f in [None] + [k for k in baum.body if isinstance(k, (ast.FunctionDef, ast.AsyncFunctionDef))]:
        knoten = [k for k in baum.body if not isinstance(k, (ast.FunctionDef, ast.AsyncFunctionDef))] if f is None else [f]
        for k0 in knoten:
            for k in ast.walk(k0):
                if isinstance(k, ast.Global):
                    mit_global = True
                if isinstance(k, ast.Call) and isinstance(k.func, ast.Name) and k.func.id in ("print", "input"):
                    funde.setdefault(f.name if f else None, set()).add(k.func.id)
    return funde, mit_global


def _probe(befehl):
    """Ein Befehl aus befehle() zum Ausprobieren: <satz> und Ähnliches wird ein Wort."""
    return re.sub(r"<[^>]*>", FUELLWORT, str(befehl)).strip()


def _gezeigt_satz(was, gezeigt):
    return "%s zeigt etwas in der Shell an („%s“) -- verabredet ist: zurückgeben, nicht anzeigen." % (was, _kurz(gezeigt.strip().splitlines()[0], 40))


def stecker_name(m):
    if not hasattr(m, "name"):
        return False, "In der Datei steht kein name = \"…\" -- so heißt der Raum im Spiel."
    name = m.name
    if not isinstance(name, str) or not name:
        return False, "name ist %r -- verabredet ist ein Text: der Raum, wie er im Spiel heißt." % (name,)
    if not re.fullmatch(r"[a-zäöüß]+", name):
        return False, "name = %r: klein und ein Wort, sonst findet geh den Raum nicht." % name
    return True, ""


def _ohne_angaben(m, fn, verbot, pfad):
    """beschreibung() und befehle(): ohne Angaben rufen. Gibt (ok, grund, wert)."""
    f = getattr(m, fn, None)
    if not callable(f):
        return False, "Es gibt keine Funktion %s() -- das Spiel ruft sie%s." % (fn, " beim Hereinkommen" if fn == "beschreibung" else " vor jeder Eingabe"), None
    try:
        pflicht = [p for p in inspect.signature(f).parameters.values() if p.default is p.empty and p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)]
    except (TypeError, ValueError):
        pflicht = []
    if pflicht:
        return False, "%s(%s) erwartet etwas in der Klammer -- das Spiel ruft %s() ohne Angaben." % (fn, ", ".join(p.name for p in pflicht), fn), None
    wert, gezeigt, fehler = _still(f)
    if isinstance(fehler, _KeinInput):
        return False, "%s() fragt mit input() -- ein Raum fragt nie." % fn, None
    if fehler is not None:
        return False, "%s() %s." % (fn, _abbruch(fehler, pfad)), None
    if gezeigt:
        return False, _gezeigt_satz("%s()" % fn, gezeigt) + (" Zurück kommt %r." % (wert,) if wert is None else ""), wert
    if fn == "beschreibung" and (not isinstance(wert, str) or not wert.strip()):
        return False, "beschreibung() gibt %r zurück -- verabredet ist ein Satz." % (wert,), wert
    if fn == "befehle":
        if not isinstance(wert, list) or not wert or not all(isinstance(b, str) and b.strip() for b in wert):
            return False, "befehle() gibt %r zurück -- verabredet ist eine Liste von Befehlen, mindestens einer." % (_kurz(repr(wert), 50),), wert
    if verbot.get(fn):
        return False, "In %s() steht %s -- verabredet ist: zurückgeben, nicht anzeigen und nicht fragen." % (fn, " und ".join(sorted(verbot[fn]))), wert
    return True, "", wert


def stecker_antwort(m, pfad, befehle, verbot, mit_global):
    f = getattr(m, "antwort", None)
    if not callable(f):
        andere = []
        for n, g in vars(m).items():
            if inspect.isfunction(g) and n not in ("beschreibung", "befehle") and not n.startswith("_"):
                try:
                    if len(inspect.signature(g).parameters) == 2:
                        andere.append("%s(%s)" % (n, ", ".join(inspect.signature(g).parameters)))
                except (TypeError, ValueError):
                    pass
        if andere:
            return False, "Es gibt keine Funktion antwort -- nur %s. Das Spiel ruft antwort." % andere[0]
        return False, "Es gibt keine Funktion antwort(befehl, rucksack) -- das Spiel ruft sie bei jeder Eingabe."
    try:
        para = list(inspect.signature(f).parameters)
    except (TypeError, ValueError):
        para = []
    if len(para) != 2:
        return False, "antwort(%s) hat %d Angabe%s in der Klammer -- verabredet sind zwei: erst der Befehl, dann der Rucksack." % (", ".join(para), len(para), "" if len(para) == 1 else "n")
    if "ruck" in para[0].lower() or "befehl" in para[1].lower() or "eingabe" in para[1].lower():
        return False, "Die Klammer ist vertauscht: antwort(%s, %s) -- verabredet ist erst der Befehl, dann der Rucksack." % tuple(para)
    saetze = []
    for b in [UNBEKANNT] + [_probe(x) for x in befehle]:
        wert, gezeigt, fehler = _still(lambda: f(b, ["lampe"]))
        if isinstance(fehler, _KeinInput):
            return False, "Auf „%s“ fragt antwort mit input() -- ein Raum fragt nie, er bekommt den Befehl." % b
        if fehler is not None:
            return False, "Auf „%s“ %s." % (b, _abbruch(fehler, pfad))
        if gezeigt:
            return False, "Auf „%s“ " % b + _gezeigt_satz("antwort", gezeigt).replace("antwort zeigt", "zeigt antwort", 1)
        if not isinstance(wert, str) or not wert.strip():
            return False, "Auf „%s“ gibt antwort %r zurück -- verabredet ist ein Satz, für jeden Befehl%s." % (b, wert, ", auch einen, den der Raum nicht kennt" if b == UNBEKANNT else "")
        saetze.append(wert)
    # versteht der Raum keinen seiner eigenen Befehle, kommt der Befehl nicht an (die Klammer vertauscht, ohne dass die
    # Namen es verraten) -- befehle() nennt, was der Raum versteht
    if len(saetze) > 1 and all(x == saetze[0] for x in saetze[1:]):
        return False, ("Auf jeden Befehl aus befehle() antwortet der Raum wie auf einen, den er nicht kennt (%s) -- kommt "
                       "der Befehl an der Stelle in der Klammer an, an der das Spiel ihn schickt?" % _kurz(saetze[0], 40))
    if mit_global:
        return False, "In der Datei steht global -- ein Raum ändert nur den Rucksack, nicht das Spiel."
    for wo, was in verbot.items():
        if wo not in (None, "beschreibung", "befehle"):
            return False, "In %s steht %s -- verabredet ist: zurückgeben, nicht anzeigen und nicht fragen." % (wo, " und ".join(sorted(was)))
    # die Grenze: ein frischer Raum, ein voller Rucksack, jeder Befehl zweimal
    m2, _, fehler = laden(pfad)
    if fehler is None and callable(getattr(m2, "antwort", None)):
        rucksack = list(VOLL)
        for b in [_probe(x) for x in befehle] * 2:
            _still(lambda: m2.antwort(b, rucksack))
            if len(rucksack) > 6:
                return False, "Mit sechs Dingen im Rucksack legt „%s“ noch etwas hinein -- verabredet sind höchstens sechs." % b
    return True, ""


def rundgang(pfad, befehle):
    m, _, fehler = laden(pfad)
    if fehler is not None:
        return None
    satz, _, _ = _still(m.beschreibung)
    rucksack, schritte = ["lampe"], []
    # erst die Befehle ohne Platzhalter (nimm, pfeife …), dann die mit (sprich <satz> -> sprich hallo)
    for b in [_probe(x) for x in sorted(befehle, key=lambda x: "<" in x)][:5]:
        wert, _, _ = _still(lambda: m.antwort(b, rucksack))
        schritte.append([b, str(wert)])
    return {"beschreibung": str(satz), "schritte": schritte, "rucksack": list(rucksack)}


def kopf_lesen(text):
    """Wer den Raum gebaut hat, aus dem Kopfkommentar: „# aula.py -- der Raum von Kofi und Jule, …“ -> „der Raum von
    Kofi und Jule“ (der Kommentar oben, hinter dem ersten „--“, bis zum ersten Satzzeichen)."""
    zeilen = []
    for z in text.splitlines():
        z = z.strip()
        if not z.startswith("#"):
            break
        zeilen.append(z.lstrip("#").strip())
    teile = " ".join(zeilen).split("--", 1)
    if len(teile) < 2:
        return ""
    return _kurz(re.split(r"[.,:;]", teile[1].strip(), 1)[0].strip(), 60)


def pruefen(pfad):
    pfad = pathlib.Path(pfad).resolve()
    text = pfad.read_text("utf-8", errors="replace")
    aus = {"datei": pfad.name, "leer": not any(z.strip() and not z.strip().startswith("#") for z in text.splitlines()),
           "kopf": kopf_lesen(text), "laden": None, "name": None,
           "stecker": [{"stecker": s, "ok": None, "grund": ""} for s in STECKER], "rundgang": None}
    if aus["leer"]:
        return aus
    try:
        baum = ast.parse(text)
    except SyntaxError as e:
        aus["laden"] = "Der Raum lässt sich nicht einstecken: Python versteht Zeile %s nicht (%s)." % (e.lineno, _kurz(e.msg, 50))
        return aus
    verbot, mit_global = _verbotenes(baum)
    sys.path.insert(0, str(pfad.parent))
    m, gezeigt, fehler = laden(pfad)
    if isinstance(fehler, _KeinInput):
        aus["laden"] = "Der Raum lässt sich nicht einstecken: Er fragt beim import mit input() -- ein Raum fragt nie."
        return aus
    if fehler is not None:
        aus["laden"] = "Der Raum lässt sich nicht einstecken: Beim import %s." % _abbruch(fehler, pfad)
        return aus
    if isinstance(getattr(m, "name", None), str):
        aus["name"] = m.name
    if gezeigt:
        aus["laden"] = ("Beim import zeigt der Raum etwas in der Shell an („%s“) -- außerhalb der Funktionen stehen nur "
                        "Startwerte, keine Probe und kein print." % _kurz(gezeigt.strip().splitlines()[0], 40))
    ergebnisse = [stecker_name(m)]
    ok_b, grund_b, _ = _ohne_angaben(m, "beschreibung", verbot, pfad)
    ok_c, grund_c, befehle = _ohne_angaben(m, "befehle", verbot, pfad)
    ergebnisse += [(ok_b, grund_b), (ok_c, grund_c)]
    liste = befehle if isinstance(befehle, list) else []
    ergebnisse.append(stecker_antwort(m, pfad, [b for b in liste if isinstance(b, str)], verbot, mit_global))
    for eintrag, (ok, grund) in zip(aus["stecker"], ergebnisse):
        eintrag.update(ok=bool(ok), grund=grund)
    if not aus["laden"] and all(e["ok"] for e in aus["stecker"]):
        aus["rundgang"] = rundgang(pfad, liste)
    return aus


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("Aufruf: grundriss.py <raum.py> [--json]")
    ergebnis = pruefen(sys.argv[1])
    if "--json" in sys.argv:
        sys.stdout.write("\n" + MARKE + json.dumps(ergebnis, ensure_ascii=False) + "\n")
    else:
        print(json.dumps(ergebnis, ensure_ascii=False, indent=1))
