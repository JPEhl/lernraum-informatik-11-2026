"""Relationenalgebra fuer den Kursserver -- der zweite Laeufer neben relalg.js (Aufgabenart „Term“, iq2 fall, 19.11.2026).

Die Werkstatt Daten rechnet Terme im Browser mit werkstatt/_scripts/datenwerkstatt/relalg.js (Tisch relalg). Was eine
Aufgabe ist, weiss aber nur der Server (Pruefstoff, verschleiert) -- er prueft den Term der Klasse und rechnet im Pult
die Sterne nach. Darum dieselbe Rechnung hier in Python, nur mit der Standardbibliothek (laeuft auf dem Stick):
lesen (Abiturnotation, [ ] oder _{ }, Druckform, Woerter sigma/pi/join/kreuz), Bedingungen, Uebersetzen nach SQL
(Spalten c0, c1, … mit Herkunft), Ausfuehren mit Deckel, Vergleichen als Menge nach Attributnamen. Titel und Texte der
Meldungen sind WORTGLEICH mit relalg.js; test/relalg_gleichlauf.py haelt beide Laeufer gleich (LR6).

Die Datenbasen: fall.sqlite und auszug.json, die bauen.py nach _system/seite/werkstatt/daten/ legt. basen(ordner)
oeffnet beide (die ganze Datenbank nur lesend, der Auszug im Speicher) und merkt sie sich je Ordner.
"""
import html
import json
import pathlib
import re
import sqlite3


class RAFehler(Exception):
    def __init__(self, titel, text):
        super().__init__(titel)
        self.titel, self.text = titel, text


_ID = re.compile(r"[A-Za-zÄÖÜäöüß_][A-Za-z0-9ÄÖÜäöüß_]*")


def esc(s):
    return html.escape(str(s), quote=True).replace("&#x27;", "'")


def code(w):
    return "<code>" + esc(w) + "</code>"


def _q(n):
    return '"' + str(n).replace('"', '""') + '"'


def normalisieren(s):
    """iPad und Mac setzen gern typografische Anfuehrungszeichen -- die meinen dasselbe wie '."""
    return re.sub(r"[„“”]", '"', re.sub(r"[‘’‚‛′`´]", "'", str(s)))


_WOERTER = {"sigma": "σ", "pi": "π", "join": "⋈", "kreuz": "×", "cross": "×"}


# ── Lesen ───────────────────────────────────────────────────────────────────────────────────────────────────────────
#  Baum: {art:"tab", name} · {art:"sel", bed, kind} · {art:"proj", attrs, kind} · {art:"join", l, r} · {art:"kreuz", l, r}

def lesen(eingabe):
    s = normalisieren(eingabe)
    i = 0

    def leer():
        nonlocal i
        while i < len(s) and s[i].isspace():
            i += 1

    def rest():
        return s[i:i + 25].strip()

    def kurz_vor():
        return " (kurz vor %s)" % code(rest()) if rest() else " (am Ende)"

    def zeichen():
        leer()
        if i < len(s) and s[i] in "σπ⋈×":
            return s[i]
        m = _ID.match(s, i)
        if m and m.group(0).lower() in _WOERTER:
            return _WOERTER[m.group(0).lower()]
        return None

    def zeichen_nehmen():
        nonlocal i
        leer()
        if s[i] in "σπ⋈×":
            i += 1
            return
        i += len(_ID.match(s, i).group(0))

    def index(muss_klammerform):
        nonlocal i
        leer()
        auf = zu = None
        if i < len(s) and s[i] == "[":
            auf, zu = "[", "]"
            i += 1
        elif s[i:i + 2] == "_{":
            auf, zu = "{", "}"
            i += 2
        elif i < len(s) and s[i] == "_":
            i += 1
        if zu:
            start, tiefe, im_text = i, 0, False
            while i < len(s):
                c = s[i]
                if c == "'":
                    im_text = not im_text
                elif not im_text and c == auf:
                    tiefe += 1
                elif not im_text and c == zu:
                    if tiefe == 0:
                        break
                    tiefe -= 1
                i += 1
            if i >= len(s):
                raise RAFehler("Klammer nicht geschlossen",
                               "Die %s nach dem Zeichen wird nicht wieder geschlossen. Bedingung bzw. Attribute stehen zwischen %s."
                               % (code("[" if auf == "[" else "_{"), code("[ ]" if auf == "[" else "_{ }")))
            inhalt = s[start:i]
            i += 1
            return inhalt
        if muss_klammerform:
            return None
        start, im_text = i, False
        while i < len(s):
            if s[i] == "'":
                im_text = not im_text
            elif not im_text and s[i] == "(":
                break
            i += 1
        inhalt = s[start:i]
        return inhalt if inhalt.strip() else None

    def primaer():
        nonlocal i
        leer()
        z = zeichen()
        if z in ("σ", "π"):
            zeichen_nehmen()
            idx = index(False)
            if idx is None or not idx.strip():
                if z == "σ":
                    raise RAFehler("Hinter σ fehlt die Bedingung", "σ braucht eine Bedingung, zum Beispiel " + code("σ[Farbe = 'rot'](Fahrzeug)") + ".")
                raise RAFehler("Hinter π fehlen die Attribute", "π braucht die Attribute, die stehen bleiben, zum Beispiel " + code("π[Kennzeichen, PersNr](Fahrzeug)") + ".")
            leer()
            if i >= len(s):
                raise RAFehler("Es fehlt, worauf " + z + " wirkt",
                               "Hinter %s muss in Klammern stehen, worauf es angewendet wird, zum Beispiel %s."
                               % (code(z + "[" + idx.strip() + "]"), code("(Fahrzeug)")))
            kind = primaer()
            if z == "σ":
                return {"art": "sel", "bed": idx.strip(), "kind": kind}
            attrs = [a.strip() for a in idx.split(",")]
            if any(not a for a in attrs):
                raise RAFehler("Ein Attribut fehlt", "In %s steht ein Komma zu viel oder eins fehlt." % code("π[" + idx.strip() + "]"))
            return {"art": "proj", "attrs": attrs, "kind": kind}
        if z in ("⋈", "×"):
            raise RAFehler("Links fehlt etwas", "Vor %s muss eine Tabelle oder ein Term stehen%s." % (code(z), kurz_vor()))
        if i < len(s) and s[i] == "(":
            i += 1
            t = term()
            leer()
            if i >= len(s) or s[i] != ")":
                raise RAFehler("Klammer nicht geschlossen", "Eine %s wird nicht wieder geschlossen%s." % (code("("), kurz_vor()))
            i += 1
            return t
        m = _ID.match(s, i)
        if m:
            i += len(m.group(0))
            return {"art": "tab", "name": m.group(0)}
        if i >= len(s):
            raise RAFehler("Der Term hört zu früh auf", "Am Ende fehlt noch eine Tabelle oder ein Term in Klammern.")
        raise RAFehler("Das Zeichen passt hier nicht", "Mit %s kann die Werkstatt hier nichts anfangen%s." % (code(s[i]), kurz_vor()))

    def term():
        links = primaer()
        while True:
            leer()
            z = zeichen()
            if z not in ("⋈", "×"):
                break
            zeichen_nehmen()
            if z == "⋈":
                leer()
                if (i < len(s) and s[i] == "[") or s[i:i + 2] == "_{":
                    raise RAFehler("⋈ steht ohne Bedingung",
                                   "%s verbindet die Zeilen, die in den Attributen mit <b>gleichem Namen</b> übereinstimmen — "
                                   "so steht es im Abitur, ohne Bedingung daran. Soll nach einer anderen Bedingung verbunden werden: %s."
                                   % (code("⋈"), code("σ[Bedingung](A × B)")))
            leer()
            if i >= len(s):
                raise RAFehler("Rechts fehlt etwas", "Hinter %s muss eine zweite Tabelle oder ein Term stehen." % code(z))
            rechts = primaer()
            links = {"art": "kreuz" if z == "×" else "join", "l": links, "r": rechts}
        return links

    leer()
    if i >= len(s):
        raise RAFehler("Noch kein Term", "Gebt einen Term ein, zum Beispiel " + code("σ[Farbe = 'rot'](Fahrzeug)") + ".")
    baum = term()
    leer()
    if i < len(s):
        if s[i] == ")":
            raise RAFehler("Eine Klammer zu viel", "Hier wird eine %s geschlossen, die nie geöffnet wurde%s." % (code(")"), kurz_vor()))
        raise RAFehler("Hier geht es nicht weiter", "Nach dem Term steht noch etwas%s. Fehlt ein %s oder ein %s dazwischen?" % (kurz_vor(), code("⋈"), code("×")))
    return baum


# ── Bedingungen ────────────────────────────────────────────────────────────────────────────────────────────────────

_VERGL = {"=": "=", "<>": "<>", "!=": "<>", "≠": "<>", "<": "<", ">": ">", "<=": "<=", ">=": ">=", "≤": "<=", "≥": ">="}
_ZAHL = re.compile(r"-?\d+(?:[.,]\d+)?")


def _bed_tokens(bed):
    t, i, s = [], 0, bed
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
            continue
        if c == "'":
            j, w = i + 1, ""
            while True:
                if j >= len(s):
                    raise RAFehler("Anführungszeichen nicht geschlossen", "Ein Text ist mit %s geöffnet, aber nicht wieder geschlossen: %s." % (code("'"), code(s[i:])))
                if s[j] == "'" and s[j + 1:j + 2] == "'":
                    w += "'"
                    j += 2
                    continue
                if s[j] == "'":
                    break
                w += s[j]
                j += 1
            t.append({"a": "text", "w": w})
            i = j + 1
            continue
        if c == '"':
            raise RAFehler("Doppelte Anführungszeichen", "Texte stehen in <b>einfachen</b> Anführungszeichen: %s, nicht %s." % (code("'rot'"), code('"rot"')))
        zwei = s[i:i + 2]
        if zwei in ("<>", "!=", "<=", ">="):
            t.append({"a": "op", "w": zwei})
            i += 2
            continue
        if c in "=<>≠≤≥":
            t.append({"a": "op", "w": c})
            i += 1
            continue
        if c == "∧":
            t.append({"a": "und"}); i += 1; continue
        if c == "∨":
            t.append({"a": "oder"}); i += 1; continue
        if c == "¬":
            t.append({"a": "nicht"}); i += 1; continue
        if c in "()":
            t.append({"a": c}); i += 1; continue
        z = _ZAHL.match(s, i)
        if z and not re.match(r"[A-Za-zÄÖÜäöüß_]", s[i + len(z.group(0)):i + len(z.group(0)) + 1]):
            w = float(z.group(0).replace(",", "."))
            t.append({"a": "zahl", "w": int(w) if w == int(w) else w})
            i += len(z.group(0))
            continue
        m = _ID.match(s, i)
        if m:
            w = m.group(0)
            i += len(w)
            if s[i:i + 1] == ".":
                m2 = _ID.match(s, i + 1)
                if m2:
                    w += "." + m2.group(0)
                    i += 1 + len(m2.group(0))
            g = w.upper()
            if g in ("AND", "UND"):
                t.append({"a": "und"})
            elif g in ("OR", "ODER"):
                t.append({"a": "oder"})
            elif g in ("NOT", "NICHT"):
                t.append({"a": "nicht"})
            elif g == "LIKE":
                raise RAFehler("LIKE gibt es in der Relationenalgebra nicht",
                               "In einer Bedingung der Relationenalgebra wird nur verglichen: " + code("=") + ", " + code("<") + ", " + code(">")
                               + " … Textmuster wie „fängt mit WI an“ kommen mit SQL.")
            else:
                t.append({"a": "name", "w": w})
            continue
        raise RAFehler("Das Zeichen passt nicht in die Bedingung", "Mit %s in %s kann die Werkstatt nichts anfangen." % (code(c), code(bed)))
    return t


def _zahl_sql(w):
    return str(w)


def _bed_sql(bed, aufloesen):
    t = _bed_tokens(bed)
    k = 0
    ganz = code(bed)

    def wo():
        return "" if k < len(t) else " am Ende"

    def operand():
        nonlocal k
        x = t[k] if k < len(t) else None
        if not x:
            raise RAFehler("Die Bedingung hört zu früh auf", "In %s fehlt hinter dem Vergleich noch ein Wert." % ganz)
        if x["a"] == "text":
            k += 1
            return "'" + x["w"].replace("'", "''") + "'"
        if x["a"] == "zahl":
            k += 1
            return _zahl_sql(x["w"])
        if x["a"] == "name":
            k += 1
            return aufloesen(x["w"], True)
        raise RAFehler("Hier fehlt ein Attribut oder ein Wert", "In %s steht an einer Stelle kein Attribut und kein Wert%s." % (ganz, wo()))

    def vergleich():
        nonlocal k
        if k < len(t) and t[k]["a"] == "(":
            k += 1
            e = oder()
            if k >= len(t) or t[k]["a"] != ")":
                raise RAFehler("Klammer nicht geschlossen", "In %s wird eine %s nicht wieder geschlossen." % (ganz, code("(")))
            k += 1
            return "(" + e + ")"
        a = operand()
        op = t[k] if k < len(t) else None
        if not op or op["a"] != "op":
            raise RAFehler("Hier fehlt der Vergleich", "In %s steht ein Attribut ohne Vergleich. Eine Bedingung vergleicht, zum Beispiel %s." % (ganz, code("Farbe = 'rot'")))
        k += 1
        b = operand()
        return a + " " + _VERGL[op["w"]] + " " + b

    def nicht():
        nonlocal k
        if k < len(t) and t[k]["a"] == "nicht":
            k += 1
            return "NOT " + nicht()
        return vergleich()

    def und():
        nonlocal k
        e = nicht()
        while k < len(t) and t[k]["a"] == "und":
            k += 1
            e += " AND " + nicht()
        return e

    def oder():
        nonlocal k
        e = und()
        while k < len(t) and t[k]["a"] == "oder":
            k += 1
            e += " OR " + und()
        return e

    if not t:
        raise RAFehler("Die Bedingung ist leer", "Zwischen den Klammern steht keine Bedingung.")
    e = oder()
    if k < len(t):
        x = t[k]
        raise RAFehler("Zwei Vergleiche ohne AND oder OR",
                       "In %s stehen Vergleiche nebeneinander. Verbindet sie mit %s oder %s" % (ganz, code("AND"), code("OR"))
                       + (" (vor %s)." % code(x["w"]) if x["a"] == "name" else "."))
    return e


# ── Uebersetzen ────────────────────────────────────────────────────────────────────────────────────────────────────

def _werte(db, sql):
    return db.execute(sql).fetchall()


def _zeilenzahl(db, tab):
    return _werte(db, "SELECT COUNT(*) FROM " + _q(tab))[0][0]


def _spalten(db, tab):
    return [z[1] for z in _werte(db, "PRAGMA table_info(%s)" % _q(tab))]


def _tabellen(db):
    return [z[0] for z in _werte(db, "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY rowid")]


def _aehnlich(wort, kandidaten):
    best, bestd = None, 99
    for k in kandidaten:
        a, b = wort.lower(), k.lower()
        d = [[i] + [0] * len(b) for i in range(len(a) + 1)]
        for j in range(1, len(b) + 1):
            d[0][j] = j
        for i in range(1, len(a) + 1):
            for j in range(1, len(b) + 1):
                d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (0 if a[i - 1] == b[j - 1] else 1))
        if d[len(a)][len(b)] < bestd:
            best, bestd = k, d[len(a)][len(b)]
    return best if bestd <= max(2, len(wort) // 3) else None


GRENZE_DISTINCT = 2e7


def _tausend(n):
    r = (str(round(n / 1e9)) + " Milliarden") if n >= 1e9 else (str(round(n / 1e6)) + " Millionen") if n >= 1e6 else str(int(n))
    return re.sub(r"\B(?=(\d{3})+(?!\d))", " ", r)


def uebersetzen(db, baum, protokoll=None):
    tabs = _tabellen(db)
    zaehler = [0]

    def neu():
        zaehler[0] += 1
        return "q%d" % (zaehler[0] - 1)

    def aufloeser(schema, basis, wo):
        def aufloesen(ref, in_bed):
            t, a = ref.split(".", 1) if "." in ref else (None, ref)
            treffer = [(s, k) for k, s in enumerate(schema) if s["name"].lower() == a.lower() and (not t or s["tab"].lower() == t.lower())]
            if len(treffer) == 1:
                return "c%d" % treffer[0][1]
            if len(treffer) > 1:
                raise RAFehler("Welches Attribut ist gemeint?",
                               "%s gibt es hier mehrmals. Schreibt die Tabelle davor: " % code(a) + " oder ".join(code(s["tab"] + "." + s["name"]) for s, _ in treffer) + ".")
            vorhanden = [s["name"] for s in schema]
            frueher = next((b for b in basis if b["name"].lower() == a.lower()), None)
            if frueher:
                raise RAFehler("%s gibt es hier nicht mehr" % a,
                               "%s steht in %s, aber ein %s weiter innen hat es nicht übernommen. %s kann nur mit dem arbeiten, was noch da ist: "
                               % (code(a), code(frueher["tab"]), code("π"), wo) + ", ".join(code(x) for x in vorhanden) + ".")
            if in_bed and not t:
                raise RAFehler("Attribut oder Text?",
                               "Ein Attribut %s gibt es hier nicht. Ist %s ein <b>Wert</b>? Dann gehört er in einfache Anführungszeichen: %s. Vorhanden: "
                               % (code(a), code(a), code("'" + a + "'")) + ", ".join(code(x) for x in vorhanden) + ".")
            v = _aehnlich(a, vorhanden)
            raise RAFehler("Dieses Attribut gibt es hier nicht",
                           "Ein Attribut %s gibt es hier nicht." % code(ref) + (" Meint ihr %s?" % code(v) if v else "")
                           + " Vorhanden: " + ", ".join(code(x) for x in vorhanden) + ".")
        return aufloesen

    def knoten(b):
        e = knoten_roh(b)
        if protokoll is not None:
            protokoll[id(b)] = e
        return e

    def knoten_roh(b):
        if b["art"] == "tab":
            echt = next((t for t in tabs if t.lower() == b["name"].lower()), None)
            if not echt:
                v = _aehnlich(b["name"], tabs)
                raise RAFehler("Diese Tabelle gibt es nicht", "Eine Tabelle %s kennt die Datenbank nicht." % code(b["name"])
                               + (" Meint ihr %s?" % code(v) if v else "") + " Vorhanden: " + ", ".join(code(x) for x in tabs) + ".")
            sp = _spalten(db, echt)
            schema = [{"tab": echt, "name": n} for n in sp]
            return {"sql": "SELECT %s FROM %s" % (", ".join("%s AS c%d" % (_q(x), k) for k, x in enumerate(sp)), _q(echt)),
                    "schema": schema, "basis": list(schema), "schaetz": _zeilenzahl(db, echt), "hinweise": [], "produkt": None}
        if b["art"] == "sel":
            k, a = knoten(b["kind"]), neu()
            bed = _bed_sql(b["bed"], aufloeser(k["schema"], k["basis"], code("σ")))
            verbindet = bool(re.search(r"c\d+ = c\d+", bed))
            sel = re.sub(r"\bc(\d+)\b", lambda m: "%s.c%s" % (a, m.group(1)), bed)
            return dict(k, sql="SELECT * FROM (%s) AS %s WHERE %s" % (k["sql"], a, sel),
                        schaetz=k["produkt"] if verbindet and k.get("produkt") else k["schaetz"], produkt=None)
        if b["art"] == "proj":
            k, a = knoten(b["kind"]), neu()
            auf = aufloeser(k["schema"], k["basis"], code("π"))
            idx = [int(auf(x, False)[1:]) for x in b["attrs"]]
            doppelt = next((x for j, x in enumerate(idx) if idx.index(x) != j), None)
            if doppelt is not None:
                raise RAFehler("Ein Attribut steht zweimal", "%s steht in %s doppelt." % (code(k["schema"][doppelt]["name"]), code("π")))
            if k["schaetz"] > GRENZE_DISTINCT:
                raise RAFehler("Das wird zu groß",
                               "Unter diesem %s stünden rund %s Zeilen — jede mit jeder. Das rechnet auch ein Computer nicht in Ruhe durch. Fehlt ein %s mit Bedingung statt %s?"
                               % (code("π"), _tausend(k["schaetz"]), code("⋈"), code("×")))
            return dict(k, sql="SELECT DISTINCT %s FROM (%s) AS %s" % (", ".join("%s.c%d AS c%d" % (a, x, j) for j, x in enumerate(idx)), k["sql"], a),
                        schema=[k["schema"][x] for x in idx], produkt=None)
        l, r, al, ar = knoten(b["l"]), knoten(b["r"]), None, None
        al, ar = neu(), neu()
        versatz = len(l["schema"])
        alle = l["schema"] + r["schema"]
        basis = l["basis"] + r["basis"]
        hinweise = l["hinweise"] + r["hinweise"]

        def spalten_sql(schema, links):
            return ["%s.c%d AS c%d" % (al if links else ar, k, k if links else k + versatz) for k in range(len(schema))]
        if b["art"] == "kreuz":
            return {"sql": "SELECT %s FROM (%s) AS %s, (%s) AS %s" % (", ".join(spalten_sql(l["schema"], True) + spalten_sql(r["schema"], False)), l["sql"], al, r["sql"], ar),
                    "schema": alle, "basis": basis, "hinweise": hinweise, "schaetz": l["schaetz"] * r["schaetz"], "produkt": max(l["schaetz"], r["schaetz"])}
        paare = []
        for kr, s in enumerate(r["schema"]):
            kl = [k for k, x in enumerate(l["schema"]) if x["name"].lower() == s["name"].lower()]
            if len(kl) > 1:
                raise RAFehler("Welches Attribut verbindet?",
                               "%s steht links mehrmals (aus einem %s). %s weiß nicht, über welches verbunden werden soll. Deckt vorher mit %s ab, was nicht gebraucht wird."
                               % (code(s["name"]), code("×"), code("⋈"), code("π")))
            if len(kl) == 1:
                paare.append((kl[0], kr))
        if not paare:
            hinweise.append("Die beiden Seiten von %s haben kein Attribut mit demselben Namen. Dann verbindet %s jede Zeile mit jeder, wie %s."
                            % (code("⋈"), code("⋈"), code("×")))
            return {"sql": "SELECT %s FROM (%s) AS %s, (%s) AS %s" % (", ".join(spalten_sql(l["schema"], True) + spalten_sql(r["schema"], False)), l["sql"], al, r["sql"], ar),
                    "schema": alle, "basis": basis, "hinweise": hinweise, "schaetz": l["schaetz"] * r["schaetz"], "produkt": max(l["schaetz"], r["schaetz"])}
        if len(paare) > 1:
            hinweise.append("%s verbindet hier über %d Attribute mit gleichem Namen: " % (code("⋈"), len(paare))
                            + " und ".join(code(r["schema"][kr]["name"]) for _, kr in paare)
                            + ". Eine Zeile findet nur einen Partner, wenn <b>alle</b> übereinstimmen.")
        weg = {kr for _, kr in paare}
        rechts = [(s, k) for k, s in enumerate(r["schema"]) if k not in weg]
        schema = l["schema"] + [s for s, _ in rechts]
        sel = ["%s.c%d AS c%d" % (al, k, k) for k in range(len(l["schema"]))] + ["%s.c%d AS c%d" % (ar, k, versatz + j) for j, (_, k) in enumerate(rechts)]
        return {"sql": "SELECT %s FROM (%s) AS %s, (%s) AS %s WHERE %s" % (", ".join(sel), l["sql"], al, r["sql"], ar,
                                                                          " AND ".join("%s.c%d = %s.c%d" % (al, a, ar, c) for a, c in paare)),
                "schema": schema, "basis": basis, "hinweise": hinweise, "schaetz": max(l["schaetz"], r["schaetz"]), "produkt": None}
    return knoten(baum)


def kopf(schema):
    """Spaltennamen fuer die Anzeige: das Attribut, bei Doppelten Tabelle.Attribut."""
    return [s["tab"] + "." + s["name"] if sum(1 for x in schema if x["name"].lower() == s["name"].lower()) > 1 else s["name"] for s in schema]


def sql(db, eingabe):
    k = uebersetzen(db, lesen(eingabe))
    return {"sql": "SELECT * FROM (%s)" % k["sql"], "kopf": kopf(k["schema"]), "hinweise": k["hinweise"]}


def ausfuehren(db, eingabe, zeigen=200, zaehlen=100000):
    u = sql(db, eingabe)
    zeilen, anzahl = [], 0
    for z in db.execute(u["sql"]):
        if len(zeilen) < zeigen:
            zeilen.append(list(z))
        anzahl += 1
        if anzahl >= zaehlen:
            break
    return {"spalten": u["kopf"], "zeilen": zeilen, "anzahl": anzahl, "mehr": anzahl >= zaehlen, "hinweise": u["hinweise"]}


def alle(db, eingabe):
    return ausfuehren(db, eingabe, zeigen=100001, zaehlen=100001)


# ── Pruefen ────────────────────────────────────────────────────────────────────────────────────────────────────────

def _norm(w):
    if w is None:
        return "NULL"
    if isinstance(w, bool):
        w = int(w)
    if isinstance(w, (int, float)):
        r = round(float(w), 6)
        return str(int(r)) if r == int(r) else repr(r)
    return re.sub(r"\s+", " ", str(w).strip()).lower()


def _zeile(z):
    return json.dumps([_norm(w) for w in z], ensure_ascii=False)


def _nach_namen(ist, soll):
    n = lambda x: x.lower().split(".")[-1]
    if len(ist["spalten"]) != len(soll["spalten"]):
        return None
    pos = []
    for s in soll["spalten"]:
        exakt = next((k for k, x in enumerate(ist["spalten"]) if x.lower() == s.lower()), -1)
        pos.append(exakt if exakt >= 0 else next((k for k, x in enumerate(ist["spalten"]) if n(x) == n(s)), -1))
    if any(p < 0 for p in pos) or len(set(pos)) != len(pos):
        return None
    return {"spalten": soll["spalten"], "zeilen": [[z[p] for p in pos] for z in ist["zeilen"]]}


def vergleichen(ist, soll, zeige_fehlende=True):
    """{ok, text, zeile?, spalten?} -- nach Attributnamen und als Menge, wie raVergleichen in relalg.js."""
    if len(ist["spalten"]) != len(soll["spalten"]):
        n = len(ist["spalten"])
        return {"ok": False, "text": "Euer Ergebnis hat %d Attribut%s, gesucht %s." % (n, "" if n == 1 else "e", "ist eins" if len(soll["spalten"]) == 1 else "sind %d" % len(soll["spalten"]))}
    geordnet = _nach_namen(ist, soll)
    if not geordnet:
        fehlt = [s for s in soll["spalten"] if not any(x.lower().split(".")[-1] == s.lower().split(".")[-1] for x in ist["spalten"])]
        return {"ok": False, "text": "Die Attribute stimmen noch nicht" + (": es fehlt " + ", ".join(fehlt) + "." if fehlt and zeige_fehlende else ".")}
    b = {_zeile(z) for z in soll["zeilen"]}
    a = {_zeile(z) for z in geordnet["zeilen"]}
    for z in geordnet["zeilen"]:
        if _zeile(z) not in b:
            return {"ok": False, "zeile": z, "spalten": soll["spalten"], "text": "Diese Zeile gehört nicht ins Ergebnis:"}
    for z in soll["zeilen"]:
        if _zeile(z) not in a:
            return ({"ok": False, "zeile": z, "spalten": soll["spalten"], "text": "Es fehlt mindestens eine Zeile, zum Beispiel:"}
                    if zeige_fehlende else {"ok": False, "text": "Es fehlt noch mindestens eine Zeile."})
    if len(geordnet["zeilen"]) != len(a):
        return {"ok": False, "text": "Eine Zeile steht doppelt da. Ein Ergebnis der Relationenalgebra ist eine Menge: jede Zeile einmal."}
    return {"ok": True, "text": "Stimmt: %s, genau die gesuchten." % ("keine Zeile — die Menge ist leer" if not b else "%d Zeile%s" % (len(b), "" if len(b) == 1 else "n"))}


def pruefen(basen, eingabe, muster):
    """Prueft einen Term gegen das Muster -- auf jeder Datenbasis. Was im Auszug stimmt, kann in der ganzen Datenbank
    falsch sein. basen: [(name, db)]."""
    for name, db in basen:
        v = vergleichen(alle(db, eingabe), alle(db, muster))
        if not v["ok"]:
            return dict(v, basis=name)
    n = len(alle(basen[0][1], muster)["zeilen"])
    return {"ok": True, "text": "Stimmt: %s, genau die gesuchten" % ("die Menge ist leer" if n == 0 else "%d Zeile%s" % (n, "" if n == 1 else "n"))
            + (" — im Auszug und in der ganzen Datenbank." if len(basen) > 1 else ".")}


def term_pruefen(basen, eingabe, muster):
    """Fuer die Aufgabenart: wie pruefen, aber ein Fehler im Term der Klasse ist eine Meldung, kein Absturz.
    {ok, text, titel?, zeile?, spalten?, basis?}"""
    try:
        return pruefen(basen, eingabe, muster)
    except RAFehler as e:
        return {"ok": False, "titel": e.titel, "text": e.text}
    except sqlite3.Error as e:
        return {"ok": False, "titel": "Das DBMS meldet einen Fehler", "text": esc(str(e))}


# ── Die Datenbasen ─────────────────────────────────────────────────────────────────────────────────────────────────

def auszug_bauen(voll, auszug):
    """Eine zweite Datenbank mit demselben Schema und den Zeilen aus auszug.json -- damit stimmt, was gerechnet wird,
    mit dem Blatt (raAusdruckBauen in relalg.js)."""
    db = sqlite3.connect(":memory:", check_same_thread=False)
    for name, s in _werte(voll, "SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY rowid"):
        db.execute(s)
        zeilen = auszug.get(name) or []
        if zeilen:
            db.executemany("INSERT INTO %s VALUES (%s)" % (_q(name), ",".join("?" * len(zeilen[0]))), zeilen)
    db.commit()
    db.execute("PRAGMA query_only = ON")      # Aufgabenart „Abfrage“ (20.11.2026): getipptes SQL darf nichts schreiben
    return db


_BASEN = {}


def basen(ordner):
    """[("Auszug", db), ("ganze Datenbank", db)] aus <ordner>/fall.sqlite und auszug.json (bauen.py legt sie nach
    _system/seite/werkstatt/daten/). Die ganze Datenbank nur lesend. Fehlt eine Datei: None."""
    ordner = pathlib.Path(ordner)
    schluessel = str(ordner.resolve())
    if schluessel not in _BASEN:
        db_pfad, aus_pfad = ordner / "fall.sqlite", ordner / "auszug.json"
        if not (db_pfad.is_file() and aus_pfad.is_file()):
            return None
        voll = sqlite3.connect(db_pfad.resolve().as_uri() + "?mode=ro", uri=True, check_same_thread=False)
        _BASEN[schluessel] = [("Auszug", auszug_bauen(voll, json.loads(aus_pfad.read_text("utf-8")))), ("ganze Datenbank", voll)]
    return _BASEN[schluessel]


# ── Aufgabenart „Abfrage“ (iq2 fall/select, 20.11.2026): SQL statt Term ─────────────────────────────────────────
#  Die Klasse tippt eine SQL-Anweisung; der Server fuehrt sie NUR LESEND aus (eine Anweisung, beginnt mit SELECT,
#  query_only bzw. mode=ro, Deckel fuer Zeit und Zeilen) und vergleicht sie mit der gesuchten -- am Auszug und an der
#  ganzen Datenbank. Spalten nach Namen; als Multimenge (SQL streicht doppelte Zeilen nicht -- DISTINCT kommt in
#  `lesen`); steht im Gesuchten ORDER BY, zaehlt auch die Reihenfolge. Meldungen wie fehlerDeuten in daten.js.

import time as _time

SQL_GRENZE = 100001
SQL_SEKUNDEN = 3.0
_SQL_WOERTER = ["SELECT", "FROM", "WHERE", "AND", "OR", "NOT", "LIKE", "BETWEEN", "ORDER", "BY", "GROUP", "HAVING", "JOIN", "ON",
            "AS", "DISTINCT", "COUNT", "SUM", "AVG", "MIN", "MAX", "ASC", "DESC", "IN", "IS", "NULL", "INNER", "NATURAL"]


def _sql_ohne_kommentar(s):
    return re.sub(r"--[^\n]*", "", s).strip().rstrip(";").strip()


def sql_alle(db, eingabe):
    """{spalten, zeilen, anzahl} -- wirft RAFehler (nur lesen, eine Anweisung, zu lange) oder sqlite3.Error."""
    s = _sql_ohne_kommentar(eingabe)
    if not s:
        raise RAFehler("Keine Abfrage", "Das Feld ist leer.")
    if ";" in re.sub(r"'[^']*'", "", s):
        raise RAFehler("Nur eine Anweisung", "Hier steht mehr als eine Anweisung. Schreibt genau eine, sie beginnt mit <code>SELECT</code>.")
    if not re.match(r"(?is)^SELECT\b", s):
        raise RAFehler("Nur lesen", "Eine Abfrage beginnt mit <code>SELECT</code>.")
    beginn = _time.monotonic()
    db.set_progress_handler(lambda: 1 if _time.monotonic() - beginn > SQL_SEKUNDEN else 0, 20000)
    try:
        try:
            cur = db.execute(s)
        except sqlite3.OperationalError as e:
            if "interrupted" in str(e):
                raise RAFehler("Das dauert zu lange", "Die Datenbank rechnet zu lange an dieser Abfrage. Steht jede Tabelle mit einer Bedingung verbunden da?")
            raise
        spalten = [d[0] for d in (cur.description or [])]
        zeilen = [list(z) for z in cur.fetchmany(SQL_GRENZE)]
    except sqlite3.OperationalError as e:
        if "interrupted" in str(e):
            raise RAFehler("Das dauert zu lange", "Die Datenbank rechnet zu lange an dieser Abfrage. Steht jede Tabelle mit einer Bedingung verbunden da?")
        raise
    finally:
        db.set_progress_handler(None, 0)
    return {"spalten": spalten, "zeilen": zeilen, "anzahl": len(zeilen)}


def sql_fehler_deuten(meldung, eingabe, db):
    """{titel, text} -- wie fehlerDeuten in daten.js: nennt die Stelle, nie die Loesung."""
    tabs = _tabellen(db)
    spalten = sorted({s for t in tabs for s in _spalten(db, t)})
    c = code
    m = re.search(r"no such table: (?:main\.)?(\S+)", meldung)
    if m:
        v = _aehnlich(m.group(1), tabs)
        return {"titel": "Diese Tabelle gibt es nicht", "text": "Eine Tabelle %s kennt die Datenbank nicht.%s Vorhanden: %s." % (c(m.group(1)), (" Meint ihr %s?" % c(v)) if v else "", ", ".join(c(x) for x in tabs))}
    m = re.search(r"no such column: (\S+)", meldung)
    if m:
        w = m.group(1); kurz = w.split(".")[-1]; v = _aehnlich(kurz, spalten)
        wertstelle = "." not in w and re.search(r"(=|<>|!=|<|>|\bLIKE|\bIN\s*\(|,)\s*" + re.escape(w) + r"\b", eingabe, re.I)
        if v and v != kurz and not wertstelle:
            return {"titel": "Diese Spalte gibt es nicht", "text": "Eine Spalte %s gibt es nicht. Meint ihr %s? Der Plan zeigt alle Spalten." % (c(w), c(v))}
        if "." in w:
            return {"titel": "Diese Spalte gibt es nicht", "text": "%s gibt es nicht. Steht die Tabelle vor dem Punkt auch im FROM, und hat sie diese Spalte?" % c(w)}
        return {"titel": "Spalte oder Text?", "text": "Eine Spalte %s gibt es nicht. Ist %s ein <b>Wert</b>, also ein Text wie in der Tabelle? Dann gehört er in einfache Anführungszeichen: %s." % (c(w), c(w), c("'" + w + "'"))}
    m = re.search(r"ambiguous column name: (\S+)", meldung)
    if m:
        return {"titel": "Welche Spalte ist gemeint?", "text": "%s gibt es in mehreren Tabellen der Abfrage. Schreibt den Tabellennamen davor: %s." % (c(m.group(1)), c("Tabelle." + m.group(1)))}
    if re.search(r"unrecognized token: \"'", meldung):
        return {"titel": "Anführungszeichen nicht geschlossen", "text": "Ein Text ist mit <code>'</code> geöffnet, aber nicht wieder geschlossen. Jeder Text braucht zwei Anführungszeichen: <code>'rot'</code>."}
    if "incomplete input" in meldung:
        return {"titel": "Die Abfrage ist unvollständig", "text": "Die Abfrage hört mitten drin auf. Fehlt am Ende noch etwas, zum Beispiel ein Wert nach <code>=</code> oder eine Klammer?"}
    m = re.search(r'near "([^"]*)": syntax error', meldung)
    if m:
        w = m.group(1); v = _aehnlich(w.upper(), _SQL_WOERTER); tipp = ""
        if v and v != w.upper():
            tipp = " Ist %s vielleicht ein vertipptes %s?" % (c(w), c(v))
        elif w.upper() == "FROM" and re.search(r",\s*FROM", eingabe, re.I):
            tipp = " Steht vor <code>FROM</code> ein Komma zu viel?"
        elif w.upper() == "WHERE" and not re.search(r"\bFROM\b", eingabe, re.I):
            tipp = " Fehlt vor <code>WHERE</code> noch <code>FROM</code> und eine Tabelle?"
        return {"titel": "Hier stimmt die Schreibweise nicht", "text": "Die Datenbank versteht die Abfrage kurz vor %s nicht mehr.%s" % (c(w), tipp)}
    if "misuse of aggregate" in meldung:
        return {"titel": "Zählen und Rechnen an der falschen Stelle", "text": "Eine Funktion wie <code>COUNT</code> oder <code>SUM</code> darf nicht im <code>WHERE</code> stehen. Bedingungen an das Gezählte gehören hinter <code>GROUP BY</code> in <code>HAVING</code>."}
    return {"titel": "Das DBMS meldet einen Fehler", "text": "Prüft die Abfrage Wort für Wort: " + esc(meldung)}


def _oben_teilen(s, trenner=","):
    """Teilt an Kommas auf oberster Ebene (nicht in Klammern, nicht in Texten)."""
    teile, tiefe, text, start = [], 0, False, 0
    for i, z in enumerate(s):
        if z == "'":
            text = not text
        elif not text and z == "(":
            tiefe += 1
        elif not text and z == ")":
            tiefe -= 1
        elif not text and tiefe == 0 and z == trenner:
            teile.append(s[start:i]); start = i + 1
    teile.append(s[start:])
    return [x.strip() for x in teile if x.strip()]


def _sortiergruppen(db, muster, n_spalten):
    """Die gesuchte Anweisung mit ORDER BY: ihre Zeilen in Gruppen gleicher Sortierschluessel, in Reihenfolge -- Zeilen
    mit gleichem Schluessel duerfen in beliebiger Folge stehen (gleiche Geburtsjahre). Dazu werden die Ausdruecke hinter
    ORDER BY als Spalten angehaengt. Geht das nicht, None (dann zaehlt die genaue Reihenfolge)."""
    s = _sql_ohne_kommentar(muster)
    treffer = list(re.finditer(r"(?is)\bORDER\s+BY\b", s))
    if not treffer:
        return None
    vor, ob = s[:treffer[-1].start()], s[treffer[-1].end():]
    schluessel = [re.sub(r"(?is)\s+(ASC|DESC)\s*$", "", k) for k in _oben_teilen(ob)]
    m = re.search(r"(?is)^\s*SELECT\s+(?:DISTINCT\s+)?(.*?)\s+FROM\b", vor)
    if not m or not schluessel:
        return None
    try:
        zeilen = sql_alle(db, vor[:m.end(1)] + ", " + ", ".join(schluessel) + vor[m.end(1):] + " ORDER BY " + ob)["zeilen"]
    except (RAFehler, sqlite3.Error):
        return None
    gruppen, letzter = [], object()
    for z in zeilen:
        k = _zeile(z[n_spalten:])
        if k != letzter:
            gruppen.append([]); letzter = k
        gruppen[-1].append(_zeile(z[:n_spalten]))
    return gruppen


def _folge_passt(zeilen, gruppen):
    """Stehen die Zeilen Gruppe fuer Gruppe in der Reihenfolge? Innerhalb einer Gruppe ist die Folge frei."""
    from collections import Counter
    i, rest = 0, Counter(gruppen[0]) if gruppen else Counter()
    for z in zeilen:
        while rest[z] == 0:
            if sum(rest.values()) > 0:
                return False
            i += 1
            if i >= len(gruppen):
                return False
            rest = Counter(gruppen[i])
        rest[z] -= 1
    return True


def sql_vergleichen(ist, soll, reihenfolge=False, gruppen=None):
    """{ok, text, zeile?, spalten?} -- Spalten nach Namen, Zeilen als Multimenge; mit reihenfolge auch die Folge (bei
    gleichen Sortierschluesseln -- gruppen -- ist sie innerhalb der Gruppe frei)."""
    if len(ist["spalten"]) != len(soll["spalten"]):
        n = len(ist["spalten"])
        return {"ok": False, "text": "Euer Ergebnis hat %d Spalte%s, gesucht %s." % (n, "" if n == 1 else "n", "ist eine" if len(soll["spalten"]) == 1 else "sind %d" % len(soll["spalten"]))}
    geordnet = _nach_namen(ist, soll)
    if not geordnet:
        fehlt = [s for s in soll["spalten"] if not any(x.lower().split(".")[-1] == s.lower().split(".")[-1] for x in ist["spalten"])]
        return {"ok": False, "text": "Die Spalten stimmen noch nicht" + (": es fehlt " + ", ".join(fehlt) + "." if fehlt else ".")}
    from collections import Counter
    a, b = Counter(_zeile(z) for z in geordnet["zeilen"]), Counter(_zeile(z) for z in soll["zeilen"])
    for z in geordnet["zeilen"]:
        if b[_zeile(z)] == 0:
            return {"ok": False, "zeile": z, "spalten": soll["spalten"], "text": "Diese Zeile gehört nicht ins Ergebnis:"}
    for z in soll["zeilen"]:
        if a[_zeile(z)] == 0:
            return {"ok": False, "zeile": z, "spalten": soll["spalten"], "text": "Es fehlt mindestens eine Zeile, zum Beispiel:"}
    if a != b:
        return {"ok": False, "text": "Eine Zeile steht zu oft oder zu selten da."}
    if reihenfolge and not (_folge_passt([_zeile(z) for z in geordnet["zeilen"]], gruppen) if gruppen is not None
                            else [_zeile(z) for z in geordnet["zeilen"]] == [_zeile(z) for z in soll["zeilen"]]):
        return {"ok": False, "text": "Die Zeilen stimmen, aber nicht ihre Reihenfolge — achtet auf ORDER BY."}
    n = len(soll["zeilen"])
    return {"ok": True, "text": "Stimmt: %d Zeile%s, genau die gesuchten." % (n, "" if n == 1 else "n")}


def abfrage_pruefen(basen, eingabe, muster):
    """Fuer die Aufgabenart „Abfrage“: {ok, text, titel?, zeile?, spalten?, basis?} -- ein Fehler der Klasse ist eine
    Meldung, kein Absturz."""
    reihenfolge = bool(re.search(r"(?is)\bORDER\s+BY\b", _sql_ohne_kommentar(muster)))
    for name, db in basen:
        try:
            ist = sql_alle(db, eingabe)
        except RAFehler as e:
            return {"ok": False, "titel": e.titel, "text": e.text}
        except sqlite3.Error as e:
            return dict(sql_fehler_deuten(str(e), eingabe, db), ok=False)
        soll = sql_alle(db, muster)
        v = sql_vergleichen(ist, soll, reihenfolge, _sortiergruppen(db, muster, len(soll["spalten"])) if reihenfolge else None)
        if not v["ok"]:
            return dict(v, basis=name)
    n = sql_alle(basen[0][1], muster)["anzahl"]
    return {"ok": True, "text": "Stimmt: %d Zeile%s, genau die gesuchten" % (n, "" if n == 1 else "n")
            + (" — im Auszug und in der ganzen Datenbank." if len(basen) > 1 else ".")}
