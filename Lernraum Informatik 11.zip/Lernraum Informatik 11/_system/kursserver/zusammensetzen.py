"""Eine Schuelerfassung aus Bausteinen zusammensetzen (Kurse im Pult anlegen, K1, 24.11.2026).

Lehrer 24.11.2026: *„Kann man es nicht so machen, dass das Lehrerpult alle Kurse enthält in ihrer Urform und ich dann
Kurse auf der Seite erstellen kann, die dann automatisch eine entsprechende Schülerversion mit neuen Passwörtern etc.
erstellt?“* -- entschieden: Das Pult baut nicht, es setzt nur Kapitel zusammen, die im Projekt gebaut und geprueft sind.

Darum gibt es diesen Schritt genau EINMAL: bauen.py ruft ihn fuer jede Schuelerfassung, das Pult ruft ihn fuer einen
neuen Kurs. Was hier steht, entscheidet beides; Projekt und Pult koennen nicht auseinanderlaufen. Nur die
Standardbibliothek (das Pult laeuft am Schulrechner in Thonny).

Ein BAUSTEIN ist ein Kapitel, fertig gebaut fuer die Schuelerfassung, ohne das, was erst der Kurs festlegt:

    <bausteine>/<kapitel>/kapitel.json   die Reihe (ohne nr, zugabe, halbjahr), dazu je Thema die Eingaben fuer
                                         Glossar und Lernkarten, Hilfen, Pruefstoff und die Loesungen IM KLARTEXT
    <bausteine>/<kapitel>/themen/...     die Dateien der Themen (wie in themen/<kapitel>/ der Schuelerfassung,
                                         ohne loesung.enc), dazu _akte/
    <system>/_system/kursserver, seite   Server und Seite der Schuelerfassung
    <system>/start.py
    <system>/_beilagen/daten/            die Werkstatt Daten (nur wenn ein Kapitel sie braucht, kommt sie hinein)

Was erst der Kurs festlegt: Reihenfolge und Nummern der Kapitel, Zugabe, Halbjahr, die Kennwoerter (und damit die
verschluesselten Loesungen samt Kette), Glossar und Lernkarten ueber alle Kapitel, Titel, Kennung, Fassung.
Die Loesungen im Klartext liegen nur in Bausteinen -- im Projekt (Temp-Ordner) und im Pult, nie in einer Schuelerfassung.
"""
import hashlib
import html
import json
import pathlib
import re
import shutil

from . import chiffre

KAPITEL_JSON = "kapitel.json"
PRUEFSTOFF_TEILE = ("parsons", "faelle", "vorhersagen", "fragen", "klausuren", "diagramme", "terme")
UMLAUTE = str.maketrans({"ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss", "Ä": "ae", "Ö": "oe", "Ü": "ue"})


# -- Glossar und Lernkarten (bis 24.11.2026 in bauen.py) ------------------------------------------------------------
def formen(begriff):
    """Die Formen, unter denen ein Begriff im Text gefunden wird -- ohne Zusatztext in der
    Quelle (Galerie Rang 6): Programm, Programms, Programme, Programmen; Algorithmus -> Algorithmen.
    Gleich lange Formen alphabetisch (bis 24.11.2026 in Mengenreihenfolge -- jeder Bau eine andere)."""
    if begriff.endswith("us"):
        f = [begriff, begriff[:-2] + "en"]
    elif begriff.endswith("e"):
        f = [begriff, begriff + "n", begriff + "s"]
    else:
        f = [begriff, begriff + "s", begriff + "e", begriff + "en", begriff + "es"]
    return sorted(set(f), key=lambda x: (-len(x), x))


def glossar_bauen(themen):
    """themen: [(reihe, thema, definitionen, texte)] in Kursreihenfolge. Jeder ::: definition-Block
    wird ein Eintrag: Begriff · Definition (die der Erklaerung, sonst die erste) · eingefuehrt
    (die erste Stelle im Kurs) · vorkommend (je Thema die Stellen, an denen er im Text steht)."""
    eintraege = {}
    for r, t, defs, _ in themen:
        for d in defs:
            e = eintraege.setdefault(d["begriff"], {"begriff": d["begriff"], "html": d["html"], "formen": formen(d["begriff"]),
                                                   "eingefuehrt": dict(d["ort"], thema=r["kennung"] + "/" + t["kennung"], nr=t["nr"]),
                                                   "_erkl": False, "vorkommend": []})
            e.setdefault("_def", set()).add((r["kennung"] + "/" + t["kennung"], d["ort"]["ort"]))
            if d["ort"]["ort"].startswith("erklaerung") and not e["_erkl"]:
                e["html"], e["_erkl"] = d["html"], True
                if d["ort"]["ort"] != e["eingefuehrt"]["ort"] or t["nr"] != e["eingefuehrt"]["nr"]:
                    e["erklaert"] = dict(d["ort"], thema=r["kennung"] + "/" + t["kennung"], nr=t["nr"])
    for e in eintraege.values():
        muster = re.compile(r"(?<!\w)(?:%s)(?!\w)" % "|".join(re.escape(x) for x in e["formen"]))
        for r, t, _, texte in themen:
            # Erst ab dem Thema, das ihn einfuehrt (Reihensichtung i11 Teil II, 25.10.: „Bibliothek“ -- der Raum im
            # Spiel -- stand als Fundstelle schon in T1-T6, die Python-Bibliothek kommt in T14; die Klasse sah den
            # Begriff, bevor er dran war). Ein Wort, das vorher fiel, meinte etwas anderes oder war noch nicht Stoff.
            if t["nr"] < e["eingefuehrt"]["nr"]:
                continue
            # Wo er definiert ist, steht er schon unter eingefuehrt/erklaert -- nicht noch einmal
            orte = [dict(o) for o, text in texte if muster.search(text) and (r["kennung"] + "/" + t["kennung"], o["ort"]) not in e["_def"]]
            if orte:
                e["vorkommend"].append({"thema": r["kennung"] + "/" + t["kennung"], "nr": t["nr"], "titel": t["titel"], "orte": orte})
        e.pop("_erkl")
        e.pop("_def")
    schluessel = lambda b: b.lower().translate(UMLAUTE)  # noqa: E731
    return [eintraege[b] for b in sorted(eintraege, key=schluessel)]


def lernkarten_bauen(glossar, themen):
    """Lernkarten (Galerie Rang 15, Lehrer 16.10.: „Entscheide du“ -> A Begriffe + B Prueffragen der
    Erklaerung, aufdecken und selbst sagen). Ohne Zusatztext in der Quelle:
      begriff/<Begriff>            jeder Glossar-Eintrag: vorne der Begriff, hinten seine Definition;
                                   gehoert zum Thema, in dem er eingefuehrt wird
      frage/<reihe>/<thema>/<name> jede Prueffrage der Erklaerung: vorne die Frage, hinten die richtige
                                   Wahl mit Begruendung
    Die Kennung steht im Stand der Klasse -- wie bei den Fragen: ein Name wechselt nie die Frage.
    Reihenfolge: Kursreihenfolge der Themen, je Thema erst Begriffe, dann Fragen."""
    reihenfolge = {r["kennung"] + "/" + t["kennung"]: i for i, (r, t, _) in enumerate(themen)}
    karten = []
    for e in glossar:
        k = e["eingefuehrt"]["thema"]
        karten.append({"id": "begriff/" + e["begriff"], "art": "begriff", "thema": k, "vorne": html.escape(e["begriff"]),
                       "hinten": e["html"], "kurz": e["begriff"], "_o": (reihenfolge.get(k, 999), 0)})
    for r, t, fragen in themen:
        k = r["kennung"] + "/" + t["kennung"]
        for i, f in enumerate(fragen):
            karten.append(dict({x: f[x] for x in ("vorne", "hinten", "kurz")}, id="frage/%s/%s" % (k, f["name"]), art="frage",
                               thema=k, _o=(reihenfolge[k], 1 + i)))
    karten.sort(key=lambda c: c["_o"])
    for c in karten:
        c.pop("_o")
    return karten


# -- Manifest (bis 24.11.2026 in bauen.py) ------------------------------------------------------------------------
def dateien_hashen(ziel):
    aus = {}
    for f in sorted(pathlib.Path(ziel).rglob("*")):
        rel = f.relative_to(ziel).as_posix()
        if f.is_file() and not rel.startswith(("_stand/", "abgaben/")) and "__pycache__" not in rel and rel != "_system/manifest.json":
            aus[rel] = hashlib.sha256(f.read_bytes()).hexdigest()
    return aus


KAPITEL_RUNDEN = 200000      # PBKDF2 wie chiffre.py -- ein Kapitel-Kennwort ist so stark wie das einer Loesung


def kennwort_normal(kennwort):
    """Wie die Klasse ein Kennwort tippt: Gross/klein und Leerzeichen am Rand sind egal (wie bei den Loesungen)."""
    return str(kennwort or "").strip().lower()


def kapitel_pruefwert(kurs, kapitel, kennwort):
    """Kapitel mit Kennwort freischalten (Lehrer 25.11.2026): die Schuelerfassung traegt je gesperrtem Kapitel nur
    diesen Pruefwert, nie das Kennwort. Das Salz haengt an Kurs und Kapitel, nicht am Zufall -- sonst setzte das Pult
    einen anderen Kurs zusammen als das Projekt (Gegenprobe, Bausteintest)."""
    salz = hashlib.sha256(("lernraum-kapitel:%s:%s" % (kurs, kapitel)).encode("utf-8")).hexdigest()[:32]
    pruef = hashlib.pbkdf2_hmac("sha256", kennwort_normal(kennwort).encode("utf-8"), bytes.fromhex(salz), KAPITEL_RUNDEN).hex()
    return {"salz": salz, "pruef": pruef}


def kapitel_kennwort_passt(gesperrt, kennwort):
    p = hashlib.pbkdf2_hmac("sha256", kennwort_normal(kennwort).encode("utf-8"), bytes.fromhex(gesperrt["salz"]), KAPITEL_RUNDEN).hex()
    return hashlib.sha256(p.encode()).digest() == hashlib.sha256(gesperrt["pruef"].encode()).digest()


def manifest_schreiben(ziel, inhalt, fassung):
    """_system/manifest.json: je Datei SHA-256 und Art -- system (Seite, Server, start.py),
    inhalt (Themen), arbeit (Arbeitsdateien der Klasse: bei einer Aktualisierung nur
    angelegt, wenn sie fehlen, nie ersetzt). kursserver/aktualisieren.py liest es."""
    ziel = pathlib.Path(ziel)
    arbeit = set()
    for r in inhalt["reihen"]:
        for t in r["themen"]:
            basis = "themen/%s/%s/" % (r["kennung"], t["kennung"])
            if t.get("arbeitsdateien"):
                arbeit.update(basis + rel for rel in t["arbeitsdateien"])
            elif t["arbeitsdatei"]:
                arbeit.add(basis + t["arbeitsdatei"])
            for s in t["vortrag"]:
                if s["art"] in ("code", "html"):
                    arbeit.add(basis + "vortrag/" + s["arbeit"])
    dateien = {}
    for rel, s in dateien_hashen(ziel).items():
        art = "arbeit" if rel in arbeit else ("inhalt" if rel.startswith("themen/") else "system")
        dateien[rel] = {"sha256": s, "art": art}
    m = {"kurs": inhalt["kurs"], "fassung_nr": fassung["nr"], "fassung_datum": fassung.get("datum", ""),
         "aenderungen": fassung.get("aenderungen", []), "entwurf": inhalt.get("fassung_entwurf", False),
         # gesperrte Kapitel (25.11.2026) nicht: aus dieser Liste zeigt die Seite nach einer Aktualisierung „Neue Themen“
         "themen": {r["kennung"] + "/" + t["kennung"]: "Thema %d · %s" % (t["nr"], t["titel"]) for r in inhalt["reihen"]
                    if not r.get("gesperrt") for t in r["themen"]},
         "dateien": dateien}
    (ziel / "_system" / "manifest.json").write_text(json.dumps(m, ensure_ascii=False, indent=0), "utf-8")
    return m


def ordnername(titel):
    """Der Ordner, den die Klasse nach dem Entpacken sieht -- „Lernraum Informatik Q-Phase“ (wie in der Anleitung)."""
    return "Lernraum " + titel


def zipname(titel):
    """Der Name der ZIP: der des Ordners, ohne Kennung und ohne Fassung (Lehrer 24.11.2026: „Ich weiß nicht, ob das
    Schulportal Dateien umbenennt“ -- der Lernraum erkennt Kurs und Fassung ohnehin am Inhalt, nie am Namen)."""
    return ordnername(titel) + ".zip"


def info_name(kopf):
    """Die Info-Datei im Lernraum: an ihrem Namen sieht man den Kurs (24.11.2026). Nur ASCII-Zeichen im Namen --
    die ZIP soll auf jedem Windows sauber entpacken."""
    teile = [kopf["titel"]]
    if kopf.get("untertitel") and not kopf["untertitel"].startswith(kopf["titel"]):
        teile.append(kopf["untertitel"])
    elif kopf.get("untertitel"):
        teile = [kopf["untertitel"]]
    name = " - ".join(teile)
    name = re.sub(r"[^A-Za-z0-9ÄÖÜäöüß .,()-]+", "-", name.replace("·", "-").replace("/", "-"))
    name = name.translate(str.maketrans({"ä": "ae", "ö": "oe", "ü": "ue", "Ä": "Ae", "Ö": "Oe", "Ü": "Ue", "ß": "ss"}))
    return "Kurs - " + re.sub(r"\s*-\s*(-\s*)+", " - ", name).strip(" -")[:90] + ".txt"


INFO_MUSTER = re.compile(r"^Kurs - [A-Za-z0-9 .,()-]+\.txt$")       # aktualisieren.py laesst genau diese Datei zu


def info_text(kopf):
    z = ["Lernraum: %s%s" % (kopf["titel"], (" · " + kopf["untertitel"]) if kopf.get("untertitel") else ""),
         "Kurs: %s" % kopf["kurs"]]
    if kopf.get("schuljahr"):
        z.append("Schuljahr: %s" % kopf["schuljahr"])
    z += ["", "Diesen Ordner „%s“ ganz auf deinen USB-Stick ziehen." % ordnername(kopf["titel"]),
          "Dann in Thonny start.py öffnen und den grünen Pfeil drücken (F5).",
          "Mehr steht in SO_FAENGST_DU_AN.pdf. Welche Fassung du hast, steht unten auf der Kursseite.", ""]
    return "\r\n".join(z)          # Windows-Zeilenenden: der Editor der Schule zeigt sie sicher richtig


def zip_bauen(schueler, ziel_zip, ordner=None):
    """Die ZIP eines Lernraums: genau die Dateien des Manifests + das Manifest (bis 24.11.2026 in fassung.py).
    Seit 24.11.2026 in EINEM Ordner („Lernraum <titel>/“, ordner=None: aus inhalt.json) -- nach dem Entpacken liegt
    der Ordner da, den die Anleitung nennt, gleich wie die ZIP heisst. Dieselbe ZIP taugt zum Austeilen, fuer
    „Von Hand hereinnehmen“ und als Aktualisierung ueber GitHub (aktualisieren.py erkennt den Ordner)."""
    import zipfile
    schueler, ziel_zip = pathlib.Path(schueler), pathlib.Path(ziel_zip)
    m = json.loads((schueler / "_system" / "manifest.json").read_text("utf-8"))
    if ordner is None:
        ordner = ordnername(json.loads((schueler / "_system" / "inhalt.json").read_text("utf-8"))["titel"])
    ziel_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ziel_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in sorted(m["dateien"]) + ["_system/manifest.json"]:
            z.write(schueler / rel, (ordner + "/" + rel) if ordner else rel)
    daten = ziel_zip.read_bytes()
    return hashlib.sha256(daten).hexdigest(), len(daten)


# -- Bausteine ------------------------------------------------------------------------------------------------------
def braucht_daten(reihen):
    """Die Werkstatt Daten (sql.js, Fall-Datenbank, fuenf MB) nur, wenn ein Thema sie benutzt."""
    return any(th.get("werkstatt") == "daten" or th.get("terme") or any(x.get("name") == "daten" for x in th["vortrag"] if x["art"] == "werkstatt")
               for r in reihen for th in r["themen"])


def baustein_schreiben(ordner, reihe, themen_extra, hilfen, pruefstoff, loesungen):
    """kapitel.json eines Bausteins. reihe: wie in inhalt.json, ohne nr/zugabe/halbjahr. themen_extra: je Thema
    (in Reihenfolge) {"glossar": [definitionen, texte], "karten": [fragen]}. loesungen: {kapitel/thema: Loesung}."""
    ordner = pathlib.Path(ordner)
    ordner.mkdir(parents=True, exist_ok=True)
    r = {k: v for k, v in reihe.items() if k not in ("nr", "zugabe", "halbjahr", "vorbereitet", "gesperrt", "kennwort")}   # was erst der Kurs festlegt
    (ordner / KAPITEL_JSON).write_text(json.dumps({"reihe": r, "themen": themen_extra, "hilfen": hilfen, "pruefstoff": pruefstoff,
                                                   "loesungen": loesungen}, ensure_ascii=False), "utf-8")


def baustein_lesen(ordner):
    return json.loads((pathlib.Path(ordner) / KAPITEL_JSON).read_text("utf-8"))


def _kopieren(quelle, ziel):
    ziel.parent.mkdir(parents=True, exist_ok=True)
    if quelle.is_dir():
        shutil.copytree(quelle, ziel, ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
    else:
        shutil.copy2(quelle, ziel)


def zusammensetzen(bausteine, system, kurs, kapitel, kennwoerter, ziel):
    """Setzt eine Schuelerfassung nach ziel/ zusammen (der Ordner muss leer sein oder fehlen).

    bausteine   Ordner mit einem Unterordner je Kapitel (siehe oben)
    system      Ordner mit _system/kursserver, _system/seite, start.py, _beilagen/daten
    kurs        {"kurs", "titel", "untertitel", "version", "fassung_nr", "fassung_datum", "aktualisierung"
                 [, "halbjahr"]} -- die Kopfwerte von inhalt.json
    kapitel     [{"kennung": "schach", "zugabe": False, "halbjahr": "Q1" | None [, "kennwort": "…"]}, ...] in
                Kursreihenfolge -- mit "kennwort" ist das Kapitel gesperrt, bis die Klasse es eintippt (25.11.2026)
    kennwoerter {"<kapitel>/<thema>": kennwort} fuer jedes Thema mit Loesung

    Schreibt Themen, verschluesselte Loesungen (mit der Kette: jede traegt die Kennwoerter aller Themen davor,
    Lehrer 16.11.2026), _system/inhalt.json, hilfen.json, pruefstoff.json, Server und Seite, start.py, _stand/,
    abgaben/. Das Manifest und „Entwurf“ schreibt der Aufrufer (manifest_schreiben), wenn inhalt fertig ist.
    Gibt inhalt zurueck."""
    bausteine, system, ziel = pathlib.Path(bausteine), pathlib.Path(system), pathlib.Path(ziel)
    ziel.mkdir(parents=True, exist_ok=True)
    inhalt = {k: kurs[k] for k in ("kurs", "titel", "untertitel", "version")}
    inhalt.update(reihen=[], fassung_nr=kurs["fassung_nr"], fassung_datum=kurs.get("fassung_datum", ""),
                  aktualisierung=kurs.get("aktualisierung", ""))
    if kurs.get("halbjahr"):
        inhalt["halbjahr"] = kurs["halbjahr"]
    if kurs.get("schuljahr"):
        inhalt["schuljahr"] = kurs["schuljahr"]          # steht auch in der Info-Datei (24.11.2026)
    inhalt["fassung"] = "schueler"
    hilfen, pruefstoff = {}, {teil: {} for teil in PRUEFSTOFF_TEILE}
    glossar_themen, karten_themen, davor = [], [], []
    for nr, k in enumerate(kapitel, 1):
        rk = k["kennung"]
        b = baustein_lesen(bausteine / rk)
        reihe = {"kennung": rk, "nr": nr}
        reihe.update((x, v) for x, v in b["reihe"].items() if x != "kennung")
        reihe["zugabe"] = bool(k.get("zugabe"))
        if k.get("halbjahr"):
            reihe["halbjahr"] = k["halbjahr"]
        if k.get("kennwort"):
            reihe["gesperrt"] = kapitel_pruefwert(kurs["kurs"], rk, k["kennwort"])
        if (bausteine / rk / "themen").is_dir():
            _kopieren(bausteine / rk / "themen", ziel / "themen" / rk)
        for t, extra in zip(reihe["themen"], b["themen"]):
            glossar_themen.append((reihe, t, extra["glossar"][0], extra["glossar"][1]))
            karten_themen.append((reihe, t, extra["karten"]))
            voll = rk + "/" + t["kennung"]
            if t.get("hat_loesung"):
                mit_kette = dict(b["loesungen"][voll], davor=[{"thema": v, "kennwort": kennwoerter[v]} for v in davor])
                (ziel / "themen" / rk / t["kennung"]).mkdir(parents=True, exist_ok=True)
                (ziel / "themen" / rk / t["kennung"] / "loesung.enc").write_bytes(
                    chiffre.verschluesseln(json.dumps(mit_kette, ensure_ascii=False).encode("utf-8"), kennwoerter[voll]))
                davor.append(voll)
        hilfen.update(b["hilfen"])
        for teil, werte in b["pruefstoff"].items():
            pruefstoff[teil].update(werte)
        inhalt["reihen"].append(reihe)
    inhalt["glossar"] = glossar_bauen(glossar_themen)
    inhalt["lernkarten"] = lernkarten_bauen(inhalt["glossar"], karten_themen)
    sysz = ziel / "_system"
    _kopieren(system / "_system" / "kursserver", sysz / "kursserver")
    _kopieren(system / "_system" / "seite", sysz / "seite")
    if braucht_daten(inhalt["reihen"]):
        if not (system / "_beilagen" / "daten").is_dir():
            raise ValueError("Ein Kapitel braucht die Werkstatt Daten, der System-Baustein hat sie nicht.")
        _kopieren(system / "_beilagen" / "daten", sysz / "seite" / "werkstatt" / "daten")
    (sysz / "inhalt.json").write_text(json.dumps(inhalt, ensure_ascii=False, indent=0), "utf-8")
    (sysz / "hilfen.json").write_text(json.dumps(hilfen, ensure_ascii=False), "utf-8")
    (sysz / "pruefstoff.json").write_text(json.dumps(pruefstoff, ensure_ascii=False), "utf-8")
    _kopieren(system / "start.py", ziel / "start.py")
    # die Info-Datei: an ihrem Namen sieht man, welcher Kurs das ist (24.11.2026)
    (ziel / info_name(kurs)).write_text(info_text(kurs), "utf-8")
    (ziel / "_stand").mkdir(exist_ok=True)
    (ziel / "abgaben").mkdir(exist_ok=True)
    return inhalt
