// Werkstatt "Namensschilder" -- ein Objekt gibt es nur einmal; Variablen und Attribute sind Schilder, die daran haengen.
// iq1 schach/beziehung (14.11.2026). Drei Attrappen im Drehbuch (Faden · Debugger · auf dem Brett); Lehrerwahl:
// Fassung C „Auf dem Brett“ -- die Dinge stehen dort, wo das Programm sie zeigt: die Dame auf dem Brett, der Zug als
// Karte daneben, ein Zettel "Dame" (ein Wort). Die Schilder dame und zug haengen an ihren Dingen; das Fach figur des
// Zugs haengt erst am Zettel. Wer sein Ende auf die Dame zieht, hat dieselbe Dame mit zwei Schildern.
// Der Bruch zur 11: Dort lag der Wert als Karte IM Kaestchen (kaestchen.js) -- ein Objekt liegt nicht im Kaestchen.
// Tische (LT9: ein Tisch erscheint erst mit seinem Thema):
//   zug  -- beziehung: Dame, Zug, Zettel; fragen, umhaengen, ausfuehren
// Bedient wie eine Zeichenflaeche (LR6, 13.11.): das Ende des Fadens ziehen statt eines Modus, Strg/Cmd+Z nimmt zurueck,
// Esc bricht das Ziehen ab, die Kuerzel als Zeile darunter. Erst ohne Code, dann „als Python zeigen“ -- die Knoepfe
// werden zu Aufrufen, das Umhaengen zur Zeile, die den Zug baut.
// Der Zettel fliegt in den Papierkorb, sobald das Fach an der Dame haengt (Durchsicht 16.11.2026, W2: „Der "Dame"-Zettel
// irritiert, sobald der Pfeil zum Objekt geht. Er sollte sichtbar weggeworfen werden“) -- wer das Ende zurueck auf den
// Korb zieht, holt ihn wieder heraus.
// Einbinden: Werkstaetten.namensschilder(element, {tisch: "zug"}) -> { film: {spielen, herstellen, laeuft} }
// Film (bauen.py, WERKSTATT_FILM): + frage · + dame · + umhaengen: figur|zettel · + ausfuehren · + python · + neu · + halt
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.namensschilder = function (wurzel, opt) {
  opt = opt || {};
  const RUHIG = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  // der SVG-Namensraum ohne Adresse im Quelltext (K5 liest jede Adresse als extern) -- wie netz.js
  const NS = (() => { const d = document.createElement("div"); d.innerHTML = "<svg></svg>"; return d.firstChild.namespaceURI; })();
  const FELD = 52, BX = 20, BY = 20;                       // das Brett
  const KARTE = { x: 540, y: 34, b: 300, kopf: 40, zeile: 34 };   // der Zug
  const ZETTEL = { x: 600, y: 250, b: 150, h: 58 };
  const KORB = { x: 800, y: 340, b: 96, h: 84 };            // der Papierkorb -- dort liegt der Zettel, wenn ihn keiner braucht
  const WURF_MS = 600;
  const START = { zeile: 7, spalte: 3 }, ZIEL = { zeile: 3, spalte: 3 };

  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const s = (tag, at, text) => { const e = document.createElementNS(NS, tag); for (const k in at) e.setAttribute(k, at[k]); if (text != null) e.textContent = text; return e; };

  let z = neu();                // der Zustand
  let zurueck = [];             // fuer Strg/Cmd+Z
  let ziehen = null;            // {x, y} beim Ziehen des Fadenendes
  let lauf = null;              // die laufende Animation {von, nach, t0, fertig}
  let wurf = null;              // der Zettel fliegt: {hin: true (in den Korb) | false (zurueck auf den Tisch), t0}

  function neu() {
    return { fach: "zettel", zeile: START.zeile, spalte: START.spalte, python: false, antwort: null, protokoll: [] };
  }
  const kopie = o => JSON.parse(JSON.stringify(o));
  function merken() { zurueck.push(kopie(z)); if (zurueck.length > 50) zurueck.shift(); }

  wurzel.textContent = "";
  wurzel.classList.add("namensschilder");
  const auftrag = h("p", "auftrag", "Die Dame steht auf dem Brett, der Zug liegt daneben. Ein Schild hängt an genau einem Ding – an einem Ding dürfen mehrere hängen.");
  const antwortEl = h("div", "antwort leer");
  const flaeche = s("svg", { viewBox: "0 0 930 470", class: "tisch", role: "img", "aria-label": "Das Brett mit der Dame, der Zug, ein Zettel, ein Papierkorb und die Namensschilder" });
  const aktionen = h("div", "aktionen");
  const meldung = h("p", "meldung");
  const protokollEl = h("pre", "protokoll"); protokollEl.hidden = true;
  const unten = h("div", "unten");
  const schalter = h("button", "", "als Python zeigen");
  const vonVorn = h("button", "ruhig", "von vorn");
  unten.append(schalter, vonVorn);
  const kuerzel = h("p", "kuerzel", "Das Ende am Fach figur ziehen: umhängen · Strg/⌘+Z zurück · Esc bricht ab");
  wurzel.append(auftrag, antwortEl, flaeche, aktionen, meldung, unten, kuerzel, protokollEl);

  // ─── Lage ──────────────────────────────────────────────────────────────────────────
  function feldMitte(zeile, spalte) { return { x: BX + spalte * FELD + FELD / 2, y: BY + zeile * FELD + FELD / 2 }; }
  function figurLage() {
    if (lauf) {
      const t = Math.min(1, (performance.now() - lauf.t0) / 700), e = t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      return { zeile: lauf.von.zeile + (lauf.nach.zeile - lauf.von.zeile) * e, spalte: lauf.von.spalte + (lauf.nach.spalte - lauf.von.spalte) * e };
    }
    return { zeile: z.zeile, spalte: z.spalte };
  }
  const fachY = KARTE.y + KARTE.kopf + KARTE.zeile * .5;
  const griff = { x: KARTE.x + KARTE.b, y: fachY };
  function zielPunkt(ziel) {
    if (ziel === "figur") { const l = figurLage(); const m = feldMitte(l.zeile, l.spalte); return { x: m.x + 20, y: m.y - 20 }; }
    return { x: ZETTEL.x + ZETTEL.b / 2, y: ZETTEL.y };
  }
  function trifft(p) {
    const l = figurLage(), m = feldMitte(l.zeile, l.spalte);
    if (Math.abs(p.x - m.x) <= FELD * .6 && Math.abs(p.y - m.y) <= FELD * .6) return "figur";
    // der Zettel liegt auf dem Tisch -- oder, wenn das Fach an der Dame haengt, im Papierkorb
    if (z.fach === "figur") {
      if (p.x >= KORB.x - 12 && p.x <= KORB.x + KORB.b + 12 && p.y >= KORB.y - 34 && p.y <= KORB.y + KORB.h + 10) return "zettel";
    } else if (p.x >= ZETTEL.x - 10 && p.x <= ZETTEL.x + ZETTEL.b + 24 && p.y >= ZETTEL.y - 10 && p.y <= ZETTEL.y + ZETTEL.h + 10) return "zettel";
    return null;
  }
  // wie weit der Zettel weg ist: 0 = liegt auf dem Tisch, 1 = liegt im Papierkorb
  function zettelWeg() {
    if (!wurf) return z.fach === "figur" ? 1 : 0;
    const f = Math.min(1, (performance.now() - wurf.t0) / WURF_MS), e = f < .5 ? 2 * f * f : 1 - Math.pow(-2 * f + 2, 2) / 2;
    return wurf.hin ? e : 1 - e;
  }

  // ─── Zeichnen ──────────────────────────────────────────────────────────────────────
  function faden(a, b, cls) {
    const mx = (a.x + b.x) / 2, my = Math.max(a.y, b.y) + 40;
    return s("path", { d: "M" + a.x + " " + a.y + " Q" + mx + " " + my + " " + b.x + " " + b.y, class: "faden " + (cls || "") });
  }
  // der Faden des Fachs: erst nach rechts aus der Karte, unter ihr herum, dann zum Ding -- nie quer ueber die Faecher
  function fachFaden(a, b, cls) {
    const unter = KARTE.y + KARTE.kopf + 3 * KARTE.zeile + 60;
    return s("path", { d: "M" + a.x + " " + a.y + " C" + (a.x + 70) + " " + a.y + " " + (a.x + 50) + " " + unter + " " + (a.x - 40) + " " + unter
      + " S" + (b.x + 40) + " " + (b.y - 60) + " " + b.x + " " + b.y, class: "faden " + (cls || "") });
  }
  function schild(x, y, text, cls) {
    const g = s("g", { class: "schild " + (cls || "") });
    const w = text.length * 11 + 34;
    g.append(s("path", { d: "M" + x + " " + (y + 16) + " L" + (x + 14) + " " + y + " H" + (x + w) + " V" + (y + 32) + " H" + (x + 14) + " Z" }),
      s("circle", { cx: x + 12, cy: y + 16, r: 3.5 }), s("text", { x: x + 22, y: y + 21 }, text));
    return { g, links: { x: x, y: y + 16 }, rechts: { x: x + w, y: y + 16 } };
  }
  function zeichnen() {
    flaeche.textContent = "";
    const brett = s("g", { class: "brett" });
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++)
      brett.append(s("rect", { x: BX + c * FELD, y: BY + r * FELD, width: FELD, height: FELD, fill: (r + c) % 2 === 0 ? "#eeeed2" : "#769656" }));
    flaeche.append(brett);
    const l = figurLage(), m = feldMitte(l.zeile, l.spalte);
    const fig = s("g", { class: "figur" + (ziehen && trifft(ziehen) === "figur" ? " ziel" : "") });
    // die Dame gezeichnet, nicht als Zeichen: ♕ kommt je nach Schrift als schwarzes Emoji (Probe 14.11.)
    const d = (x, y) => (m.x + x) + " " + (m.y + y);
    fig.append(s("circle", { cx: m.x, cy: m.y, r: FELD * .46, class: "ring" }),
      s("path", { class: "glyphe", d: "M" + d(-15, 14) + " L" + d(-18, -8) + " L" + d(-8, 2) + " L" + d(0, -14) + " L" + d(8, 2) + " L" + d(18, -8) + " L" + d(15, 14) + " Z" }),
      s("rect", { class: "glyphe", x: m.x - 17, y: m.y + 14, width: 34, height: 6, rx: 2 }),
      ...[[-18, -8], [0, -14], [18, -8]].map(([x, y]) => s("circle", { class: "glyphe", cx: m.x + x, cy: m.y + y - 4, r: 3.5 })));
    // der Zug als Karte
    const karte = s("g", { class: "karte-zug" });
    const hoch = KARTE.kopf + 3 * KARTE.zeile + 10;
    karte.append(s("rect", { x: KARTE.x, y: KARTE.y, width: KARTE.b, height: hoch, rx: 12 }),
      s("text", { x: KARTE.x + KARTE.b / 2, y: KARTE.y + 27, class: "kopf" }, "Zug"),
      s("line", { x1: KARTE.x, y1: KARTE.y + KARTE.kopf, x2: KARTE.x + KARTE.b, y2: KARTE.y + KARTE.kopf }));
    const pre = z.python ? "__" : "";
    [[pre + "figur", ""], [pre + "zeile", "3"], [pre + "spalte", "3"]].forEach(([n, w], i) => {
      const y = KARTE.y + KARTE.kopf + KARTE.zeile * i + 24;
      karte.append(s("text", { x: KARTE.x + 16, y, class: "fachname" }, n), s("text", { x: KARTE.x + 150, y, class: "fachwert" }, w));
    });
    // der Zettel -- ein Wort. Haengt das Fach an der Dame, liegt er im Papierkorb (er fliegt im Bogen hinein).
    const weg = zettelWeg();
    const heim = { x: ZETTEL.x + ZETTEL.b / 2, y: ZETTEL.y + ZETTEL.h / 2 }, imKorb = { x: KORB.x + KORB.b / 2, y: KORB.y + 6 };
    const zx = heim.x + (imKorb.x - heim.x) * weg, zy = heim.y + (imKorb.y - heim.y) * weg - Math.sin(Math.PI * weg) * 46;
    const zettel = s("g", { class: "zettel" + (weg === 1 ? " weg" : "") + (ziehen && trifft(ziehen) === "zettel" ? " ziel" : ""),
      transform: "translate(" + zx.toFixed(1) + " " + zy.toFixed(1) + ") rotate(" + (18 * weg).toFixed(1) + ") scale(" + (1 - .42 * weg).toFixed(3) + ")",
      opacity: (1 - .35 * weg).toFixed(2) });
    zettel.append(s("path", { d: "M" + (-ZETTEL.b / 2) + " " + (-ZETTEL.h / 2) + " h" + (ZETTEL.b - 20) + " l20 20 v" + (ZETTEL.h - 20) + " h-" + ZETTEL.b + " Z" }),
      s("text", { x: 0, y: 7 }, '"Dame"'));
    // der Papierkorb: hinten der Rand, vorn der Korb -- der Zettel steckt dazwischen
    const korbHinten = s("g", { class: "korb" });
    korbHinten.append(s("ellipse", { cx: KORB.x + KORB.b / 2, cy: KORB.y + 16, rx: KORB.b / 2, ry: 9 }));
    const korbVorn = s("g", { class: "korb" });
    korbVorn.append(s("path", { d: "M" + KORB.x + " " + (KORB.y + 16) + " Q" + (KORB.x + KORB.b / 2) + " " + (KORB.y + 30) + " " + (KORB.x + KORB.b) + " " + (KORB.y + 16)
        + " L" + (KORB.x + KORB.b - 13) + " " + (KORB.y + KORB.h) + " H" + (KORB.x + 13) + " Z" }),
      ...[.3, .5, .7].map(a => s("line", { x1: KORB.x + KORB.b * a, y1: KORB.y + 30 - Math.abs(a - .5) * 14, x2: KORB.x + 13 + (KORB.b - 26) * a, y2: KORB.y + KORB.h - 3 })));
    // die Schilder
    const sd = schild(470, 410, "dame"), sz = schild(446, KARTE.y + 4, "zug");
    const fd = faden(sd.links, { x: m.x + 4, y: m.y + 14 }, "variable");
    const fz = s("path", { d: "M" + sz.rechts.x + " " + sz.rechts.y + " L" + KARTE.x + " " + sz.rechts.y, class: "faden variable" });
    // das Fach figur -- sein Ende ist der Griff
    const ende = ziehen ? ziehen : zielPunkt(z.fach);
    const ff = fachFaden(griff, ende, "fach" + (ziehen ? " zieht" : "") + (!ziehen && z.fach === "zettel" ? " wort" : ""));
    const knoten = s("circle", { cx: griff.x, cy: griff.y, r: 7, class: "griff" });
    const endpunkt = s("circle", { cx: ende.x, cy: ende.y, r: 9, class: "ende", tabindex: 0, role: "button", "aria-label": "Ende des Fachs figur: ziehen zum Umhängen" });
    flaeche.append(fd, fz, karte, korbHinten, zettel, korbVorn, fig, ff, sd.g, sz.g, knoten, endpunkt);
  }
  function antwortZeigen() {
    const a = z.antwort;
    antwortEl.textContent = "";
    antwortEl.className = "antwort" + (a ? (a.fehler ? " fehler" : " gut") : " leer");
    if (!a) { antwortEl.textContent = z.python ? "Hier steht gleich, was Python antwortet." : "Hier steht gleich, wer antwortet."; return; }
    antwortEl.append(h("span", "frage", z.python ? a.py : a.ohne), h("span", "pfeil", "→"), h("span", "wert", z.python ? a.pyAntwort : a.ohneAntwort));
  }
  function knoepfe() {
    aktionen.textContent = "";
    const k = (ohne, py, tun, titel) => { const b = h("button", z.python ? "code" : "", z.python ? py : ohne); if (titel) b.title = titel; b.onclick = () => { if (!lauf && !wurf) tun(true); }; aktionen.append(b); return b; };
    k("Frag die Figur im Zug: Zeile?", "zug.get_figur().get_zeile()", frage);
    k("Frag dame: Zeile?", "dame.get_zeile()", frageDame);
    k("Zug ausführen", "zug.ausfuehren()", ausfuehren);
    k("Fach figur umhängen", z.fach === "zettel" ? "zug = Zug(dame, 3, 3)" : 'zug = Zug("Dame", 3, 3)',
      () => umhaengen(z.fach === "zettel" ? "figur" : "zettel"), "Dasselbe wie das Ende des Fadens ziehen");
  }
  function protokollZeigen() {
    protokollEl.hidden = !z.python;
    const kopf = ['dame = Figur("Dame", "weiß", ' + START.zeile + ", " + START.spalte + ")",
      z.fach === "zettel" ? 'zug = Zug("Dame", 3, 3)' : "zug = Zug(dame, 3, 3)"];
    protokollEl.textContent = kopf.concat(z.protokoll).join("\n");
    protokollEl.scrollTop = 1e6;
  }
  function alles() {
    zeichnen(); antwortZeigen(); knoepfe(); protokollZeigen();
    schalter.textContent = z.python ? "ohne Python" : "als Python zeigen";
  }

  // ─── Handgriffe ────────────────────────────────────────────────────────────────────
  function antworte(ohne, py, ohneAntwort, pyAntwort, fehler) {
    z.antwort = { ohne, py, ohneAntwort, pyAntwort, fehler: !!fehler };
    z.protokoll.push(">>> " + py, pyAntwort);
  }
  function frage() {
    merken();
    if (z.fach === "zettel") antworte("die Figur im Zug, Zeile?", "zug.get_figur().get_zeile()", "Der Zettel „Dame“ ist ein Wort – ein Wort hat kein Feld.", "AttributeError: 'str' object has no attribute 'get_zeile'", true);
    else antworte("die Figur im Zug, Zeile?", "zug.get_figur().get_zeile()", "Die Dame antwortet: " + z.zeile, String(z.zeile));
    meldung.textContent = ""; alles();
  }
  function frageDame() {
    merken();
    antworte("dame, Zeile?", "dame.get_zeile()", "Die Dame antwortet: " + z.zeile, String(z.zeile));
    meldung.textContent = ""; alles();
  }
  function umhaengen(ziel, animiert) {
    if (ziel !== "figur" && ziel !== "zettel") return;
    if (ziel === z.fach) { alles(); return; }
    merken();
    z.fach = ziel; z.antwort = null; z.protokoll = [];
    meldung.className = "meldung";
    meldung.textContent = ziel === "figur" ? "Das Fach figur hängt jetzt an der Dame auf dem Brett – den Zettel braucht niemand mehr."
      : "Der Zettel liegt wieder auf dem Tisch, das Fach figur hängt an ihm.";
    if (animiert !== false && !RUHIG) {
      wurf = { hin: ziel === "figur", t0: performance.now() };
      const schritt = () => { if (!wurf) return; zeichnen(); if (performance.now() - wurf.t0 < WURF_MS) requestAnimationFrame(schritt); else { wurf = null; alles(); } };
      alles(); requestAnimationFrame(schritt);
    } else alles();
  }
  function ausfuehren(animiert) {
    merken();
    if (z.fach === "zettel") {
      antworte("Zug ausführen", "zug.ausfuehren()", "Der Zug sagt dem Zettel: zieh! – ein Wort kann nicht ziehen.", "AttributeError: 'str' object has no attribute 'ziehen'", true);
      alles(); return;
    }
    const von = { zeile: z.zeile, spalte: z.spalte };
    z.zeile = ZIEL.zeile; z.spalte = ZIEL.spalte;
    z.antwort = { ohne: "Zug ausführen", py: "zug.ausfuehren()", ohneAntwort: "Der Zug sagt seiner Figur: zieh nach (3, 3).", pyAntwort: "", fehler: false };
    z.protokoll.push(">>> zug.ausfuehren()");
    meldung.className = "meldung"; meldung.textContent = "";
    if (animiert && !RUHIG && (von.zeile !== z.zeile || von.spalte !== z.spalte)) {
      lauf = { von, nach: { zeile: z.zeile, spalte: z.spalte }, t0: performance.now() };
      const schritt = () => { if (!lauf) return; zeichnen(); if (performance.now() - lauf.t0 < 700) requestAnimationFrame(schritt); else { lauf = null; alles(); } };
      knoepfe(); antwortZeigen(); protokollZeigen(); requestAnimationFrame(schritt);
    } else alles();
  }
  function rueckgaengig() {
    if (lauf || !zurueck.length) return;
    wurf = null;
    const py = z.python; z = zurueck.pop(); z.python = py; meldung.textContent = ""; alles();
  }
  function vonVorne() { lauf = null; wurf = null; ziehen = null; const py = z.python; z = neu(); z.python = py; zurueck = []; meldung.textContent = ""; alles(); }

  schalter.onclick = () => { z.python = !z.python; alles(); };
  vonVorn.onclick = vonVorne;

  // ─── Ziehen ────────────────────────────────────────────────────────────────────────
  function punkt(ev) {
    const p = flaeche.createSVGPoint(); p.x = ev.clientX; p.y = ev.clientY;
    const m = flaeche.getScreenCTM(); return m ? p.matrixTransform(m.inverse()) : { x: 0, y: 0 };
  }
  flaeche.addEventListener("pointerdown", ev => {
    if (lauf || wurf) return;
    const p = punkt(ev), e = zielPunkt(z.fach);
    const nah = (a, b) => Math.hypot(a.x - b.x, a.y - b.y) < 18;
    if (!nah(p, e) && !nah(p, griff)) return;
    ev.preventDefault(); flaeche.setPointerCapture(ev.pointerId);
    ziehen = { x: p.x, y: p.y }; zeichnen();
  });
  flaeche.addEventListener("pointermove", ev => { if (!ziehen) return; const p = punkt(ev); ziehen = { x: p.x, y: p.y }; zeichnen(); });
  flaeche.addEventListener("pointerup", () => {
    if (!ziehen) return;
    const ziel = trifft(ziehen); ziehen = null;
    if (ziel) umhaengen(ziel); else { meldung.className = "meldung"; meldung.textContent = "Ein Fach hängt immer an einem Ding – das Ende bleibt, wo es war."; zeichnen(); }
  });
  flaeche.addEventListener("keydown", ev => {
    if ((ev.key === "Enter" || ev.key === " ") && ev.target.classList && ev.target.classList.contains("ende")) {
      ev.preventDefault(); umhaengen(z.fach === "zettel" ? "figur" : "zettel");
    }
  });
  wurzel.tabIndex = -1;
  wurzel.addEventListener("keydown", ev => {
    if (ev.key === "Escape" && ziehen) { ziehen = null; zeichnen(); }
    else if ((ev.metaKey || ev.ctrlKey) && ev.key.toLowerCase() === "z") { ev.preventDefault(); rueckgaengig(); }
  });

  alles();

  // ─── Film (Vortrag, wie der Code-Film) ─────────────────────────────────────────────
  function filmSchritt(x, animiert) {
    if (x.aktion === "frage") frage();
    else if (x.aktion === "dame") frageDame();
    else if (x.aktion === "umhaengen") umhaengen(x.wert, animiert);
    else if (x.aktion === "ausfuehren") ausfuehren(animiert);
    else if (x.aktion === "python") { z.python = true; alles(); }
    else if (x.aktion === "neu") vonVorne();
  }
  function filmHerstellen(liste) {
    lauf = null; wurf = null; ziehen = null; z = neu(); zurueck = []; meldung.textContent = "";
    liste.forEach(x => filmSchritt(x, false));
    alles();
  }
  return { zustand: () => kopie(z), film: { spielen: x => filmSchritt(x, true), herstellen: filmHerstellen, laeuft: () => !!lauf || !!wurf } };
};
window.Werkstaetten.namensschilder.einleitung = "Ein Objekt gibt es nur einmal – Variablen und Attribute sind Schilder, die daran hängen. Zieht das Ende des Fachs figur an ein anderes Ding, fragt nach, führt den Zug aus. Dann „als Python zeigen“.";
