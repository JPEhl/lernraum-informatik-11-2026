// Werkstatt "Grundriss" -- der erste Stock der Schule bei Nacht als Grundriss; jeder Raum steckt mit vier Steckern am
// Flur: name · beschreibung() · befehle() · antwort(befehl, rucksack). i11 projekt/verabredung (18.11.2026). Drei
// Attrappen (geheim/planung/werkstatt_attrappen/krypto_attrappen.html, Kapitel 5: A Grundriss · B Verabredung am Tisch
// · C …); Lehrerwahl 18.11.: „Entscheide du alles“ -- Fassung A, dazu sein Wunsch nach mehr Enaktivität am Rechner und
// Ausprobieren MIT Auftrag (ENTSCHEIDUNGEN.md daneben).
//   * Geprueft wird der ECHTE Code: Die Werkstatt schickt je Raum nur den Dateinamen an den Kursserver
//     (api grundriss/pruefen), der laedt die Datei wie der Selbstcheck im Unterprozess (kursserver/grundriss.py) und
//     fragt den Raum, wie das Spiel ihn fragt. Rot heisst: Hier weicht der Raum von der Verabredung ab -- mit Grund.
//   * Sind alle vier Stecker gruen, ist die Tuer offen, und der Rundgang geht hinein: Beschreibung und die Antworten
//     des Raums auf seine Befehle, so wie das Spiel sie zeigen wuerde.
//   * Ob ein Name doppelt ist, weiss nur, wer alle Raeume sieht: Das prueft die Werkstatt selbst (spaeterer Raum rot).
//   * Sie liest neu, wenn das Fenster wieder nach vorn kommt (die Datei ist inzwischen gespeichert), und auf „neu prüfen“.
// Optionen (bauen.py): thema (Kennung) · ort "arbeit" (Python-Ordner der Uebung) | "vortrag" (Dateien des Vortrags) ·
//   raeume "sekretariat|aula|…" oder Liste (ohne .py) · wahl (der Raum, der zuerst offen ist) · vergeben (Namen im
//   Erdgeschoss, getrennt mit |) · api (nur fuer die Probe: eine Funktion statt des Servers)
// Einbinden: Werkstaetten.grundriss(element, opt) -> { zustand, neu }
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.grundriss = function (wurzel, opt) {
  opt = opt || {};
  const NS = (() => { const d = document.createElement("div"); d.innerHTML = "<svg></svg>"; return d.firstChild.namespaceURI; })();
  const STECKER = ["name", "beschreibung()", "befehle()", "antwort(befehl, rucksack)"];
  const UNTEN = String(opt.vergeben || "flur|informatikraum|lehrerzimmer|bibliothek|keller|hausmeisterraum|tor|gang")
    .split("|").map(x => x.trim()).filter(Boolean);
  const liste = Array.isArray(opt.raeume) ? opt.raeume : String(opt.raeume || "").split("|");
  const raeume = liste.map(x => String(x).trim().replace(/\.py$/, "")).filter(Boolean);
  const ort = opt.ort === "vortrag" ? "vortrag" : "arbeit";
  const frage = typeof opt.api === "function" ? opt.api : (name, daten) => api(name, daten);

  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const s = (tag, at, text) => { const e = document.createElementNS(NS, tag); for (const k in at) e.setAttribute(k, at[k]); if (text != null) e.textContent = text; return e; };
  const strich = t => String(t || "").replace(/ -- /g, " – ");
  const gross = w => w ? w.charAt(0).toUpperCase() + w.slice(1) : w;

  stil();
  wurzel.textContent = "";
  wurzel.classList.add("grundriss");
  const z = { raeume: raeume.map(d => ({ datei: d + ".py", stamm: d, ergebnis: null, fehler: "" })), wahl: 0, rundgang: false, laeuft: false };
  const start = opt.wahl ? raeume.indexOf(String(opt.wahl).replace(/\.py$/, "")) : -1;
  if (start >= 0) z.wahl = start;

  const kopf = h("div", "gr-kopf");
  const zaehler = h("span", "gr-zaehler");
  const neuKnopf = h("button", "ruhig", "neu prüfen"); neuKnopf.type = "button";
  neuKnopf.onclick = () => pruefen();
  kopf.append(zaehler, neuKnopf);
  const tisch = h("div", "gr-tisch");
  const plan = s("svg", { class: "gr-plan", role: "group", "aria-label": "Grundriss des ersten Stocks" });
  const panel = h("div", "gr-panel"); panel.setAttribute("role", "region"); panel.setAttribute("aria-live", "polite");
  tisch.append(plan, panel);
  const kuerzel = h("p", "gr-kuerzel", "Klick auf einen Raum: seine Stecker · Pfeiltasten: der nächste Raum · Rundgang, wenn die Tür offen ist");
  wurzel.append(kopf, tisch, kuerzel);
  if (!raeume.length) { panel.append(h("p", "gr-hinweis", "Im Grundriss steht kein Raum.")); return { zustand: () => kopie(), neu: () => Promise.resolve() }; }

  // ─── rechnen ───────────────────────────────────────────────────────────────────────
  function anzeigeName(r) {
    const e = r.ergebnis;
    if (e && e.name && /^[a-zäöüß]+$/.test(e.name)) return gross(e.name);
    return r.stamm === "meinraum" ? "Euer Raum" : gross(r.stamm);
  }
  // die vier Stecker eines Raums, mit dem, was nur die Werkstatt sieht: ein Name, den schon ein anderer Raum trägt
  function stecker(i) {
    const r = z.raeume[i], e = r.ergebnis;
    if (!e) return STECKER.map(n => ({ stecker: n, ok: null, grund: r.fehler ? "" : "wird geprüft …" }));
    const st = (e.stecker && e.stecker.length === 4 ? e.stecker : STECKER.map(n => ({ stecker: n, ok: null, grund: "" }))).map(x => Object.assign({}, x));
    if (st[0].ok && e.name) {
      const frueher = z.raeume.slice(0, i).find(x => x.ergebnis && x.ergebnis.name === e.name && !x.ergebnis.leer);
      if (frueher) Object.assign(st[0], { ok: false, grund: "Den Namen „" + e.name + "“ trägt schon " + anzeigeName(frueher) + " (" + frueher.datei + ") – geh fände nur einen von beiden." });
      else if (UNTEN.includes(e.name)) Object.assign(st[0], { ok: false, grund: "„" + e.name + "“ heißt schon ein Raum im Erdgeschoss – wählt einen anderen Namen." });
    }
    return st;
  }
  function lage(i) {
    const r = z.raeume[i], e = r.ergebnis;
    if (r.fehler) return "fehler";
    if (!e) return "pruefen";
    if (e.leer) return "leer";
    if (e.laden) return "zu";
    return stecker(i).every(x => x.ok) ? "offen" : "zu";
  }
  function kopie() {
    return { wahl: z.wahl, rundgang: z.rundgang, raeume: z.raeume.map((r, i) => ({ datei: r.datei, name: anzeigeName(r), lage: lage(i), fehler: r.fehler, laden: r.ergebnis ? r.ergebnis.laden : null, stecker: stecker(i) })) };
  }

  // ─── fragen ────────────────────────────────────────────────────────────────────────
  let runde = 0;
  async function pruefen() {
    const meine = ++runde;
    z.laeuft = true; zeichnen();
    await Promise.all(z.raeume.map(async r => {
      try { const e = await frage("grundriss/pruefen", { thema: opt.thema || "", ort, datei: r.datei }); if (meine === runde) { r.ergebnis = e; r.fehler = ""; } }
      catch (err) { if (meine === runde) { r.ergebnis = null; r.fehler = (err && err.message) || String(err); } }
    }));
    if (meine !== runde) return;
    z.laeuft = false;
    if (z.rundgang && lage(z.wahl) !== "offen") z.rundgang = false;
    zeichnen();
  }

  // ─── zeichnen ──────────────────────────────────────────────────────────────────────
  const B = 760, RAND = 8, LUECKE = 10, HOCH = 128, FLUR = 46;
  function zeichnen() {
    const fokus = document.activeElement && plan.contains(document.activeElement) ? document.activeElement.dataset.i : null;
    // bis drei Raeume eine Reihe ueber dem Gang (der Vortrag: zwei), sonst zwei Reihen; die Treppe nimmt den letzten Platz
    const n = z.raeume.length, reihen = n <= 3 ? 1 : 2, spalten = reihen === 1 ? n + 1 : Math.ceil((n + 1) / 2);
    const breit = (B - 2 * RAND - (spalten - 1) * LUECKE) / spalten;
    const H = 2 * RAND + reihen * HOCH + FLUR + (reihen === 1 ? 6 : 0);
    plan.setAttribute("viewBox", "0 0 " + B + " " + H);
    plan.textContent = "";
    const yFlur = RAND + HOCH;
    plan.append(s("rect", { x: 2, y: 2, width: B - 4, height: H - 4, rx: 18, class: "gr-wand" }));
    plan.append(s("rect", { x: RAND, y: yFlur, width: B - 2 * RAND, height: FLUR, class: "gr-flur" }));
    plan.append(s("text", { x: B / 2, y: yFlur + FLUR / 2 + 5, class: "gr-flurtext", "text-anchor": "middle" }, "Gang im ersten Stock"));
    const platz = k => { const oben = k < spalten, sp = oben ? k : k - spalten; return { x: RAND + sp * (breit + LUECKE), y: oben ? RAND : yFlur + FLUR, oben }; };
    const t = platz(reihen * spalten - 1);
    const treppe = s("g", { class: "gr-treppe" });
    treppe.append(s("rect", { x: t.x, y: t.y, width: breit, height: HOCH, rx: 12 }));
    for (let k = 0; k < 5; k++) treppe.append(s("line", { x1: t.x + 18, x2: t.x + breit - 18, y1: t.y + 30 + k * 15, y2: t.y + 30 + k * 15 }));
    treppe.append(s("text", { x: t.x + breit / 2, y: t.y + HOCH - 14, "text-anchor": "middle" }, "Treppe ins Erdgeschoss"));
    plan.append(treppe);
    z.raeume.forEach((r, i) => {
      const p = platz(i), l = lage(i), st = stecker(i), gewaehlt = i === z.wahl;
      const g = s("g", { class: "gr-raum gr-" + l + (gewaehlt ? " gr-gewaehlt" : ""), tabindex: "0", role: "button", "data-i": String(i),
        "aria-pressed": String(gewaehlt), "aria-label": anzeigeName(r) + ", " + r.datei + ": " + ({ offen: "Tür offen, alle vier Stecker passen", leer: "noch leer", pruefen: "wird geprüft", fehler: "nicht geprüft" }[l] || ("Tür zu, " + (st.filter(x => x.ok === false).length || "kein") + " Stecker rot")) });
      g.append(s("rect", { x: p.x, y: p.y, width: breit, height: HOCH, rx: 12, class: "gr-boden" }));
      g.append(s("text", { x: p.x + 14, y: p.y + 31, class: "gr-name" }, anzeigeName(r)));
      const unter = r.stamm === "meinraum" ? "meinraum.py · euer Raum" : wer(r) || r.datei;
      g.append(passend(s("text", { x: p.x + 14, y: p.y + 53, class: "gr-wer" }, unter), breit - 28));
      if (l === "leer") g.append(s("text", { x: p.x + 14, y: p.y + 92, class: "gr-leertext" }, "noch leer"));
      else st.forEach((x, j) => { const k = s("circle", { cx: p.x + 24 + j * 27, cy: p.y + 90, r: 9.5, class: "gr-stecker " + (x.ok === true ? "gr-ja" : x.ok === false ? "gr-nein" : "gr-offen") }); k.append(s("title", {}, x.stecker)); g.append(k); });
      if (l === "zu" && r.ergebnis && r.ergebnis.laden) g.append(s("text", { x: p.x + 14, y: p.y + 118, class: "gr-ladentext" }, "lässt sich nicht einstecken"));
      // die Tuer wie im Bauplan: eine Luecke in der Wand zum Gang; zu = der Fluegel liegt in der Luecke, offen = er
      // steht in den Raum hinein, der Bogen zeigt, wie er aufging (rechts, frei von den Steckern)
      const tb = 40, tx = p.x + breit - tb - 22, wy = p.oben ? p.y + HOCH : p.y, rein = p.oben ? -1 : 1;
      g.append(s("rect", { x: tx, y: wy - 3, width: tb, height: 6, class: "gr-tuerspalt" }));
      if (l === "offen") {
        g.append(s("path", { d: "M " + (tx + tb) + " " + wy + " A " + tb + " " + tb + " 0 0 " + (p.oben ? 0 : 1) + " " + tx + " " + (wy + rein * tb), class: "gr-bogen" }));
        g.append(s("rect", { x: tx - 3, y: Math.min(wy, wy + rein * tb), width: 6, height: tb, rx: 2, class: "gr-tuer" }));
      } else g.append(s("rect", { x: tx, y: wy - 3, width: tb, height: 6, rx: 2, class: "gr-tuer" }));
      g.addEventListener("click", () => waehlen(i));
      g.addEventListener("keydown", ev => {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); waehlen(i); }
        else if (ev.key === "ArrowRight" || ev.key === "ArrowDown") { ev.preventDefault(); waehlen((i + 1) % n, true); }
        else if (ev.key === "ArrowLeft" || ev.key === "ArrowUp") { ev.preventDefault(); waehlen((i + n - 1) % n, true); }
      });
      g.addEventListener("mousedown", ev => ev.preventDefault());      // kein markierter Text beim Klicken
      plan.append(g);
    });
    const offen = z.raeume.filter((r, i) => lage(i) === "offen").length;
    zaehler.textContent = z.laeuft && !z.raeume.some(r => r.ergebnis) ? "Die Räume werden geprüft …" : "Türen offen: " + offen + " von " + n;
    neuKnopf.disabled = z.laeuft;
    tafel();
    if (fokus != null) { const f = plan.querySelector('[data-i="' + fokus + '"]'); if (f) f.focus({ preventScroll: true }); }
  }
  // wer den Raum gebaut hat, aus dem Kopfkommentar („der Raum von Kofi und Jule“ -> „von Kofi und Jule“)
  const wer = r => ((r.ergebnis && r.ergebnis.kopf) || "").replace(/^der Raum (?=von )/, "");
  // ein Text im Raum, der nicht hineinpasst, endet mit „…“ (gemessen, sobald der Grundriss auf der Seite steht)
  function passend(el, platz) {
    requestAnimationFrame(() => {
      if (!el.isConnected || !el.getComputedTextLength) return;
      let text = el.textContent;
      while (text.length > 4 && el.getComputedTextLength() > platz) { text = text.slice(0, -1); el.textContent = text.trimEnd() + "…"; }
    });
    return el;
  }
  function waehlen(i, fokus) {
    if (z.wahl !== i) z.rundgang = false;
    z.wahl = i; zeichnen();
    if (fokus) { const f = plan.querySelector('[data-i="' + i + '"]'); if (f) f.focus({ preventScroll: true }); }
  }
  function tafel() {
    panel.textContent = "";
    const i = z.wahl, r = z.raeume[i], e = r.ergebnis, l = lage(i);
    const titel = h("h3", "", anzeigeName(r));
    const von = r.stamm === "meinraum" ? "euer Raum" : wer(r);
    panel.append(titel, h("p", "gr-datei", (von ? von + " · " : "") + r.datei));
    if (r.fehler) { panel.append(h("p", "gr-banner", "Nicht geprüft: " + r.fehler)); return; }
    if (!e) { panel.append(h("p", "gr-hinweis", "Der Raum wird geprüft …")); return; }
    if (e.leer) {
      panel.append(h("p", "gr-hinweis", "In " + r.datei + " steht noch nichts außer dem Kopf. Sobald dort steht, was die Verabredung verlangt, steckt der Grundriss den Raum ein."));
      return;
    }
    if (e.laden) panel.append(h("p", "gr-banner", strich(e.laden)));
    const ul = h("ul", "gr-liste");
    stecker(i).forEach(x => {
      const li = h("li", x.ok === true ? "gr-ja" : x.ok === false ? "gr-nein" : "gr-offen");
      li.append(h("span", "gr-ampel"), h("code", "", x.stecker));
      li.append(h("span", "gr-grund", x.ok === true ? "passt" : x.ok === false ? strich(x.grund) : "nicht geprüft"));
      ul.append(li);
    });
    panel.append(ul);
    panel.append(h("p", "gr-satz gr-" + l, l === "offen" ? "Alle vier Stecker passen: Die Tür ist offen." : "Die Tür bleibt zu, bis alle vier Stecker passen."));
    const rk = h("button", "primaer", z.rundgang ? "Rundgang schließen" : "Rundgang"); rk.type = "button";
    rk.disabled = l !== "offen";
    rk.title = l === "offen" ? "So zeigt das Spiel den Raum" : "Erst wenn alle vier Stecker passen";
    rk.onclick = () => { z.rundgang = !z.rundgang; zeichnen(); };
    const knoepfe = h("div", "gr-knoepfe"); knoepfe.append(rk); panel.append(knoepfe);
    if (z.rundgang && e.rundgang) {
      const rg = e.rundgang, box = h("div", "gr-rundgang");
      box.setAttribute("aria-label", "Rundgang durch " + anzeigeName(r));
      const zeile = (art, text) => box.append(h("div", "gr-z " + art, text));
      zeile("ein", "> geh " + (e.name || r.stamm));
      zeile("aus", rg.beschreibung);
      (rg.schritte || []).forEach(([b, a]) => { zeile("ein", "> " + b); zeile("aus", a); });
      zeile("rest", "Im Rucksack: " + (rg.rucksack || []).join(", "));
      panel.append(box);
    }
  }

  // ─── Stile (eigene Klassen, Farben aus seite.css) ──────────────────────────────────
  function stil() {
    if (document.getElementById("gr-stil")) return;
    const st = document.createElement("style"); st.id = "gr-stil";
    st.textContent = [
      ".grundriss { display: grid; gap: .7em; container-type: inline-size; }",
      ".grundriss .gr-kopf { display: flex; gap: .8em; align-items: center; flex-wrap: wrap; }",
      ".grundriss .gr-zaehler { font-family: var(--chip); font-size: 1.25em; letter-spacing: .04em; text-transform: uppercase; color: var(--grau); }",
      ".grundriss .gr-tisch { display: grid; grid-template-columns: minmax(0, 1.7fr) minmax(300px, 1fr); gap: 1.1em; align-items: start; }",
      // schmaler als der Reiter (im Vortrag neben dem Text, am Handy): die Tafel unter den Grundriss, die Stecker zweispaltig
      "@container (max-width: 980px) { .grundriss .gr-tisch { grid-template-columns: 1fr; } }",
      "@container (min-width: 620px) and (max-width: 980px) { .grundriss .gr-liste { grid-template-columns: 1fr 1fr; column-gap: 1.4em; align-items: start; } }",
      ".grundriss .gr-plan { width: 100%; height: auto; user-select: none; -webkit-user-select: none; display: block; }",
      ".grundriss .gr-plan text { pointer-events: none; font-family: var(--sans); }",
      ".grundriss .gr-wand { fill: var(--karte); stroke: var(--grau); stroke-width: 3; }",
      ".grundriss .gr-flur { fill: var(--linie); }",
      ".grundriss .gr-flurtext { font-size: 15px; fill: var(--grau); letter-spacing: .06em; }",
      ".grundriss .gr-treppe rect { fill: var(--papier); stroke: var(--linie); stroke-width: 1.5; }",
      ".grundriss .gr-treppe line { stroke: var(--grau-hell); stroke-width: 3; stroke-linecap: round; }",
      ".grundriss .gr-treppe text { font-size: 14px; fill: var(--grau); }",
      ".grundriss .gr-raum { cursor: pointer; outline: none; }",
      ".grundriss .gr-boden { fill: var(--karte); stroke: var(--linie); stroke-width: 1.5; transition: fill var(--uebergang), stroke var(--uebergang); }",
      ".grundriss .gr-raum.gr-offen .gr-boden { fill: var(--mint-hell); stroke: var(--mint); }",
      ".grundriss .gr-raum.gr-zu .gr-boden { fill: var(--koralle-hell); stroke: #f3b9a8; }",
      ".grundriss .gr-raum.gr-leer .gr-boden { fill: var(--papier); stroke: var(--grau-hell); stroke-dasharray: 6 5; }",
      ".grundriss .gr-raum.gr-gewaehlt .gr-boden { stroke: var(--tinte); stroke-width: 2.6; }",
      ".grundriss .gr-raum:focus-visible .gr-boden { stroke: var(--blau); stroke-width: 3.5; }",
      ".grundriss .gr-raum:hover .gr-boden { stroke-width: 2.6; }",
      ".grundriss .gr-name { font-size: 22px; font-weight: 700; fill: var(--tinte); }",
      ".grundriss .gr-wer { font-size: 14.5px; fill: var(--grau); }",
      ".grundriss .gr-leertext, .grundriss .gr-ladentext { font-size: 14.5px; fill: var(--grau); font-style: italic; }",
      ".grundriss .gr-ladentext { fill: var(--rot); }",
      ".grundriss .gr-stecker { stroke: var(--karte); stroke-width: 2; }",
      ".grundriss .gr-stecker.gr-ja { fill: var(--mint); } .grundriss .gr-stecker.gr-nein { fill: var(--koralle); } .grundriss .gr-stecker.gr-offen { fill: var(--grau-hell); }",
      ".grundriss .gr-tuerspalt { fill: var(--linie); }",
      ".grundriss .gr-tuer { fill: var(--grau); }",
      ".grundriss .gr-raum.gr-zu .gr-tuer { fill: var(--koralle); }",
      ".grundriss .gr-raum.gr-leer .gr-tuer { fill: var(--grau-hell); }",
      ".grundriss .gr-raum.gr-offen .gr-tuer { fill: var(--mint); }",
      ".grundriss .gr-bogen { fill: none; stroke: var(--mint); stroke-width: 1.5; stroke-dasharray: 4 4; }",
      ".grundriss .gr-panel { background: var(--karte); border: 1px solid var(--linie); border-radius: var(--radius-klein); padding: .8em 1em 1em; display: grid; gap: .45em; min-width: 0; }",
      ".grundriss .gr-panel h3 { margin: 0; font-family: var(--rund); font-weight: 400; font-size: 1.3em; }",
      ".grundriss .gr-datei { margin: 0; color: var(--grau); font-size: .9em; }",
      ".grundriss .gr-liste { list-style: none; margin: .2em 0 0; padding: 0; display: grid; gap: .45em; }",
      ".grundriss .gr-liste li { display: grid; grid-template-columns: .8em auto minmax(0, 1fr); column-gap: .55em; align-items: baseline; }",
      ".grundriss .gr-liste li code { font-size: .95em; font-weight: 600; justify-self: start; }",
      ".grundriss .gr-grund { font-size: .93em; line-height: 1.4; overflow-wrap: anywhere; }",
      ".grundriss .gr-liste li.gr-nein .gr-grund { grid-column: 2 / 4; margin-top: .15em; }",
      ".grundriss .gr-liste li.gr-ja .gr-grund, .grundriss .gr-liste li.gr-offen .gr-grund { color: var(--grau); }",
      ".grundriss .gr-ampel { width: .78em; height: .78em; border-radius: 50%; background: var(--grau-hell); transform: translateY(.08em); }",
      ".grundriss li.gr-ja .gr-ampel { background: var(--mint); } .grundriss li.gr-nein .gr-ampel { background: var(--koralle); }",
      ".grundriss .gr-satz { margin: .3em 0 0; font-weight: 600; } .grundriss .gr-satz.gr-offen { color: var(--mint); } .grundriss .gr-satz.gr-zu { color: var(--koralle); }",
      ".grundriss .gr-banner { margin: 0; background: var(--koralle-hell); border-radius: 10px; padding: .45em .7em; font-size: .93em; overflow-wrap: anywhere; }",
      ".grundriss .gr-hinweis { margin: 0; color: var(--grau); }",
      ".grundriss .gr-knoepfe { display: flex; gap: .5em; flex-wrap: wrap; }",
      ".grundriss .gr-rundgang { font-family: var(--mono); font-size: .9em; background: var(--blau-zart); border: 1px solid var(--linie); border-radius: 10px; padding: .55em .75em; display: grid; gap: .2em; overflow-wrap: anywhere; }",
      ".grundriss .gr-z.ein { color: var(--blau); } .grundriss .gr-z.rest { color: var(--grau); margin-top: .2em; }",
      ".grundriss .gr-kuerzel { margin: 0; color: var(--grau); font-size: .85em; }",
      "@media (prefers-reduced-motion: reduce) { .grundriss .gr-boden { transition: none; } }"
    ].join("\n");
    document.head.append(st);
  }

  // neu lesen, wenn die Seite wieder nach vorn kommt (die Datei ist inzwischen gespeichert) -- solange die Werkstatt steht
  const wieder = () => { if (!wurzel.isConnected) { document.removeEventListener("visibilitychange", wieder); window.removeEventListener("focus", wieder); return; } if (!document.hidden && !z.laeuft) pruefen(); };
  document.addEventListener("visibilitychange", wieder);
  window.addEventListener("focus", wieder);
  zeichnen();
  const fertig = pruefen();
  return { zustand: () => kopie(), neu: () => pruefen(), fertig };
};
window.Werkstaetten.grundriss.einleitung = "Der erste Stock als Grundriss: Jeder Raum steckt mit vier Steckern am Gang – name, beschreibung(), befehle() und antwort(befehl, rucksack). Geprüft wird die Datei, wie sie gespeichert ist. Rot sagt, wo ein Raum von der Verabredung abweicht; sind alle vier grün, ist die Tür offen, und der Rundgang führt hinein.";
window.Werkstaetten.grundriss.kurz = "der erste Stock als Grundriss: rote Stecker zeigen, wo ein Raum nicht zur Verabredung passt.";
