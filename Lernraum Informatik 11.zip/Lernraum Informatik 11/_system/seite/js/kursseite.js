/* Lernraum · kursseite.js -- Kursseite, Anmeldung, Fassung und Aktualisierung.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Kursseite ────────────────────────────────────────────────────────────────────
function themaStandText(t, pfad) {
  const ts = (Z.stand.themen || {})[pfad] || {};
  const teile = [];
  if (ts.selbstcheck) teile.push("Selbstcheck " + ts.selbstcheck.passt + " von " + ts.selbstcheck.von);
  const hilfen = Object.entries(Z.stand.aufgaben || {}).filter(([k]) => k.startsWith(pfad + "/")).reduce((n, [, a]) => n + (a.hilfen || []).length, 0);
  if (hilfen) teile.push(hilfen + " Hilfe(n) geöffnet");
  const fragen = Object.entries(Z.stand.fragen || {}).filter(([k, f]) => k.startsWith(pfad + "/") && f.geloest).length;
  if (fragen) teile.push(fragen + " Prüffrage" + (fragen === 1 ? "" : "n") + " gelöst");
  if ((Z.stand.kennwoerter || {})[pfad]) teile.push("Lösung frei");
  return teile.length ? teile.join(" · ") : "noch nicht begonnen";
}
// Im Pult: wo der Unterricht steht, nicht dein Probestand (Lehrer 16.10.: „hier sollte nicht stehen,
// wie viele Sterne ich schon habe, sondern was wir im Unterricht schon gemacht haben“).
function zeitDe(iso) { const m = (iso || "").match(/^\d{4}-(\d\d)-(\d\d)T(\d\d:\d\d)/); return m ? m[2] + "." + m[1] + "., " + m[3] : ""; }
function unterrichtText(t, pfad) {
  const st = unterrichtStelle(pfad);
  if (!st) return "im Unterricht noch nicht dran";
  const teile = [];
  if (st.reiter === "vortrag" && st.schritt) { const s = (t.vortrag || [])[st.schritt - 1]; teile.push("Vortrag Schritt " + st.schritt + " von " + (t.vortrag || []).length + (s && s.fahrplan && st.marker ? " (" + "①②③④⑤"[st.marker - 1] + ")" : "")); }
  else teile.push({ uebung: "Übung", erklaerung: "Erklärung", werkstatt: "Werkstatt", loesung: "Lösung" }[st.reiter] || st.reiter);
  return "Im Unterricht: " + teile.join(" · ") + " · Lesezeichen vom " + zeitDe(st.zeit);
}
function weiterKarte() {
  // Das Lesezeichen (Lehrer 19.10.): nur, was er am Ende einer Stunde mit „Hier aufgehört“ gesetzt hat
  const u = Z.stand.unterricht || {}, pfad = u.zuletzt, st = pfad && unterrichtStelle(pfad);
  if (!st) return h("div", { class: "weiter-karte leer-karte nur-ohne-beamer" }, h("div", { class: "wk-kopf" }, "Beim nächsten Mal weiter"),
    h("p", { class: "leer" }, "Noch kein Lesezeichen. Setz es am Ende der Stunde mit „Hier aufgehört“ – rechts neben den Reitern eines Themas."));
  const [rk, tk] = pfad.split("/"), T = thema(rk, tk); if (!T) return null;
  let wo, ziel;
  if (st.reiter === "vortrag" && st.schritt) {
    const s = T.thema.vortrag[st.schritt - 1] || {};
    wo = "Vortrag, Schritt " + st.schritt + (s.titel ? " „" + s.titel + "“" : "") + (s.fahrplan && st.marker ? ", Fahrplan " + "①②③④⑤"[st.marker - 1] + " " + s.fahrplan[st.marker - 1].replace(/<[^>]+>/g, "") : "");
    ziel = "t/" + pfad + "/vortrag/" + st.schritt;
  } else { wo = { uebung: "Übung", erklaerung: "Erklärung", werkstatt: "Werkstatt", loesung: "Lösung" }[st.reiter] || st.reiter; ziel = "t/" + pfad + "/" + st.reiter; }
  return h("a", { class: "weiter-karte nur-ohne-beamer", href: adr(ziel) }, h("div", { class: "wk-kopf" }, "Beim nächsten Mal weiter"),
    h("div", { class: "wk-wo" }, "Thema " + T.thema.nr + " · " + T.thema.titel), h("div", {}, wo), h("div", { class: "leer" }, "Lesezeichen vom " + zeitDe(st.zeit) + " →"));
}
// Wer arbeitet hier? Ohne Namen (oder eigene Stand-ZIP) bleiben die Themen zu -- die Abgabe braucht
// den Namen, und eine Stunde ohne ihn endet mit einer Abgabe, die niemandem gehört.
function anmeldeKarte() {
  const vor = h("input", { placeholder: "Vorname", autocomplete: "off" }), nach = h("input", { placeholder: "Nachname", autocomplete: "off" });
  const datei = h("input", { type: "file", accept: ".zip" });
  const fehler = h("p", { class: "fehler" });
  const los = async () => {
    if (!vor.value.trim() || !nach.value.trim()) { fehler.textContent = "Bitte Vor- und Nachnamen eintragen."; return; }
    try { const a = await api("stand/name", { vorname: vor.value.trim(), nachname: nach.value.trim() }); Z.stand = a.stand; kopfZeichnen([]); zeichnen(); }
    catch (e) { fehler.textContent = e.message; }
  };
  nach.addEventListener("keydown", ev => { if (ev.key === "Enter") los(); });
  datei.addEventListener("change", async () => {
    const f = datei.files[0]; if (!f) return;
    try { const a = await api("stand/zusammenfuehren", { daten: await dateiB64(f) }); Z.stand = a.stand;
      if (!Z.stand.name) { fehler.textContent = "In dieser ZIP steht kein Name – trag ihn oben ein."; return; }
      meldung("Willkommen zurück, " + Z.stand.name + " – dein Stand ist da."); zeichnen(); }
    catch (e) { fehler.textContent = e.message; }
  });
  return h("div", { class: "anmelden" },
    h("h2", {}, "Wer arbeitet hier?"),
    h("p", {}, "Trag deinen Namen ein, dann gehen die Themen auf. Er steht nur hier im Ordner und in deinen Abgaben."),
    h("div", { class: "zeile" }, vor, nach, h("button", { class: "primaer", onclick: los }, "Los geht’s")),
    h("p", { class: "oder" }, "oder"),
    h("p", {}, "Du hast schon an einem anderen Rechner gearbeitet? Nimm deine Stand-ZIP herein – dein Name kommt mit: ", datei),
    fehler);
}
function kursseite(haupt) {
  kopfZeichnen([]);
  const s = h("div", { class: "seite" }, h("h1", {}, Z.inhalt.titel), Z.inhalt.untertitel ? h("p", { class: "unter" }, Z.inhalt.untertitel) : null);
  const gesperrt = !Z.stand.name && !Z.lehrer;   // Lehrer 14.10.: Themen erst mit Namen oder eigener Stand-ZIP
  if (gesperrt) s.append(anmeldeKarte());
  if (Z.lehrer) { const w = weiterKarte(); if (w) s.append(w); }
  // Dein Weg: wie viele Themen sind begonnen (Stand), als Balken -- die Lernpfad-Ansicht (13.10.)
  const alle = Z.inhalt.reihen.flatMap(r => r.themen.map(t => r.kennung + "/" + t.kennung));
  const begonnen = alle.filter(p => themaStandText(null, p) !== "noch nicht begonnen").length;
  if (!Z.lehrer) {
    const balken = h("span", {}); balken.style.width = "0";
    s.append(h("div", { class: "fortschritt nur-ohne-beamer" }, h("div", { class: "ft" }, "Dein Weg"), h("div", { class: "fz" }, begonnen + " von " + alle.length + " Themen begonnen"), h("div", { class: "fb" }, balken)));
    requestAnimationFrame(() => { balken.style.width = (alle.length ? Math.round(100 * begonnen / alle.length) : 0) + "%"; });
  }
  // Kapitel und Teile einklappen (Film der Schuelerfassung 25.10., Lehrer: „dass man die Kapitel einklappen kann“) --
  // ein Klick auf die Ueberschrift; der Browser merkt es sich je Kurs (nur Bequemlichkeit, darf fehlen)
  // vorgabeZu (Q-Phase, 24.11.2026, Lehrer „ja“): Kapitel frueherer Halbjahre beginnen eingeklappt
  function klappbar(ziel, kopf, schluessel, vorgabeZu) {
    let zu = !!vorgabeZu; try { const w = localStorage.getItem(schluessel); if (w === "zu") zu = true; else if (w === "auf") zu = false; } catch (e) {}
    kopf.classList.add("klappkopf"); kopf.tabIndex = 0; kopf.setAttribute("role", "button");
    const setzen = (wert) => { zu = wert; ziel.classList.toggle("zu", zu); kopf.classList.toggle("zu", zu); kopf.setAttribute("aria-expanded", String(!zu)); };
    const wechseln = () => { setzen(!zu); try { if (zu) localStorage.setItem(schluessel, "zu"); else if (vorgabeZu) localStorage.setItem(schluessel, "auf"); else localStorage.removeItem(schluessel); } catch (e) {} };
    kopf.addEventListener("click", wechseln);
    kopf.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); wechseln(); } });
    setzen(zu);
  }
  // Ein Lernraum je Abiturjahrgang (Q-Phase, 24.11.2026): oben das laufende Halbjahr, darunter die vergangenen
  // (neuestes zuerst), dann alle Zugaben. Spaetere Halbjahre sind gar nicht gebaut. Ohne Z.inhalt.halbjahr wie bisher.
  // Im Lehrerpult (Lehrer 24.11.2026: „im Lehrerpult aber schon immer … Q1 --> Q2 --> Q3 --> Q4 sortiert“, „per Dropdown
  // ein- und ausgeblendet“): die Halbjahre der Reihe nach, je Halbjahr ein Block mit seinen Zugaben, der Kopf klappt
  // den ganzen Block; offen ist das laufende Halbjahr.
  const hjJetzt = Z.inhalt.halbjahr, hjBloecke = !!(hjJetzt && Z.lehrer);
  let reihen = Z.inhalt.reihen;
  if (hjBloecke) {
    const hjs = [...new Set(reihen.map(r => r.halbjahr || ""))].sort();
    reihen = hjs.flatMap(hj => reihen.filter(r => (r.halbjahr || "") === hj && !r.zugabe).concat(reihen.filter(r => (r.halbjahr || "") === hj && r.zugabe)));
  } else if (hjJetzt) {
    const pflicht = reihen.filter(r => !r.zugabe);
    reihen = pflicht.filter(r => r.halbjahr === hjJetzt)
      .concat(pflicht.filter(r => r.halbjahr !== hjJetzt).sort((a, b) => (b.halbjahr || "").localeCompare(a.halbjahr || "")))
      .concat(reihen.filter(r => r.zugabe));
  }
  let hjZuletzt = null, ziel = s;
  for (const r of reihen) {
    if (hjBloecke && r.halbjahr !== hjZuletzt) {
      hjZuletzt = r.halbjahr;
      // vorbereitet (24.11.2026): ein Halbjahr, das die Klasse erst mit der naechsten Fassung bekommt -- nur hier im Pult
      const vorbereitet = !!r.vorbereitet;
      const kopf = h("div", { class: "halbjahr-kopf" + (r.halbjahr === hjJetzt ? " jetzt" : "") + (vorbereitet ? " vorbereitet" : "") }, h("span", { class: "hj-schild" }, r.halbjahr),
        h("span", {}, r.halbjahr === hjJetzt ? "jetzt" : vorbereitet ? "vorbereitet – kommt mit der nächsten Fassung an die Klasse" : "zum Nachschlagen und fürs Abitur"));
      ziel = h("div", { class: "hj-block" });
      s.append(kopf, ziel);
      klappbar(ziel, kopf, "halbjahr:" + Z.kurs + "/" + r.halbjahr, r.halbjahr !== hjJetzt && !vorbereitet);
    } else if (hjJetzt && !hjBloecke && !r.zugabe && r.halbjahr !== hjZuletzt) {
      hjZuletzt = r.halbjahr;
      s.append(h("div", { class: "halbjahr-kopf" + (r.halbjahr === hjJetzt ? " jetzt" : "") }, h("span", { class: "hj-schild" }, r.halbjahr),
        h("span", {}, r.halbjahr === hjJetzt ? "jetzt" : "zum Nachschlagen und fürs Abitur")));
    }
    // die Zugabe (LR2, 17.11.2026): unter eigener Ueberschrift, nicht als weiteres Pflichtkapitel
    if (r.zugabe && !ziel.querySelector(".weiterlernen-kopf")) ziel.append(h("div", { class: "weiterlernen-kopf" }, h("h2", {}, "Zum Weiterlernen"), h("p", {}, "Kapitel, die dazukommen, wenn Zeit bleibt.")));
    // Im Jahrgangs-Lernraum ohne „Kapitel N“ (Lehrer 24.11.: das laufende Halbjahr steht oben, Kapitel 2 vor 1)
    const kap = h("section", { class: "kapitel" + (r.zugabe ? " zugabe" : "") }, h("h2", {}, r.zugabe && r.halbjahr && !hjBloecke ? h("span", { class: "hj-schild" }, r.halbjahr) : null, (r.zugabe ? "Zugabe · " : hjJetzt ? "" : "Kapitel " + r.nr + " · ") + r.titel), r.kurz ? h("p", {}, r.kurz) : null);
    klappbar(kap, kap.querySelector("h2"), "kapitel:" + Z.kurs + "/" + r.kennung, !hjBloecke && hjJetzt && !r.zugabe && r.halbjahr !== hjJetzt);
    // die Akte (wer gefehlt hat) und die Pultseite (nur Lehrer, nie am Beamer) -- iq2 fall, 19.11.2026
    if ((r.akte && !gesperrt) || (Z.lehrer && r.pultseite)) kap.append(h("div", { class: "kapitel-seiten" },
      r.akte && !gesperrt ? h("a", { class: "knopf", href: adr("kapitel/" + r.kennung + "/akte") }, "Die Akte", h("span", {}, " – für alle, die gefehlt haben")) : null,
      Z.lehrer && r.pultseite ? h("a", { class: "knopf nur-ohne-beamer", href: adr("kapitel/" + r.kennung + "/pult") }, r.pultseite.titel, h("span", {}, " – nur du")) : null));
    // je Teil der Reihe eine Ueberschrift und eine eigene Liste (Lehrer 24.10.: „keine Trennung zwischen Teil I und II
    // … Sollte es aber geben“); ohne Teile eine Liste wie bisher
    let liste = null, teil = null;
    for (const t of r.themen) {
      if (!liste || (t.teil || "") !== teil) {
        if (liste) kap.append(liste);
        teil = t.teil || "";
        if (teil) {
          const [schild, ...rest] = teil.split(" · ");
          kap.append(h("h3", { class: "teil" }, rest.length ? h("span", { class: "teil-schild" }, schild) : null, rest.length ? rest.join(" · ") : teil));
        }
        liste = h("div", { class: "themenliste" });
        if (teil) klappbar(liste, kap.lastElementChild, "teil:" + Z.kurs + "/" + r.kennung + "/" + teil);
      }
      const pfad = r.kennung + "/" + t.kennung;
      liste.append(h(gesperrt ? "div" : "a", { class: "themenkarte" + (gesperrt ? " gesperrt" : ""), "data-pfad": pfad, href: gesperrt ? null : adr("t/" + pfad + "/vortrag"), title: gesperrt ? "Erst deinen Namen eintragen – oben" : null }, h("div", { class: "nr", "data-nr": String(t.nr) }, "Thema " + t.nr), h("div", { class: "titel" }, gesperrt ? zeichen(SCHLOSS_ZEICHEN, "z-schloss") : null, t.titel), t.untertitel ? h("div", {}, t.untertitel) : null, Z.lehrer ? h("div", { class: "stand nur-ohne-beamer" + (unterrichtStelle(pfad) ? " aktiv" : "") }, unterrichtText(t, pfad))
        : h("div", { class: "stand nur-ohne-beamer" + (themaStandText(t, pfad) === "noch nicht begonnen" ? "" : " aktiv") }, themaStandText(t, pfad))));
    }
    if (liste) kap.append(liste);
    ziel.append(kap);
  }
  // Sterne je Thema (16.10.): nur für die Person -- nie am Beamer
  if (!gesperrt && !Z.lehrer) api("sterne", {}).then(r => {
    Z.sterne = Object.assign(Z.sterne || {}, r.sterne);
    s.querySelectorAll(".themenkarte[data-pfad]").forEach(k => {
      const st = r.sterne[k.dataset.pfad]; const ort = k.querySelector(".stand");
      if (st && ort && st.summe) ort.append(h("span", { class: "karte-sterne" + (st.geschafft ? " geschafft" : "") }, " · ★ " + st.summe + " von " + st.max + (st.mindest ? " (Ziel " + st.mindest + ")" : "")));
    });
  }).catch(() => {});
  const nachschlagen = !gesperrt && nachschlagenBereich();
  if (nachschlagen) s.append(nachschlagen);
  s.append(fassungKarte());
  haupt.append(s);
}

// ─── Fassung und Aktualisierung (Weg B, Lehrer 14.10.) ──────────────────────────
// Nur auf Knopfdruck. Die Seite geht nie ins Netz: Python holt fassung.json und die ZIP
// (CSP bleibt 'self'). Ohne Netz derselbe Weg von Hand: die ZIP hereinnehmen.
function datumDe(iso) { return (iso || "").split("-").reverse().join("."); }
function fassungText() {
  const i = Z.inhalt, nr = i.fassung_nr || 0;
  if (!nr) return "Noch keine veröffentlichte Fassung (Entwurf, gebaut " + datumDe(i.version) + ")";
  return "Fassung " + nr + (i.fassung_datum ? " vom " + datumDe(i.fassung_datum) : "") + (i.fassung_entwurf ? " + Änderungen (Entwurf, gebaut " + datumDe(i.version) + ")" : "");
}
function fassungKarte() {
  const box = h("div", { class: "fassung-karte" }, h("div", { class: "fk" }, h("b", {}, fassungText()), h("span", { class: "leer" }, " · Python läuft auf diesem Rechner, nichts verlässt ihn.")));
  if (Z.lehrer) { box.append(h("p", { class: "leer nur-ohne-beamer" }, "Lehrerpult: kommt aus dem Projekt (Abzug in deinen OneDrive-Ordner „Lehrerpult Informatik“). Die Klasse aktualisiert ihre Fassung hier unten per Knopf oder von Hand.")); return box; }
  const ausgabe = h("div", { class: "fassung-ausgabe" });
  const datei = h("input", { type: "file", accept: ".zip" }); datei.hidden = true;
  const sag = (...k) => { ausgabe.textContent = ""; ausgabe.append(...k); };
  const fehler = e => { knoepfe.hidden = false; sag(h("p", { class: "fehler" }, e.message)); };
  // Ladeanzeige (P4, Lehrerwahl 23.11.2026: Form A, ein Balken mit Prozent, Zeile und Stufen; ohne „Nicht den Stick
  // ziehen“). Der Server meldet unter aktualisierung/stand, wie weit er ist; die Seite fragt alle 200 ms nach, solange
  // eine lange Anfrage läuft. Der Balken geht nie zurück (Prüfen läuft beim Einspielen ein zweites Mal).
  function ladeanzeige(mitLaden) {
    const BEREICH = mitLaden ? { laden: [0, 70], pruefen: [70, 80], einspielen: [80, 100] } : { pruefen: [0, 20], einspielen: [20, 100] };
    const NAME = { laden: "Herunterladen", pruefen: "Prüfen", einspielen: "Einspielen" }, folge = Object.keys(BEREICH);
    const zeile = h("span", { class: "la-zeile" }), prozent = h("span", { class: "la-prozent" }, "0 %"), fuellung = h("i");
    const balken = h("div", { class: "la-balken", role: "progressbar", "aria-valuemin": "0", "aria-valuemax": "100", "aria-valuenow": "0", "aria-label": "Fortschritt" }, fuellung);
    const chips = folge.map(s => h("li", {}, NAME[s]));
    const el = h("div", { class: "ladeanzeige" }, h("div", { class: "la-zahlen" }, zeile, prozent), balken, h("ol", { class: "la-stufen" }, chips));
    let p = 0, jetzt = 0;
    const mb = b => (b / 1048576).toFixed(1).replace(".", ",");
    function setzen(st) {
      if (!st || !BEREICH[st.stufe]) return;
      const i = folge.indexOf(st.stufe); if (i < jetzt) return; jetzt = i;
      const [von, bis] = BEREICH[st.stufe], anteil = st.von ? Math.min(1, st.jetzt / st.von) : 0;
      p = Math.max(p, von + (bis - von) * anteil);
      fuellung.style.width = p + "%"; balken.setAttribute("aria-valuenow", Math.floor(p)); prozent.textContent = Math.floor(p) + " %";
      zeile.textContent = NAME[st.stufe] + " · " + (st.stufe === "laden" ? mb(st.jetzt) + (st.von ? " von " + mb(st.von) : "") + " MB"
        : st.stufe === "pruefen" ? "Prüfsumme und Manifest" : "Datei " + st.jetzt + " von " + st.von);
      chips.forEach((c, k) => { c.className = k < i ? "durch" : k === i ? "jetzt" : ""; });
    }
    function fertig(n) {
      p = 100; el.classList.add("fertig"); fuellung.style.width = "100%"; balken.setAttribute("aria-valuenow", "100"); prozent.textContent = "100 %";
      zeile.textContent = "Alle " + n + " Dateien eingespielt"; chips.forEach(c => { c.className = "durch"; });
    }
    async function waehrend(arbeit) {
      let fertigGemeldet = false;
      const fragen = (async () => { while (!fertigGemeldet) { try { setzen(await api("aktualisierung/stand")); } catch (e) { /* weiter */ } await schlafen(200); } })();
      try { return await arbeit(); } finally { fertigGemeldet = true; await fragen; }
    }
    return { el, setzen, fertig, waehrend };
  }
  function kopfWaehrend(nr, datum) {
    knoepfe.hidden = true;     // waehrend es laeuft, kein zweiter Anstoss
    $(".fk b", box).textContent = "Fassung " + nr + (datum ? " vom " + datumDe(datum) : ""); $(".fk .leer", box).textContent = " · wird eingespielt";
  }
  async function einspielen(anz) {
    try {
      const a = await anz.waehrend(() => api("aktualisierung/einspielen", {}));
      // der Server beendet sich gleich (wie bei „Beenden“): keine Knoepfe mehr, die ins Leere fuehren -- und kein
      // „■ Stopp“ im Hinweis, start.py ist dann schon zu Ende (Probelauf 2, 28.10.: Lehrer fragte nach „Beenden“)
      knoepfe.remove(); $(".fk b", box).textContent = "Fassung " + a.bericht.nr + " eingespielt – wirksam nach dem Neustart"; $(".fk .leer", box).textContent = "";
      const z = a.bericht.zahlen || {};
      anz.fertig((z.ersetzen || 0) + (z.neu || 0) + (z.arbeit_neu || 0));
      sag(anz.el, h("div", { class: "fertig" }, h("p", { class: "neustart" }, h("b", {}, "Fertig – jetzt Fassung " + a.bericht.nr + ". "),
        "Dein Stand, deine Programme, Anmerkungen und Abgaben sind geblieben. start.py hat sich dafür beendet. Jetzt in Thonny ", h("b", {}, "F5"), " (grüner Pfeil) – dann läuft Fassung " + a.bericht.nr + ".")));
    } catch (e) { fehler(e); }
  }
  function zeigen(kopf, aenderungen, plan, los) {
    const z = plan && plan.zahlen;
    sag(h("div", { class: "fassung-neu" }, h("p", {}, h("b", {}, kopf)),
      h("ul", {}, (aenderungen.length ? aenderungen : ["(keine Liste dabei)"]).map(x => h("li", {}, x))),
      plan && plan.themen_neu.length ? h("p", {}, "Neue Themen: " + plan.themen_neu.join(" · ")) : null,
      z ? h("p", { class: "leer" }, "Ersetzt " + (z.ersetzen + z.neu) + " Dateien der Seite und der Themen" + (z.entfernen ? ", " + z.entfernen + " entfallen" : "") + ". Bewahrt: dein Stand, deine " + z.arbeit_bewahrt + " Arbeitsdateien, Anmerkungen, Abgaben.") : null,
      h("p", {}, h("button", { class: "primaer", onclick: los }, "Einspielen"), " ", h("button", { class: "ruhig", onclick: () => sag() }, "Später"))));
  }
  async function suchen() {
    sag(h("p", { class: "laden" }, "Suche nach einer neuen Fassung …"));
    try {
      const a = await api("aktualisierung/suchen", {});
      if (a.ohne_adresse) return sag(h("p", {}, "Für diesen Kurs ist keine Adresse eingetragen. Hat dir dein Lehrer eine Aktualisierungs-ZIP gegeben? Dann „Von Hand hereinnehmen …“."));
      if (!a.info.neu) return sag(h("p", { class: "ok" }, "Du hast die neueste Fassung (Fassung " + a.hier + ")."));
      zeigen("Fassung " + a.info.nr + (a.info.datum ? " vom " + datumDe(a.info.datum) : "") + " ist da:", a.info.aenderungen, null, async () => {
        const anz = ladeanzeige(true); sag(anz.el); kopfWaehrend(a.info.nr, a.info.datum);
        try { await anz.waehrend(() => api("aktualisierung/holen", {})); } catch (e) { $(".fk b", box).textContent = fassungText(); $(".fk .leer", box).textContent = ""; return fehler(e); }
        await einspielen(anz);
      });
    } catch (e) { fehler(e); }
  }
  async function ausDatei(f) {
    const pruef = ladeanzeige(false); sag(pruef.el);
    try { const a = await pruef.waehrend(async () => api("aktualisierung/hereinnehmen", { daten: await dateiB64(f) })); const pl = a.plan;
      zeigen("Fassung " + pl.nr + (pl.datum ? " vom " + datumDe(pl.datum) : "") + " (von Hand" + (pl.alt_nr ? ", hier bisher Fassung " + pl.alt_nr : "") + "):", pl.aenderungen, pl,
        () => { const anz = ladeanzeige(false); sag(anz.el); kopfWaehrend(pl.nr, pl.datum); return einspielen(anz); }); }
    catch (e) { fehler(e); }
  }
  datei.addEventListener("change", () => { const f = datei.files[0]; datei.value = ""; if (f) ausDatei(f); });
  // Die Fassungs-ZIP kam über das Einstellungsfenster („Stand hereinnehmen“, 16.11.2026): hier geht es weiter
  if (window.fassungVonHand) { const f = window.fassungVonHand; window.fassungVonHand = null; setTimeout(() => { box.scrollIntoView({ block: "center" }); ausDatei(f); }, 0); }
  const knoepfe = h("div", { class: "zeile nur-ohne-beamer" }, h("button", { onclick: suchen }, "Nach neuer Fassung suchen"), h("button", { class: "ruhig", onclick: () => datei.click() }, "Von Hand hereinnehmen …"), datei);
  box.append(knoepfe, ausgabe);
  return box;
}

// ─── Die Akte und die Pultseite eines Kapitels (iq2 fall, 19.11.2026) ─────────────────────
// Die Akte ist die Wand „Was bisher geschah“ als ganze Seite, für alle, die gefehlt haben. Sie zeigt nur, was vor dem
// spätesten begonnenen Thema liegt (dieselbe Grenze wie das Glossar, Regel 16.10. „was erst später kommt, verwirrt nur“)
// -- das Thema, an dem jemand steht, ist „? jetzt“. Das Pult zeigt alles. Die Pultseite (Namen, Auflösung) baut nur die
// Lehrerfassung, und am Beamer erscheint sie nicht.
function kapitelSeite(haupt, rk, art) {
  const r = (Z.inhalt.reihen || []).find(x => x.kennung === rk);
  if (!r || (art === "akte" && !r.akte) || (art === "pult" && !r.pultseite) || !["akte", "pult"].includes(art)) {
    haupt.append(h("p", { class: "fehler" }, "Diese Adresse kennt die Seite nicht.")); return;
  }
  if (art === "pult") return pultSeite(haupt, r);
  const a = r.akte;
  kopfZeichnen([["Die Akte", adr("kapitel/" + rk + "/akte")]]);
  const grenze = glossarGrenze();
  const da = a.themen.filter(t => glossarRang(t.pfad) < grenze);
  const jetzt = a.themen.find(t => glossarRang(t.pfad) === grenze) || (Z.lehrer ? {} : null);
  const zuletzt = feld => { for (let i = da.length - 1; i >= 0; i--) if (da[i][feld]) return da[i][feld]; return null; };
  const nacht = zuletzt("nacht") || [], verd = zuletzt("verdaechtige") || [];
  const nachtKarte = h("div", { class: "karte a-nacht" }, h("div", { class: "etikett" }, "Die Nacht"));
  const zeiten = nacht.filter(e => e.zeit), notizen = nacht.filter(e => !e.zeit);
  if (zeiten.length) nachtKarte.append(h("table", {}, h("tbody", {}, zeiten.map(e => h("tr", {}, h("td", { class: "zeit" }, e.zeit), h("td", { html: e.text }))))));
  notizen.forEach(e => nachtKarte.append(h("p", { class: "notiz", html: e.text })));
  if (!nacht.length) nachtKarte.append(h("p", { class: "leer" }, "Noch nichts – das erste Thema bringt die Aussage der Zeugin."));
  const personen = verd.map(v => h("div", { class: "person" + (v.raus ? " raus" : "") }, h("img", { src: v.bild, alt: v.rolle + (v.raus ? ", ausgeschieden" : "") }), h("span", {}, v.rolle)));   // ~~…~~ ausgeschieden (zaehlen, 23.11.)
  while (personen.length < 3) personen.push(h("div", { class: "person leer" }, h("div", { class: "platz" }, "?"), h("span", {}, "noch niemand")));
  const links = h("div", { class: "a-links" },
    h("div", { class: "karte a-bild" }, h("img", { src: a.bild, alt: "Die leere Vitrine im Vereinsheim" }), h("p", { class: "satz", html: a.satz })),
    nachtKarte,
    h("div", { class: "karte" }, h("div", { class: "etikett" }, "Die Verdächtigen"), h("div", { class: "verd" }, personen)));
  const rechts = h("div", { class: "a-rechts" }, h("div", { class: "etikett" }, "Kaczmareks Fragen – und was wir herausgefunden haben"));
  da.forEach(t => rechts.append(h("a", { class: "karte a-zeile", href: adr("t/" + t.pfad + "/erklaerung") },
    h("div", { class: "a-nr" }, String(t.nr)), h("div", {}, h("b", { html: t.frage }), h("div", { class: "a-fund", html: t.fund })),
    h("div", { class: "chips" }, t.werkzeuge.map(w => h("span", { class: "chip" }, w))))));
  if (jetzt) rechts.append(h("div", { class: "karte a-zeile jetzt" }, h("div", { class: "a-nr" }, String(jetzt.nr || da.length + 1)), h("div", {}, h("b", {}, "? jetzt"))));
  if (!da.length && !Z.lehrer) rechts.append(h("p", { class: "leer" }, "Die Akte füllt sich mit jedem Thema, das ihr abschließt."));
  const s = h("div", { class: "seite kapitelakte" },
    h("div", { class: "a-kopf" }, h("span", { class: "art" }, (Z.inhalt.halbjahr ? "" : "Kapitel " + r.nr + " · ") + r.titel), h("h1", {}, "Die Akte"),
      h("span", { class: "ort" }, "für alle, die gefehlt haben – eine Seite, dann bist du wieder dabei")),
    h("div", { class: "a-raster" }, links, rechts));
  bilderPfad(s, rk + "/_akte");
  haupt.append(s);
}
function pultSeite(haupt, r) {
  if (!Z.lehrer) { location.hash = adr(""); return; }
  const p = r.pultseite;
  kopfZeichnen([[p.titel, adr("kapitel/" + r.kennung + "/pult")]]);
  if (Z.beamer) {
    haupt.append(h("section", { class: "seite" }, h("div", { class: "karte" }, h("h2", {}, p.titel), h("p", {}, "Namen und Auflösung – bei Beamer EIN nicht zu sehen."))));
    return;
  }
  haupt.append(h("div", { class: "seite pultseite" },
    h("div", { class: "a-kopf" }, h("span", { class: "art" }, "Pult · nur du"), h("h1", {}, p.titel), h("span", { class: "ort", html: p.unter })),
    h("div", { class: "p-raster", html: p.html })));
}
