/* Lernraum · pultstart.js -- die Startseite des Lehrerpults: Meine Kurse, Alle Kapitel, Neuer Kurs.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self').

   Kurse im Pult anlegen, K3 (Lehrer 24.11.2026: „dass das Lehrerpult alle Kurse enthält in ihrer Urform und ich dann
   Kurse auf der Seite erstellen kann, die dann automatisch eine entsprechende Schülerversion mit neuen Passwörtern etc.
   erstellt … so übersichtlich und komfortabel für mich und die Schüler“; Skizze S5jTFBGT7nNXezvMh6AJ7F, „1 passt …
   4 passt“). Adressen: #/pult · #/pult/neu · #/pult/angelegt/<kennung>. Sie stehen über allen Kursen -- der offene
   Kurs bleibt offen, bis eine Karte „Öffnen“ sagt. Nur im Pult mit mehreren Kursen, nur bei Beamer aus. */
"use strict";
const PULT_STUFEN = ["11", "Q1", "Q2", "Q3", "Q4"];
const PULT_STUFENNAME = { "11": "Klasse 11", Q1: "Objekte und Algorithmen", Q2: "Datenbanken", Q3: "Sprachen und Automaten", Q4: "Rekursion und Abitur" };

function pultKopf() {
  kopfZeichnen([]);
  $("#kopf-titel").textContent = "Lehrerpult";
  // über allen Kursen: nur der Beamer-Schalter, die übrigen Knöpfe gehören zu einem Kurs
  const r = $("#kopf-rechts"); r.textContent = "";
  r.append(h("span", { class: "kopf-gruppe" }, h("button", { class: Z.beamer ? "beamer-an" : "", onclick: beamerSchalten, title: "Beamer EIN: die Kursübersicht ist dann unerreichbar" }, Z.beamer ? "Beamer EIN" : "Beamer aus")));
}

function pultStart(haupt, rest) {
  pultKopf();
  const s = h("div", { class: "seite pult-start" });
  haupt.append(s);
  if (Z.beamer) {
    s.append(h("h1", {}, "Lehrerpult"), h("p", { class: "leer" }, "Beamer ist an – die Kursübersicht gibt es nur bei Beamer aus."),
      h("p", {}, h("a", { class: "knopf", href: adr("") }, "Zu „" + kursTitel(Z.kurs) + "“")));
    return;
  }
  s.append(h("p", { class: "laden" }, "Lade die Kurse …"));
  api("pult/katalog").then(d => {
    s.textContent = "";
    if (rest[0] === "neu") return pultNeu(s, d);
    if (rest[0] === "angelegt" && rest[1]) return pultAngelegt(s, d, rest[1]);
    pultUebersicht(s, d);
  }).catch(e => { s.textContent = ""; s.append(h("p", { class: "fehler" }, e.message)); });
}

function pultChip(text, art) { return h("span", { class: "pult-chip " + (art || "") }, text); }

function pultUebersicht(s, d) {
  s.append(h("header", { class: "pult-kopf" },
    h("div", {}, h("h1", {}, "Lehrerpult Informatik"), h("p", { class: "unter" }, "Deine Kurse und alle Kapitel an einer Stelle")),
    h("a", { class: "knopf primaer", href: "#/pult/neu" }, "+ Neuer Kurs")));
  // Meine Kurse
  const raster = h("div", { class: "pult-karten" });
  for (const k of d.kurse) {
    const pflicht = k.kapitel.filter(x => !x.zugabe && !x.vorbereitet), zug = k.kapitel.filter(x => x.zugabe && !x.vorbereitet).length;
    const hjs = vor => [...new Set(k.kapitel.filter(x => !!x.vorbereitet === vor).map(x => x.halbjahr).filter(Boolean))].join(" und ");
    const text = (k.jahrgang ? hjs(false) + " freigegeben · " + (hjs(true) ? hjs(true) + " vorbereitet · " : "") : "")
      + pflicht.map(x => x.titel).join(", ") + (zug ? " · " + zug + (zug === 1 ? " Zugabe" : " Zugaben") : "");
    raster.append(h("article", { class: "pult-karte" + (k.offen ? " offen" : "") },
      k.stufe ? pultChip(k.stufe + (k.jahrgang ? " · jetzt" : ""), k.stufe === "11" ? "elf" : "q") : null,
      h("h3", {}, k.name || k.titel), h("p", {}, text),
      h("div", { class: "zeile" },
        h("button", { class: "primaer", onclick: () => kursWechseln(k.kurs, ""), title: k.offen ? "Dieser Kurs ist gerade offen" : "" }, "Öffnen"),
        h("button", { onclick: () => kursWechseln(k.kurs, "uebersicht") }, "Übersicht"),
        k.kennwoerter ? h("a", { class: "knopf", href: "/_kennwoerter/" + encodeURIComponent(k.kurs) + ".html", target: "_blank", rel: "noopener" }, "Kennwörter") : null)));
  }
  for (const a of d.angelegt.filter(x => !x.uebernommen)) {
    raster.append(h("article", { class: "pult-karte angelegt" },
      pultChip("angelegt · " + (a.freigegeben || "11"), "neu"),
      h("h3", {}, a.name), h("p", {}, "Fassung 1 liegt bereit. Mit dem nächsten Abzug kommt der Kurs mit Übersicht und Durchsicht ins Pult."),
      h("div", { class: "zeile" },
        h("a", { class: "knopf primaer", href: "#/pult/angelegt/" + encodeURIComponent(a.kennung) }, "Ansehen"),
        h("a", { class: "knopf", href: "/" + ["_angelegt", a.kennung, a.fassung.zip].map(encodeURIComponent).join("/"), download: a.fassung.zip }, "ZIP"),
        h("a", { class: "knopf", href: "/" + ["_angelegt", a.kennung, "kennwortliste.html"].map(encodeURIComponent).join("/"), target: "_blank", rel: "noopener" }, "Kennwörter"))));
  }
  raster.append(h("a", { class: "pult-karte pult-plus", href: "#/pult/neu" }, h("span", { class: "plus" }, "+"), h("b", {}, "Neuer Kurs"),
    h("span", {}, "Kapitel wählen, Schülerfassung mit neuen Kennwörtern")));
  s.append(h("section", {}, h("h2", {}, "Meine Kurse"), raster));
  // Alle Kapitel, je Stufe klappbar (gemerkt je Browser)
  if (!d.katalog) return;
  const kap = h("section", { class: "pult-kapitel" }, h("div", { class: "pult-zeile" }, h("h2", {}, "Alle Kapitel"),
    h("p", { class: "leer" }, "in ihrer Urform – so, wie das Projekt sie gebaut und geprüft hat")));
  for (const st of d.katalog.stufen) {
    if (!st.kapitel.length) continue;
    const schluessel = "pultstufe:" + st.stufe;
    let offen = !["Q3", "Q4"].includes(st.stufe);
    try { const w = localStorage.getItem(schluessel); if (w) offen = w === "auf"; } catch (e) { /* darf fehlen */ }
    const liste = h("div", { class: "pult-kapitelliste" });
    const kopf = h("button", { type: "button", class: "pult-stufenkopf", "aria-expanded": String(offen) },
      pultChip(st.stufe, st.stufe === "11" ? "elf" : "q"), h("b", {}, PULT_STUFENNAME[st.stufe] || ""), h("span", { class: "leer" }, st.kapitel.length + " Kapitel"));
    const setzen = () => { liste.hidden = !offen; kopf.classList.toggle("zu", !offen); kopf.setAttribute("aria-expanded", String(offen)); };
    kopf.addEventListener("click", () => { offen = !offen; setzen(); try { localStorage.setItem(schluessel, offen ? "auf" : "zu"); } catch (e) { /* darf fehlen */ } });
    for (const e of st.kapitel) {
      liste.append(h("div", { class: "pult-kap" + (e.gebaut ? "" : " geplant") },
        h("div", { class: "pult-zeile" }, h("b", {}, e.titel), pultChip(e.gebaut ? (e.zugabe ? "Zugabe" : e.themen + " Themen") : "geplant", e.gebaut ? (e.zugabe ? "zugabe" : "gebaut") : "geplant")),
        h("span", { class: "leer" }, e.kurse.length ? "in " + e.kurse.join(" · ") : (e.gebaut ? "in keinem Kurs" : "Jahresplan " + st.stufe))));
    }
    setzen();
    kap.append(h("div", { class: "pult-stufe" }, kopf, liste));
  }
  s.append(kap);
}

function pultNeu(s, d) {
  s.append(h("header", { class: "pult-kopf" }, h("div", {}, h("a", { href: "#/pult" }, "← Lehrerpult"), h("h1", {}, "Neuer Kurs"),
    h("p", { class: "unter" }, "Das Pult setzt die gewählten Kapitel zu einer Schülerfassung zusammen – mit neuen Kennwörtern."))));
  if (!d.katalog) { s.append(h("p", { class: "fehler" }, "Dieses Pult hat keinen Katalog – es neu abziehen.")); return; }
  const jahr = new Date().getFullYear();
  const name = h("input", { type: "text", class: "pult-feld", value: "Abitur " + (jahr + 3), "aria-label": "Name des Kurses" });
  const schuljahr = h("input", { type: "text", class: "pult-feld", value: (jahr + 1) + "/" + String(jahr + 2).slice(2) + " bis " + (jahr + 2) + "/" + String(jahr + 3).slice(2), "aria-label": "Schuljahr" });
  const frei = h("select", { class: "pult-feld", "aria-label": "Freigegeben bis" }, ["Q1", "Q2", "Q3", "Q4"].map(x => h("option", { value: x }, x)));
  const kapitelOrt = h("div", { class: "pult-wahl" });
  const fehler = h("p", { class: "fehler" }); fehler.hidden = true;
  let art = "jahrgang";
  const artWahl = (wert, titel, text) => {
    const r = h("input", { type: "radio", name: "pult-art", value: wert }); r.checked = wert === art;
    r.addEventListener("change", () => { art = wert; artGesetzt(); });
    return h("label", { class: "pult-option" }, r, h("span", {}, h("b", {}, titel), " ", h("span", { class: "leer" }, "– " + text)));
  };
  const freiZeile = h("label", { class: "pult-label" }, "Freigegeben bis", frei,
    h("span", { class: "leer" }, "Spätere Halbjahre kommen mit einer Fassung aus dem Projekt."));
  function artGesetzt() {
    freiZeile.hidden = art !== "jahrgang";
    if (art === "jahrgang" && /^Informatik 11/.test(name.value)) name.value = "Abitur " + (jahr + 3);
    if (art === "schuljahr" && /^Abitur/.test(name.value)) { schuljahr.value = (jahr + 1) + "/" + String(jahr + 2).slice(2); name.value = "Informatik 11 · " + schuljahr.value; }
    kapitelOrt.textContent = "";
    for (const st of d.katalog.stufen) {
      if ((art === "schuljahr") !== (st.stufe === "11") || !st.kapitel.length) continue;
      const gruppe = h("div", { class: "pult-wahlgruppe" }, h("div", { class: "pult-zeile" }, pultChip(st.stufe, st.stufe === "11" ? "elf" : "q"),
        h("span", { class: "leer" }, st.kapitel.some(e => !e.gebaut) ? (PULT_STUFENNAME[st.stufe] || "") + " – noch nicht alles gebaut, kommt, sobald fertig" : PULT_STUFENNAME[st.stufe] || "")));
      const kaesten = h("div", { class: "pult-kaesten" });
      for (const e of st.kapitel) {
        const k = h("input", { type: "checkbox", value: e.kennung }); k.checked = true;
        kaesten.append(h("label", { class: "pult-option" }, k, h("span", {}, e.titel, " ", h("span", { class: "leer" }, e.gebaut ? (e.zugabe ? "Zugabe" : "") : "geplant"))));
      }
      gruppe.append(kaesten);
      kapitelOrt.append(gruppe);
    }
  }
  const knopf = h("button", { class: "primaer", type: "button" }, "Kurs anlegen");
  knopf.addEventListener("click", async () => {
    fehler.hidden = true; knopf.disabled = true; knopf.textContent = "Wird angelegt …";
    try {
      const kapitel = [...kapitelOrt.querySelectorAll("input:checked")].map(x => x.value);
      const r = await api("pult/anlegen", { art, name: name.value, schuljahr: schuljahr.value, kapitel, freigegeben: art === "jahrgang" ? frei.value : null });
      location.hash = "#/pult/angelegt/" + encodeURIComponent(r.kurs.kennung);
    } catch (e) { fehler.textContent = e.message; fehler.hidden = false; knopf.disabled = false; knopf.textContent = "Kurs anlegen"; }
  });
  const form = h("div", { class: "pult-form" },
    h("div", { class: "pult-zwei" }, h("label", { class: "pult-label" }, "Name des Kurses", name), h("label", { class: "pult-label" }, "Schuljahr", schuljahr)),
    h("fieldset", {}, h("legend", {}, "Art"),
      artWahl("jahrgang", "Ein Jahrgang Q1–Q4", "ein Lernraum bis zum Abitur, jedes Halbjahr kommt mit einer Fassung dazu"),
      artWahl("schuljahr", "Ein Schuljahr Klasse 11", "ein Lernraum für das Jahr")),
    h("fieldset", {}, h("legend", {}, "Kapitel ", h("span", { class: "leer" }, "– alle angekreuzt, abwählen, was nicht dabei sein soll")), kapitelOrt),
    freiZeile, fehler,
    h("div", { class: "zeile pult-fuss" }, knopf, h("a", { class: "knopf", href: "#/pult" }, "Abbrechen")));
  const seite = h("aside", { class: "pult-seite" }, h("h2", {}, "Was dann passiert"), h("ol", {},
    h("li", {}, "Das Pult nimmt die gewählten Kapitel so, wie sie im Projekt gebaut und geprüft sind."),
    h("li", {}, "Für jedes Thema ein neues Kennwort; die Lösungen werden damit neu verschlüsselt."),
    h("li", {}, "Es entstehen die ZIP für die Klasse und deine Kennwortliste."),
    h("li", {}, "Beim nächsten Abzug übernimmt das Projekt den Kurs – mit Übersicht und Durchsicht im Pult, und damit er später neue Fassungen bekommt.")),
    h("p", { class: "leer" }, "Online geht dabei nichts. Hochgeladen wird eine Fassung weiter nur nach deinem Ja."));
  s.append(h("div", { class: "pult-neu" }, form, seite));
  artGesetzt();
}

function pultAngelegt(s, d, kennung) {
  const a = d.angelegt.find(x => x.kennung === kennung);
  s.append(h("a", { href: "#/pult" }, "← Lehrerpult"));
  if (!a) { s.append(h("p", { class: "fehler" }, "Diesen Kurs gibt es hier nicht: " + kennung)); return; }
  const n = a.kapitel.length, mb = (a.fassung.groesse / 1048576).toFixed(1).replace(".", ",");
  const pfad = x => "/" + ["_angelegt", a.kennung, x].map(encodeURIComponent).join("/");
  s.lastElementChild.remove();       // der Rückweg steht im Kopf, wie bei „Neuer Kurs“
  s.append(h("header", { class: "pult-kopf" }, h("div", {}, h("a", { href: "#/pult" }, "← Lehrerpult"), h("h1", {}, h("span", { class: "pult-haken", "aria-hidden": "true" }, "✓"), a.name + " ist angelegt"),
    h("p", { class: "unter" }, n + " Kapitel" + (a.freigegeben ? ", freigegeben bis " + a.freigegeben : "") + " · Kurs " + a.kennung + " · für jedes Thema ein neues Kennwort"))));
  s.append(h("div", { class: "pult-karten drei" },
    h("section", { class: "pult-karte" }, h("h3", {}, "Für die Klasse"), h("p", { class: "leer" }, "Per Stick, Teams oder Schulportal austeilen."),
      h("a", { class: "pult-datei", href: pfad(a.fassung.zip), download: a.fassung.zip }, h("b", {}, a.fassung.zip), h("span", { class: "leer" }, mb + " MB · entpacken, dann start.py in Thonny" + (a.anleitung ? " – die Anleitung SO_FAENGST_DU_AN.pdf liegt bei" : "")))),
    h("section", { class: "pult-karte" }, h("h3", {}, "Nur für dich"), h("p", { class: "leer" }, "Die Kennwörter gibst du Thema für Thema frei, wie bisher."),
      h("a", { class: "pult-datei", href: pfad("kennwortliste.html"), target: "_blank", rel: "noopener" }, h("b", {}, "Kennwortliste"), h("span", { class: "leer" }, "zum Ausdrucken"))),
    h("section", { class: "pult-karte hinweis-karte" }, h("h3", {}, "Später: neue Fassungen"),
      h("p", {}, "Der Kurs liegt in deinem OneDrive-Pult. Beim nächsten Abzug übernimmt ihn das Projekt" +
        (a.spaeter && a.spaeter.length ? " – " + a.spaeter.map(x => x.titel).join(", ") + " kommt mit der Fassung für " + [...new Set(a.spaeter.map(x => x.halbjahr))].join("/") : "") +
        ". Online geht eine Fassung weiter nur nach deinem Ja."))));
  s.append(h("p", { class: "zeile" }, h("a", { class: "knopf", href: "#/pult" }, "Zurück zum Pult")));
}
