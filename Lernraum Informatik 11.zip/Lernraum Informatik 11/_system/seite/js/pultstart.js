/* Lernraum · pultstart.js -- die Startseite des Lehrerpults: Meine Kurse, Alle Kapitel, Neuer Kurs.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self').

   Kurse im Pult anlegen, K3 (Lehrer 24.11.2026: „dass das Lehrerpult alle Kurse enthält in ihrer Urform und ich dann
   Kurse auf der Seite erstellen kann, die dann automatisch eine entsprechende Schülerversion mit neuen Passwörtern etc.
   erstellt … so übersichtlich und komfortabel für mich und die Schüler“; Skizze S5jTFBGT7nNXezvMh6AJ7F, „1 passt …
   4 passt“). Adressen: #/pult · #/pult/neu · #/pult/angelegt/<kennung>. Sie stehen über allen Kursen -- der offene
   Kurs bleibt offen, bis eine Karte „Öffnen“ sagt. Nur im Pult mit mehreren Kursen, nur bei Beamer aus. */
"use strict";
const PULT_STUFEN = ["11", "Q1", "Q2", "Q3", "Q4"];
const PULT_STUFENNAME = { "11": "Klasse 11", Q1: "Objekte und Algorithmen", Q2: "Datenbanken", Q3: "Sprachen und Automaten", Q4: "Rekursion und Abitur" };

function pultKopf() {
  kopfZeichnen([]);
  $("#kopf-titel").textContent = "Lehrerpult";
  // über allen Kursen: nur der Beamer-Schalter, die übrigen Knöpfe gehören zu einem Kurs
  const r = $("#kopf-rechts"); r.textContent = "";
  r.append(h("span", { class: "kopf-gruppe" }, h("button", { class: Z.beamer ? "beamer-an" : "", onclick: beamerSchalten, title: "Beamer EIN: die Kursübersicht ist dann unerreichbar" }, Z.beamer ? "Beamer EIN" : "Beamer aus")));
}

function pultStart(haupt, rest) {
  pultKopf();
  const s = h("div", { class: "seite pult-start" });
  haupt.append(s);
  if (Z.beamer) {
    s.append(h("h1", {}, "Lehrerpult"), h("p", { class: "leer" }, "Beamer ist an – die Kursübersicht gibt es nur bei Beamer aus."),
      h("p", {}, h("a", { class: "knopf", href: adr("") }, "Zu „" + kursTitel(Z.kurs) + "“")));
    return;
  }
  s.append(h("p", { class: "laden" }, "Lade die Kurse …"));
  api("pult/katalog").then(d => {
    s.textContent = "";
    if (rest[0] === "neu") return pultNeu(s, d);
    if (rest[0] === "angelegt" && rest[1]) return pultAngelegt(s, d, rest[1]);
    if (rest[0] === "kapitel" && rest[1]) return pultKapitel(s, d, rest[1]);
    pultUebersicht(s, d);
  }).catch(e => { s.textContent = ""; s.append(h("p", { class: "fehler" }, e.message)); });
}

function pultChip(text, art) { return h("span", { class: "pult-chip " + (art || "") }, text); }

// Archiv (Lehrer 25.11.2026, Attrappe 5Daki1KgdN6VsAsQpBPiSG, „Atrappe sieht gut aus“): Archivieren blendet nur aus,
// Wiederherstellen holt alles zurück, Löschen nur aus dem Archiv und nur mit dem Namen. Welche Karte gerade nachfragt:
let PULT_FRAGT = null;
async function pultNeuZeichnen(s) {
  const d = await api("pult/katalog");
  await laden();                       // Kursmenü und offener Kurs (archiviert man den offenen, öffnet der Server einen anderen)
  pultKopf(); s.textContent = ""; pultUebersicht(s, d);
}
async function pultAktion(s, name, daten, text) {
  try { await api(name, daten); PULT_FRAGT = null; await pultNeuZeichnen(s); if (text) meldung(text); }
  catch (e) { meldung(e.message, "fehler"); }
}
function pultNachfrage(s, frage, knopfText, aktion, klasse) {
  return h("div", { class: "pult-nachfrage" }, h("p", {}, frage),
    h("div", { class: "zeile" }, h("button", { type: "button", class: klasse || "primaer", onclick: aktion }, knopfText),
      h("button", { type: "button", class: "ruhig", onclick: () => { PULT_FRAGT = null; pultNeuZeichnen(s); } }, "Abbrechen")));
}
function pultDatum(iso) { const t = (iso || "").slice(0, 10).split("-"); return t.length === 3 ? t[2] + "." + t[1] + "." + t[0] : ""; }

function pultUebersicht(s, d) {
  s.append(h("header", { class: "pult-kopf" },
    h("div", {}, h("h1", {}, "Lehrerpult Informatik"), h("p", { class: "unter" }, "Deine Kurse und alle Kapitel an einer Stelle")),
    h("a", { class: "knopf primaer", href: "#/pult/neu" }, "+ Neuer Kurs")));
  // Meine Kurse
  const raster = h("div", { class: "pult-karten" });
  for (const k of d.kurse) {
    const pflicht = k.kapitel.filter(x => !x.zugabe && !x.vorbereitet), zug = k.kapitel.filter(x => x.zugabe && !x.vorbereitet).length;
    const hjs = vor => [...new Set(k.kapitel.filter(x => !!x.vorbereitet === vor).map(x => x.halbjahr).filter(Boolean))].join(" und ");
    const text = (k.jahrgang ? hjs(false) + " freigegeben · " + (hjs(true) ? hjs(true) + " vorbereitet · " : "") : "")
      + pflicht.map(x => x.titel).join(", ") + (zug ? " · " + zug + (zug === 1 ? " Zugabe" : " Zugaben") : "");
    const name = k.name || k.titel;
    raster.append(h("article", { class: "pult-karte" + (k.offen ? " offen" : ""), "data-kurs": k.kurs },
      k.stufe ? pultChip(k.stufe + (k.jahrgang ? " · jetzt" : ""), k.stufe === "11" ? "elf" : "q") : null,
      h("h3", {}, name), h("p", {}, text),
      PULT_FRAGT === "archiv:" + k.kurs
        ? pultNachfrage(s, "„" + name + "“ ins Archiv? Die Klasse merkt nichts davon. Du holst den Kurs jederzeit zurück.", "Archivieren",
            () => pultAktion(s, "pult/archivieren", { kurs: k.kurs }, "„" + name + "“ liegt im Archiv."))
        : h("div", { class: "zeile" },
          h("button", { class: "primaer", onclick: () => kursWechseln(k.kurs, ""), title: k.offen ? "Dieser Kurs ist gerade offen" : "" }, "Öffnen"),
          h("button", { onclick: () => kursWechseln(k.kurs, "uebersicht") }, "Übersicht"),
          k.kennwoerter ? h("a", { class: "knopf", href: "/_kennwoerter/" + encodeURIComponent(k.kurs) + ".html", target: "_blank", rel: "noopener" }, "Kennwörter") : null,
          k.kapitel.some(x => x.gesperrt) ? h("a", { class: "knopf", href: "#/pult/kapitel/" + encodeURIComponent(k.kurs) }, "Kapitel freischalten") : null,
          h("button", { type: "button", class: "ruhig pult-rechts", title: "Aus dem Pult ausblenden – wiederherstellbar",
            onclick: () => { PULT_FRAGT = "archiv:" + k.kurs; s.textContent = ""; pultUebersicht(s, d); } }, "Archivieren"))));
  }
  for (const a of d.angelegt.filter(x => !x.uebernommen)) {
    raster.append(h("article", { class: "pult-karte angelegt", "data-angelegt": a.kennung },
      pultChip("angelegt · " + (a.freigegeben || "11"), "neu"),
      h("h3", {}, a.name), h("p", {}, "Fassung 1 liegt bereit. Mit dem nächsten Abzug kommt der Kurs mit Übersicht und Durchsicht ins Pult."),
      PULT_FRAGT === "verwerfen:" + a.kennung
        ? pultNachfrage(s, "„" + a.name + "“ verwerfen? ZIP und Kennwortliste gehen weg. Das Projekt hat den Kurs noch nicht übernommen.", "Verwerfen",
            () => pultAktion(s, "pult/verwerfen", { kennung: a.kennung }, "„" + a.name + "“ ist verworfen."), "gefahr")
        : h("div", { class: "zeile" },
          h("a", { class: "knopf primaer", href: "#/pult/angelegt/" + encodeURIComponent(a.kennung) }, "Ansehen"),
          h("a", { class: "knopf", href: "/" + ["_angelegt", a.kennung, a.fassung.zip].map(encodeURIComponent).join("/"), download: a.fassung.zip }, "ZIP"),
          h("a", { class: "knopf", href: "/" + ["_angelegt", a.kennung, "kennwortliste.html"].map(encodeURIComponent).join("/"), target: "_blank", rel: "noopener" }, "Kennwörter"),
          h("button", { type: "button", class: "ruhig pult-rechts", onclick: () => { PULT_FRAGT = "verwerfen:" + a.kennung; s.textContent = ""; pultUebersicht(s, d); } }, "Verwerfen"))));
  }
  raster.append(h("a", { class: "pult-karte pult-plus", href: "#/pult/neu" }, h("span", { class: "plus" }, "+"), h("b", {}, "Neuer Kurs"),
    h("span", {}, "Kapitel wählen, Schülerfassung mit neuen Kennwörtern")));
  s.append(h("section", {}, h("h2", {}, "Meine Kurse"), raster));
  pultArchiv(s, d);
  // Alle Kapitel, je Stufe klappbar (gemerkt je Browser)
  if (!d.katalog) return;
  const kap = h("section", { class: "pult-kapitel" }, h("div", { class: "pult-zeile" }, h("h2", {}, "Alle Kapitel"),
    h("p", { class: "leer" }, "in ihrer Urform – so, wie das Projekt sie gebaut und geprüft hat")));
  for (const st of d.katalog.stufen) {
    if (!st.kapitel.length) continue;
    const schluessel = "pultstufe:" + st.stufe;
    let offen = !["Q3", "Q4"].includes(st.stufe);
    try { const w = localStorage.getItem(schluessel); if (w) offen = w === "auf"; } catch (e) { /* darf fehlen */ }
    const liste = h("div", { class: "pult-kapitelliste" });
    const kopf = h("button", { type: "button", class: "pult-stufenkopf", "aria-expanded": String(offen) },
      pultChip(st.stufe, st.stufe === "11" ? "elf" : "q"), h("b", {}, PULT_STUFENNAME[st.stufe] || ""), h("span", { class: "leer" }, st.kapitel.length + " Kapitel"));
    const setzen = () => { liste.hidden = !offen; kopf.classList.toggle("zu", !offen); kopf.setAttribute("aria-expanded", String(offen)); };
    kopf.addEventListener("click", () => { offen = !offen; setzen(); try { localStorage.setItem(schluessel, offen ? "auf" : "zu"); } catch (e) { /* darf fehlen */ } });
    for (const e of st.kapitel) {
      liste.append(h("div", { class: "pult-kap" + (e.gebaut ? "" : " geplant") },
        h("div", { class: "pult-zeile" }, h("b", {}, e.titel), pultChip(e.gebaut ? (e.zugabe ? "Zugabe" : e.themen + " Themen") : "geplant", e.gebaut ? (e.zugabe ? "zugabe" : "gebaut") : "geplant")),
        h("span", { class: "leer" }, e.kurse.length ? "in " + e.kurse.join(" · ") : (e.gebaut ? "in keinem Kurs" : "Jahresplan " + st.stufe))));
    }
    setzen();
    kap.append(h("div", { class: "pult-stufe" }, kopf, liste));
  }
  s.append(kap);
}

function pultArchiv(s, d) {
  const im = d.archiv || [];
  let offen = false;
  try { offen = localStorage.getItem("pultarchiv") === "auf"; } catch (e) { /* darf fehlen */ }
  const inhalt = h("div", { class: "pult-archivinhalt" },
    h("p", { class: "leer" }, "Archivierte Kurse stehen nicht im Kursmenü. Für die Klasse ändert sich nichts. „Wiederherstellen“ holt einen Kurs mit allem zurück."));
  const kopf = h("button", { type: "button", class: "pult-stufenkopf pult-archivkopf", "aria-expanded": String(offen) },
    h("b", {}, "Archiv"), h("span", { class: "leer" }, im.length ? im.length + (im.length === 1 ? " Kurs" : " Kurse") : "leer"));
  const setzen = () => { inhalt.hidden = !offen; kopf.classList.toggle("zu", !offen); kopf.setAttribute("aria-expanded", String(offen)); };
  kopf.addEventListener("click", () => { offen = !offen; setzen(); try { localStorage.setItem("pultarchiv", offen ? "auf" : "zu"); } catch (e) { /* darf fehlen */ } });
  if (!im.length) inhalt.append(h("p", { class: "leer" }, "Kein Kurs im Archiv."));
  else {
    const raster = h("div", { class: "pult-karten" });
    for (const k of im) {
      const name = k.name || k.titel;
      const was = [k.abgaben + (k.abgaben === 1 ? " Abgabe" : " Abgaben"), k.nadeln + (k.nadeln === 1 ? " Nadel" : " Nadeln"),
        k.anmerkungen + (k.anmerkungen === 1 ? " Anmerkung" : " Anmerkungen")].join(" · ");
      raster.append(h("article", { class: "pult-karte im-archiv", "data-kurs": k.kurs },
        pultChip("archiviert" + (k.stufe ? " · " + k.stufe : ""), "archiv"),
        h("h3", {}, name),
        h("p", {}, was + " – alles noch da" + (k.archiviert_seit ? " · seit " + pultDatum(k.archiviert_seit) : "")),
        k.eigene_kapitel ? h("p", { class: "leer" }, "Trägt eigene Kapitel, die andere Kurse benutzen – lässt sich nur archivieren.") : null,
        h("div", { class: "zeile" },
          h("button", { type: "button", class: "primaer", onclick: () => pultAktion(s, "pult/wiederherstellen", { kurs: k.kurs }, "„" + name + "“ steht wieder unter Meine Kurse.") }, "Wiederherstellen"),
          k.eigene_kapitel ? null : h("button", { type: "button", class: "ruhig pult-rechts", onclick: () => pultLoeschFenster(s, k) }, "Endgültig löschen …"))));
    }
    inhalt.append(raster);
  }
  setzen();
  s.append(h("section", { class: "pult-stufe pult-archiv" }, kopf, inhalt));
}

function pultLoeschFenster(s, k) {
  const name = k.name || k.titel;
  const grund = h("div", { class: "pult-fenster-grund" });
  const zu = () => grund.remove();
  const eingabe = h("input", { type: "text", class: "pult-feld", id: "pult-loesch-name", autocomplete: "off", placeholder: name });
  const sichern = h("input", { type: "checkbox", id: "pult-loesch-zip" }); sichern.checked = k.abgaben > 0;
  const fehler = h("p", { class: "fehler" }); fehler.hidden = true;
  const los = h("button", { type: "button", class: "gefahr" }, "Endgültig löschen"); los.disabled = true;
  eingabe.addEventListener("input", () => { los.disabled = eingabe.value.trim() !== name; });
  los.addEventListener("click", async () => {
    los.disabled = true;
    if (sichern.checked) {   // erst die Sicherung laden, dann löschen
      const a = h("a", { href: "/_abgaben_sichern/" + encodeURIComponent(k.kurs) + ".zip", download: "abgaben_" + k.kurs + ".zip" });
      document.body.append(a); a.click(); a.remove();
      await schlafen(1200);
    }
    try { await api("pult/loeschen", { kurs: k.kurs, name: eingabe.value.trim() }); zu(); PULT_FRAGT = null; await pultNeuZeichnen(s);
      meldung("„" + name + "“ ist gelöscht." + (sichern.checked ? " Die Abgaben liegen als ZIP in deinen Downloads." : "")); }
    catch (e) { fehler.textContent = e.message; fehler.hidden = false; los.disabled = false; }
  });
  grund.addEventListener("click", e => { if (e.target === grund) zu(); });
  grund.addEventListener("keydown", e => { if (e.key === "Escape") zu(); });
  grund.append(h("div", { class: "pult-fenster", role: "dialog", "aria-modal": "true", "aria-labelledby": "pult-loesch-titel" },
    h("h2", { id: "pult-loesch-titel" }, "„" + name + "“ endgültig löschen?"),
    h("div", {}, h("h4", {}, "Das verschwindet aus dem Pult"), h("ul", { class: "weg" },
      h("li", {}, "die gesicherten Stände der Klasse"),
      h("li", {}, k.abgaben + (k.abgaben === 1 ? " Abgabe" : " Abgaben") + " und die Übersicht dazu"),
      h("li", {}, k.nadeln + (k.nadeln === 1 ? " Nadel" : " Nadeln") + " und " + k.anmerkungen + (k.anmerkungen === 1 ? " Anmerkung" : " Anmerkungen") + ", die noch nicht im Projekt sind"),
      h("li", {}, "die Kennwortliste"))),
    h("div", {}, h("h4", {}, "Das bleibt"), h("ul", { class: "bleibt" },
      h("li", {}, "alle Kapitel – sie wohnen in ihren Heimatkursen"),
      h("li", {}, "der Lernraum auf den Sticks der Klasse"),
      h("li", {}, "im Projekt: der Kursordner, verschoben ins Archiv der Werkstatt"))),
    h("label", { class: "pult-option", for: "pult-loesch-zip" }, sichern, h("span", {}, "Vorher die Abgaben als ZIP herunterladen")),
    h("label", { class: "pult-label", for: "pult-loesch-name" }, "Zum Bestätigen den Namen des Kurses eintippen", eingabe),
    fehler,
    h("div", { class: "zeile pult-fensterfuss" }, h("button", { type: "button", class: "ruhig", onclick: zu }, "Abbrechen"), los)));
  document.body.append(grund);
  eingabe.focus();
}

// Kapitel mit Kennwort (Lehrer 25.11.2026, Attrappe UiviBMN4mJAz7DhFRL1uNs, „passt alles“): je Kurs alle Kapitel, je
// gesperrtem das Kennwort und ein fertiger Satz für Teams. Was die Klasse schon geöffnet hat, weiß das Pult nicht.
async function pultKopieren(text, was) {
  try { await navigator.clipboard.writeText(text); meldung(was + " kopiert."); }
  catch (e) { meldung(was + ": " + text); }
}
function pultKapitel(s, d, kurs) {
  const k = d.kurse.concat(d.archiv || []).find(x => x.kurs === kurs);
  s.append(h("header", { class: "pult-kopf" }, h("div", {}, h("a", { href: "#/pult" }, "← Lehrerpult"),
    h("h1", {}, (k ? k.name || k.titel : kurs) + " · Kapitel freischalten"),
    h("p", { class: "unter" }, "Was gebaut ist, hat die Klasse schon in ihrer Fassung. Ein gesperrtes Kapitel geht auf, wenn sie sein Kennwort unten auf der Kursseite eintippt."))));
  if (!k) { s.append(h("p", { class: "fehler" }, "Diesen Kurs trägt das Pult nicht: " + kurs)); return; }
  const tb = h("tbody");
  let hj;
  for (const x of k.kapitel) {
    if (x.halbjahr && x.halbjahr !== hj) { hj = x.halbjahr; tb.append(h("tr", { class: "pult-kapgruppe" }, h("td", { colspan: "4" }, x.halbjahr))); }
    let stand, knoepfe = null;
    if (x.vorbereitet) stand = pultChip("nur im Pult – kommt mit einer Fassung", "geplant");
    else if (!x.gesperrt) stand = pultChip("offen von Anfang an", "gebaut");
    else {
      stand = h("span", { class: "pult-kw" }, x.kennwort || "–");
      if (x.kennwort) knoepfe = h("div", { class: "zeile" },
        h("button", { type: "button", onclick: () => pultKopieren(x.kennwort, "Kennwort") }, "Kennwort"),
        h("button", { type: "button", onclick: () => pultKopieren("Neues Kapitel im Lernraum: „" + x.titel + "“. Unten auf der Kursseite bei „Kapitel freischalten“ eintippen: " + x.kennwort, "Text für Teams") }, "Text für Teams"));
    }
    tb.append(h("tr", {}, h("td", {}, h("b", {}, x.titel)), h("td", {}, pultChip(x.zugabe ? "Zusatz" : "Pflicht", x.zugabe ? "zugabe" : "q")), h("td", {}, stand), h("td", {}, knoepfe)));
  }
  s.append(h("div", { class: "pult-form pult-kapiteltafel" }, h("div", { class: "pult-tabelle" }, h("table", {},
    h("thead", {}, h("tr", {}, h("th", {}, "Kapitel"), h("th", {}, "Art"), h("th", {}, "Kennwort"), h("th", {}, ""))), tb)),
    h("p", { class: "leer" }, "Zum Ausdrucken stehen die Kennwörter auch in der Kennwortliste des Kurses (Knopf „Kennwörter“ auf der Karte).")));
}

function pultNeu(s, d) {
  s.append(h("header", { class: "pult-kopf" }, h("div", {}, h("a", { href: "#/pult" }, "← Lehrerpult"), h("h1", {}, "Neuer Kurs"),
    h("p", { class: "unter" }, "Das Pult setzt die gewählten Kapitel zu einer Schülerfassung zusammen – mit neuen Kennwörtern."))));
  if (!d.katalog) { s.append(h("p", { class: "fehler" }, "Dieses Pult hat keinen Katalog – es neu abziehen.")); return; }
  const jahr = new Date().getFullYear();
  const name = h("input", { type: "text", class: "pult-feld", value: "Abitur " + (jahr + 3), "aria-label": "Name des Kurses" });
  const schuljahr = h("input", { type: "text", class: "pult-feld", value: (jahr + 1) + "/" + String(jahr + 2).slice(2) + " bis " + (jahr + 2) + "/" + String(jahr + 3).slice(2), "aria-label": "Schuljahr" });
  const frei = h("select", { class: "pult-feld", "aria-label": "Freigegeben bis" }, ["Q1", "Q2", "Q3", "Q4"].map(x => h("option", { value: x }, x)));
  const kapitelOrt = h("div", { class: "pult-wahl" });
  const fehler = h("p", { class: "fehler" }); fehler.hidden = true;
  let art = "jahrgang";
  const artWahl = (wert, titel, text) => {
    const r = h("input", { type: "radio", name: "pult-art", value: wert }); r.checked = wert === art;
    r.addEventListener("change", () => { art = wert; artGesetzt(); });
    return h("label", { class: "pult-option" }, r, h("span", {}, h("b", {}, titel), " ", h("span", { class: "leer" }, "– " + text)));
  };
  const freiZeile = h("label", { class: "pult-label" }, "Freigegeben bis", frei,
    h("span", { class: "leer" }, "Spätere Halbjahre kommen mit einer Fassung aus dem Projekt."));
  function artGesetzt() {
    freiZeile.hidden = art !== "jahrgang";
    if (art === "jahrgang" && /^Informatik 11/.test(name.value)) name.value = "Abitur " + (jahr + 3);
    if (art === "schuljahr" && /^Abitur/.test(name.value)) { schuljahr.value = (jahr + 1) + "/" + String(jahr + 2).slice(2); name.value = "Informatik 11 · " + schuljahr.value; }
    kapitelOrt.textContent = "";
    for (const st of d.katalog.stufen) {
      if ((art === "schuljahr") !== (st.stufe === "11") || !st.kapitel.length) continue;
      const gruppe = h("div", { class: "pult-wahlgruppe" }, h("div", { class: "pult-zeile" }, pultChip(st.stufe, st.stufe === "11" ? "elf" : "q"),
        h("span", { class: "leer" }, st.kapitel.some(e => !e.gebaut) ? (PULT_STUFENNAME[st.stufe] || "") + " – noch nicht alles gebaut, kommt, sobald fertig" : PULT_STUFENNAME[st.stufe] || "")));
      const kaesten = h("div", { class: "pult-kaesten" });
      for (const e of st.kapitel) {
        const k = h("input", { type: "checkbox", value: e.kennung }); k.checked = true;
        // Kapitel mit Kennwort (25.11.2026): „gleich offen“ -- sonst geht es erst mit seinem Kennwort auf
        const o = h("input", { type: "checkbox", class: "pult-offen", value: e.kennung, "data-stufe": st.stufe, "data-zugabe": e.zugabe ? "1" : "" });
        kaesten.append(h("div", { class: "pult-kapwahl" }, h("label", { class: "pult-option" }, k, h("span", {}, e.titel, " ", h("span", { class: "leer" }, e.gebaut ? (e.zugabe ? "Zugabe" : "") : "geplant"))),
          e.gebaut ? h("label", { class: "pult-offen-wahl", title: "Ohne Haken geht das Kapitel erst mit seinem Kennwort auf" }, o, h("span", {}, "gleich offen")) : null));
      }
      gruppe.append(kaesten);
      kapitelOrt.append(gruppe);
    }
    offenVorgabe();
  }
  // die Vorgabe (Lehrer 25.11.2026): Q-Phase die Pflicht bis „freigegeben“, die 11 alle Pflichtkapitel
  function offenVorgabe() {
    kapitelOrt.querySelectorAll(".pult-offen").forEach(o => {
      o.checked = !o.dataset.zugabe && (art === "schuljahr" || PULT_STUFEN.indexOf(o.dataset.stufe) <= PULT_STUFEN.indexOf(frei.value));
    });
  }
  frei.addEventListener("change", offenVorgabe);
  const knopf = h("button", { class: "primaer", type: "button" }, "Kurs anlegen");
  knopf.addEventListener("click", async () => {
    fehler.hidden = true; knopf.disabled = true; knopf.textContent = "Wird angelegt …";
    try {
      const kapitel = [...kapitelOrt.querySelectorAll("input:checked:not(.pult-offen)")].map(x => x.value);
      const offen = [...kapitelOrt.querySelectorAll("input.pult-offen:checked")].map(x => x.value).filter(x => kapitel.includes(x));
      const r = await api("pult/anlegen", { art, name: name.value, schuljahr: schuljahr.value, kapitel, offen, freigegeben: art === "jahrgang" ? frei.value : null });
      location.hash = "#/pult/angelegt/" + encodeURIComponent(r.kurs.kennung);
    } catch (e) { fehler.textContent = e.message; fehler.hidden = false; knopf.disabled = false; knopf.textContent = "Kurs anlegen"; }
  });
  const form = h("div", { class: "pult-form" },
    h("div", { class: "pult-zwei" }, h("label", { class: "pult-label" }, "Name des Kurses", name), h("label", { class: "pult-label" }, "Schuljahr", schuljahr)),
    h("fieldset", {}, h("legend", {}, "Art"),
      artWahl("jahrgang", "Ein Jahrgang Q1–Q4", "ein Lernraum bis zum Abitur, jedes Halbjahr kommt mit einer Fassung dazu"),
      artWahl("schuljahr", "Ein Schuljahr Klasse 11", "ein Lernraum für das Jahr")),
    h("fieldset", {}, h("legend", {}, "Kapitel ", h("span", { class: "leer" }, "– alle angekreuzt, abwählen, was nicht dabei sein soll")), kapitelOrt),
    freiZeile, fehler,
    h("div", { class: "zeile pult-fuss" }, knopf, h("a", { class: "knopf", href: "#/pult" }, "Abbrechen")));
  const seite = h("aside", { class: "pult-seite" }, h("h2", {}, "Was dann passiert"), h("ol", {},
    h("li", {}, "Das Pult nimmt die gewählten Kapitel so, wie sie im Projekt gebaut und geprüft sind."),
    h("li", {}, "Für jedes Thema ein neues Kennwort; die Lösungen werden damit neu verschlüsselt."),
    h("li", {}, "Was nicht „gleich offen“ ist, steckt trotzdem im Lernraum – es geht auf, wenn die Klasse sein Kennwort eintippt."),
    h("li", {}, "Es entstehen die ZIP für die Klasse und deine Kennwortliste."),
    h("li", {}, "Beim nächsten Abzug übernimmt das Projekt den Kurs – mit Übersicht und Durchsicht im Pult, und damit er später neue Fassungen bekommt.")),
    h("p", { class: "leer" }, "Online geht dabei nichts. Hochgeladen wird eine Fassung weiter nur nach deinem Ja."));
  s.append(h("div", { class: "pult-neu" }, form, seite));
  artGesetzt();
}

function pultAngelegt(s, d, kennung) {
  const a = d.angelegt.find(x => x.kennung === kennung);
  s.append(h("a", { href: "#/pult" }, "← Lehrerpult"));
  if (!a) { s.append(h("p", { class: "fehler" }, "Diesen Kurs gibt es hier nicht: " + kennung)); return; }
  const n = a.kapitel.length, mb = (a.fassung.groesse / 1048576).toFixed(1).replace(".", ",");
  const pfad = x => "/" + ["_angelegt", a.kennung, x].map(encodeURIComponent).join("/");
  s.lastElementChild.remove();       // der Rückweg steht im Kopf, wie bei „Neuer Kurs“
  s.append(h("header", { class: "pult-kopf" }, h("div", {}, h("a", { href: "#/pult" }, "← Lehrerpult"), h("h1", {}, h("span", { class: "pult-haken", "aria-hidden": "true" }, "✓"), a.name + " ist angelegt"),
    h("p", { class: "unter" }, n + " Kapitel" + (a.freigegeben ? ", freigegeben bis " + a.freigegeben : "") + " · Kurs " + a.kennung + " · für jedes Thema ein neues Kennwort"))));
  s.append(h("div", { class: "pult-karten drei" },
    h("section", { class: "pult-karte" }, h("h3", {}, "Für die Klasse"), h("p", { class: "leer" }, "Per Stick, Teams oder Schulportal austeilen."),
      h("a", { class: "pult-datei", href: pfad(a.fassung.zip), download: a.fassung.zip }, h("b", {}, a.fassung.zip), h("span", { class: "leer" }, mb + " MB · entpacken, dann start.py in Thonny" + (a.anleitung ? " – die Anleitung SO_FAENGST_DU_AN.pdf liegt bei" : "")))),
    h("section", { class: "pult-karte" }, h("h3", {}, "Nur für dich"), h("p", { class: "leer" }, "Die Kennwörter gibst du Thema für Thema frei, wie bisher."),
      h("a", { class: "pult-datei", href: pfad("kennwortliste.html"), target: "_blank", rel: "noopener" }, h("b", {}, "Kennwortliste"), h("span", { class: "leer" }, "zum Ausdrucken"))),
    h("section", { class: "pult-karte hinweis-karte" }, h("h3", {}, "Später: neue Fassungen"),
      h("p", {}, "Der Kurs liegt in deinem OneDrive-Pult. Beim nächsten Abzug übernimmt ihn das Projekt" +
        (a.spaeter && a.spaeter.length ? " – " + a.spaeter.map(x => x.titel).join(", ") + " kommt mit der Fassung für " + [...new Set(a.spaeter.map(x => x.halbjahr))].join("/") : "") +
        ". Online geht eine Fassung weiter nur nach deinem Ja."))));
  s.append(h("p", { class: "zeile" }, h("a", { class: "knopf", href: "#/pult" }, "Zurück zum Pult")));
}
