/* Lernraum · router.js -- der Router: welche Ansicht zur Adresse gehört.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Router ──────────────────────────────────────────────────────────────────────
function zeichnen() { zeichnenInhalt(); durchsichtNach(); anmerkungenNach(); }
// Frisch geöffnet (Lehrer 24.11.2026: „wenn du mir das Pult neu öffnest, kommt immer die Meldung, dass gerade …
// offen ist“): Nennt die Adresse beim Öffnen einen anderen Kurs, wechselt das Pult selbst -- die Karte bleibt nur am
// Beamer und für einen veralteten Tab (sonst schalteten sich zwei Tabs gegenseitig um).
let frischGeoeffnet = true;
function zeichnenInhalt() {
  const frisch = frischGeoeffnet; frischGeoeffnet = false;
  const alle = hashTeile();
  const haupt = $("#haupt"); haupt.textContent = ""; haupt.className = "";
  Z.weg = [];
  // Adresse ohne Kurs (alt: #/t/..., Lesezeichen, Knopf "#/") -> mit dem offenen Kurs davor.
  // Die Startseite des Pults (K3, 24.11.2026): über allen Kursen, #/pult; ohne Adresse landet das Pult dort
  if (Z.lehrer && Z.pult && (!alle.length || alle[0] === "pult")) {
    if (!alle.length) { location.replace("#/pult"); return; }
    return pultStart(haupt, alle.slice(1));
  }
  $("#kopf-titel").textContent = kopfTitel();
  const bekannt = k => k === Z.kurs || Z.kurse.some(e => e.kurs === k);
  if (!alle.length || !bekannt(alle[0])) { location.replace(adr(alle.map(encodeURIComponent).join("/"))); return; }
  if (alle[0] !== Z.kurs && frisch && Z.lehrer && !Z.beamer) {
    haupt.append(h("p", { class: "laden" }, "Wechsle zu „" + kursTitel(alle[0]) + "“ …"));
    return kursWechseln(alle[0], alle.slice(1).join("/"));
  }
  if (alle[0] !== Z.kurs) return fremderKurs(haupt, alle[0], alle.slice(1));
  const teile = alle.slice(1);
  if (!teile.length || teile[0] === "kurs") return kursseite(haupt);
  if (teile[0] === "uebersicht") return uebersichtSeite(haupt);
  if (teile[0] === "schuljahr") return schuljahrSeite(haupt);
  if (teile[0] === "besprechung") return besprechungSeite(haupt);
  if (teile[0] === "glossar") {
    if (!Z.lehrer && !Z.stand.name) { location.hash = adr(""); return; }   // wie die Themen: erst der Name
    return glossarSeite(haupt, teile[1]);
  }
  if (teile[0] === "ichkann") {
    if (!Z.lehrer && !Z.stand.name) { location.hash = adr(""); return; }
    return ichKannSeite(haupt);
  }
  if (teile[0] === "lernkarten") {
    if (!Z.lehrer && !Z.stand.name) { location.hash = adr(""); return; }
    return lernkartenSeite(haupt);
  }
  if (teile[0] === "kapitel" && teile.length >= 3) {
    // die Akte (alle) und die Pultseite (nur Lehrer) eines Kapitels -- iq2 fall, 19.11.2026
    if (!Z.lehrer && !Z.stand.name) { location.hash = adr(""); return; }
    return kapitelSeite(haupt, teile[1], teile[2]);
  }
  if (teile[0] === "fehlerbuch") {
    if (!Z.lehrer && !Z.stand.name) { location.hash = adr(""); return; }
    return fehlerbuchSeite(haupt);
  }
  if (teile[0] === "t" && teile.length >= 3) {
    if (!Z.lehrer && !Z.stand.name) { location.hash = adr(""); return; }   // erst der Name (Lehrer 14.10.)
    return themaSeite(haupt, teile[1], teile[2], teile[3] || "vortrag", teile[4]);
  }
  haupt.append(h("p", { class: "fehler" }, "Diese Adresse kennt die Seite nicht."));
}
window.addEventListener("hashchange", zeichnen);

// Eine Adresse aus einem Kurs, der gerade nicht offen ist (zweiter Tab, Lesezeichen).
// Nie still wechseln: Am Beamer bliebe sonst unbemerkt der falsche Kurs stehen.
function fremderKurs(haupt, kurs, rest) {
  kopfZeichnen([]);
  const karte = h("div", { class: "karte fremder-kurs" },
    h("h2", {}, "Diese Seite gehört zu „" + kursTitel(kurs) + "“"),
    h("p", {}, "Im Lehrerpult ist gerade „" + kopfTitel() + "“ offen."));
  const zeile = h("div", { class: "zeile" });
  if (Z.beamer) zeile.append(h("p", { class: "leer" }, "Den Kurs wechseln geht nur bei Beamer aus."));
  else zeile.append(h("button", { class: "primaer", onclick: () => kursWechseln(kurs, rest.join("/")) }, "Zu „" + kursTitel(kurs) + "“ wechseln"));
  zeile.append(h("a", { class: "knopf", href: adr("") }, "Bei „" + kopfTitel() + "“ bleiben"));
  karte.append(zeile);
  haupt.append(h("section", { class: "seite" }, karte));
}

// Kurs wechseln (nur Lehrerpult, nur bei Beamer aus -- der Server sagt sonst 423).
// Alles, was je Kurs geladen war, wird vergessen: Durchsicht, Werkbuch, Hängestellen.
// Das Kursmenü schliesst bei einem Klick daneben und mit Esc (einmal fuer die Seite, nicht je Zeichnen der Kopfleiste)
document.addEventListener("pointerdown", ev => { const m = document.querySelector("details.kurs-menue[open]"); if (m && !m.contains(ev.target)) m.open = false; });
document.addEventListener("keydown", ev => { if (ev.key === "Escape") { const m = document.querySelector("details.kurs-menue[open]"); if (m) m.open = false; } });
async function kursWechseln(kurs, route) {
  try { await api("kurs/waehlen", { kurs }); } catch (e) { meldung(e.message, "fehler"); return; }
  D.daten = null; W.daten = null; A.stellen = []; A.haengestellen = false; A.liste = []; A.thema = null;
  await laden();
  const ziel = adr(route || "");
  if (location.hash === ziel) zeichnen(); else location.hash = ziel;
}
